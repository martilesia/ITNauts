// Loads and validates public/config/game.config.json.
export async function loadConfig() {
  let res;
  try { res = await fetch(import.meta.env.BASE_URL + 'config/game.config.json'); }
  catch { throw new Error('Could not fetch game.config.json.'); }
  if (!res.ok) throw new Error('game.config.json not found (HTTP ' + res.status + ').');
  let cfg;
  try { cfg = await res.json(); } catch { throw new Error('game.config.json is not valid JSON.'); }
  const need = ['game', 'settings', 'customization', 'intro', 'sim', 'sci', 'cards', 'chapters'];
  const miss = need.filter((k) => !(k in cfg));
  if (miss.length) throw new Error('Missing config sections: ' + miss.join(', '));
  if (!Array.isArray(cfg.chapters) || cfg.chapters.length !== 10) throw new Error('Config must define exactly 10 chapters.');
  return cfg;
}
