import { useEffect, useState } from 'react';
import { loadConfig } from './data/configLoader.js';

// Loads game.config.json at runtime, then starts the game engine.
export default function App() {
  const [state, setState] = useState({ status: 'loading', error: null });
  useEffect(() => {
    let dead = false;
    loadConfig()
      .then((cfg) => {
        if (dead) return;
        window.__SBC_CONFIG__ = cfg;
        setState({ status: 'ready', error: null });
      })
      .catch((e) => !dead && setState({ status: 'error', error: e.message }));
    return () => { dead = true; };
  }, []);
  useEffect(() => {
    if (state.status !== 'ready') return;
    const s = document.createElement('script');
    s.src = import.meta.env.BASE_URL + 'engine.js';
    s.onerror = () => setState({ status: 'error', error: 'Could not load the game engine (engine.js).' });
    document.body.appendChild(s);
    return () => s.remove();
  }, [state.status]);
  if (state.status === 'error')
    return <div className="card bad" role="alert"><h2>Configuration error</h2><p>{state.error}</p><p>Check public/config/game.config.json.</p></div>;
  if (state.status === 'loading') return <p style={{ padding: 20 }}>Loading…</p>;
  return <div id="app" />;
}
