# SPACE BASE COMMANDER

Educational web game (Vite + React). Content and tunable values live in
`public/config/game.config.json`, loaded at runtime by `src/data/configLoader.js`.

## Run
    npm install
    npm run dev      # development
    npm run build    # production build in dist/
    npm run preview

## Structure
- `public/config/game.config.json`: chapters, decisions, consequences, cards, simulation values (fictional-educational values are labeled).
- `public/engine.js`: game engine (screens, activities, LocalStorage save/resume). Reads `window.__SBC_CONFIG__`.
- `src/`: React shell (config loading, validation, error screen).

## Limitations
The engine is one classic script, not yet split into React components. No audio.
Gravity values are rounded reference figures: verify against the official source.
To test the config: edit a chapter title or a resource effect in the JSON and reload.
