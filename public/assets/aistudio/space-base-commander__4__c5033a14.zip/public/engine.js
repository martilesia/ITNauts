(function (global) {
  'use strict';

  const SCREENS = {
    INITIAL: 'INITIAL',
    PERSONALIZATION: 'PERSONALIZATION',
    DESTINATION: 'DESTINATION',
    EXPERIMENTS: 'EXPERIMENTS',
    EXITED: 'EXITED',
  };

  function createInitialProgress(config) {
    const progress = {};
    const planets =
      (config &&
        config.screens &&
        config.screens.experiments &&
        config.screens.experiments.planets) ||
      [];

    planets.forEach(function (planet) {
      progress[planet.id] = {
        unlocked: Boolean(planet.unlockedByDefault),
        unlockedUpTo: 5,
        starsByExperiment: {},
      };
    });

    if (!progress.earth) {
      progress.earth = {
        unlocked: true,
        unlockedUpTo: 5,
        starsByExperiment: {},
      };
    }

    return progress;
  }

  function createFreshModisMissionState() {
    return {
      step: 1,
      timeOfDay: 'day',
      inspectedObservations: {},
      comparisonAnswers: {},
      installedLayers: [],
      mistakes: 0,
      completedStars: 0,
    };
  }

  function createFreshTerrainMissionState(config) {
    const items =
      (config &&
        config.screens &&
        config.screens.experiments &&
        config.screens.experiments.items) ||
      [];
    const m3 = items.find(function (it) {
      return it.id === 3;
    });
    const grid = (m3 && m3.missionData && m3.missionData.grid) || {};
    const start = grid.start || { x: 0, y: 5 };

    return {
      phase: 'BRIEFING',
      rover: { x: start.x, y: start.y, facing: 'right' },
      visitedCells: [start.x + ',' + start.y],
      battery: 100,
      samplesCollected: [],
      resolvedChallenges: [],
      score: 0,
      activeChallenge: null,
      pendingTarget: null,
      instructionsOpen: false,
      lowBatteryWarningShown: false,
      lowBatteryModalOpen: false,
      reachedDestination: false,
      feedbackMessage: null,
      selectedLocationId: null,
      missionSuccess: false,
      failureReason: null,
      earnedStars: 0,
    };
  }

  function createSpaceBaseEngine() {
    let config = null;
    const listeners = new Set();

    let state = {
      initialized: false,
      currentScreen: SCREENS.INITIAL,
      audioEnabled: true,
      exitModalOpen: false,
      sessionActive: false,
      sessionCount: 0,
      character: {
        hair: 'classic',
        suit: 'azure',
        emblem: 'saturn',
        gloves: 'ice',
        boots: 'cobalt',
        accessory: 'star_charm',
      },
      selectedDestination: null,
      activePlanetId: 'earth',
      activeExperimentId: null,
      modisMission: createFreshModisMissionState(),
      terrainMission: createFreshTerrainMissionState(null),
      experimentProgress: {},
      statusNotice: null,
      lastAction: null,
    };

    function getModisMissionConfig() {
      const items =
        (config &&
          config.screens &&
          config.screens.experiments &&
          config.screens.experiments.items) ||
        [];
      const mission1 = items.find(function (it) {
        return it.id === 1;
      });
      return mission1 && mission1.missionData ? mission1.missionData : null;
    }

    function getTerrainMissionConfig() {
      const items =
        (config &&
          config.screens &&
          config.screens.experiments &&
          config.screens.experiments.items) ||
        [];
      const mission3 = items.find(function (it) {
        return it.id === 3;
      });
      return mission3 && mission3.missionData ? mission3.missionData : null;
    }

    function computeModisHabitatTelemetry(installedLayers) {
      const missionData = getModisMissionConfig();
      const builder = missionData && missionData.habitatBuilder;
      if (!builder) {
        return {
          dayInternalC: 21,
          nightInternalC: 21,
          isDaySafe: true,
          isNightSafe: true,
          isFullyProtected: true,
        };
      }

      let dayTemp = builder.baseDayInternalC;
      let nightTemp = builder.baseNightInternalC;

      (installedLayers || []).forEach(function (layerId) {
        const layer = (builder.layers || []).find(function (l) {
          return l.id === layerId;
        });
        if (layer) {
          dayTemp += layer.dayDeltaC || 0;
          nightTemp += layer.nightDeltaC || 0;
        }
      });

      const isDaySafe = dayTemp >= builder.safeMinC && dayTemp <= builder.safeMaxC;
      const isNightSafe =
        nightTemp >= builder.safeMinC && nightTemp <= builder.safeMaxC;

      return {
        dayInternalC: dayTemp,
        nightInternalC: nightTemp,
        isDaySafe: isDaySafe,
        isNightSafe: isNightSafe,
        isFullyProtected: isDaySafe && isNightSafe,
      };
    }

    function notify() {
      const snapshot = getState();
      listeners.forEach(function (listener) {
        try {
          listener(snapshot);
        } catch (err) {
          console.error('[SpaceBaseEngine] Listener error:', err);
        }
      });
    }

    function init(loadedConfig) {
      config = loadedConfig || {};
      const defaultAudio =
        config.game && typeof config.game.defaultAudioEnabled === 'boolean'
          ? config.game.defaultAudioEnabled
          : true;

      const defaultCharacter =
        (config.screens &&
          config.screens.personalization &&
          config.screens.personalization.defaultCharacter) || {
          hair: 'classic',
          suit: 'azure',
          emblem: 'saturn',
          gloves: 'ice',
          boots: 'cobalt',
          accessory: 'star_charm',
        };

      state = {
        initialized: true,
        currentScreen: SCREENS.INITIAL,
        audioEnabled: defaultAudio,
        exitModalOpen: false,
        sessionActive: false,
        sessionCount: 0,
        character: Object.assign({}, defaultCharacter),
        selectedDestination: null,
        activePlanetId: 'earth',
        activeExperimentId: null,
        modisMission: createFreshModisMissionState(),
        terrainMission: createFreshTerrainMissionState(config),
        experimentProgress: createInitialProgress(config),
        statusNotice: null,
        lastAction: 'ENGINE_INITIALIZED',
      };
      notify();
      return getState();
    }

    function getState() {
      return {
        initialized: state.initialized,
        currentScreen: state.currentScreen,
        audioEnabled: state.audioEnabled,
        exitModalOpen: state.exitModalOpen,
        sessionActive: state.sessionActive,
        sessionCount: state.sessionCount,
        character: Object.assign({}, state.character),
        selectedDestination: state.selectedDestination,
        activePlanetId: state.activePlanetId,
        activeExperimentId: state.activeExperimentId,
        modisMission: JSON.parse(JSON.stringify(state.modisMission)),
        modisHabitatTelemetry: computeModisHabitatTelemetry(
          state.modisMission.installedLayers
        ),
        terrainMission: JSON.parse(JSON.stringify(state.terrainMission)),
        experimentProgress: JSON.parse(JSON.stringify(state.experimentProgress)),
        statusNotice: state.statusNotice,
        lastAction: state.lastAction,
      };
    }

    function subscribe(listener) {
      if (typeof listener !== 'function') {
        return function () {};
      }
      listeners.add(listener);
      listener(getState());
      return function unsubscribe() {
        listeners.delete(listener);
      };
    }

    function startGame() {
      state = Object.assign({}, state, {
        currentScreen: SCREENS.PERSONALIZATION,
        exitModalOpen: false,
        sessionActive: true,
        sessionCount: state.sessionCount + 1,
        statusNotice: null,
        lastAction: 'GAME_STARTED',
      });
      notify();
      return getState();
    }

    function updateCharacterPart(category, optionId) {
      if (!category || !optionId) return getState();
      const nextCharacter = Object.assign({}, state.character);
      nextCharacter[category] = optionId;

      state = Object.assign({}, state, {
        character: nextCharacter,
        lastAction: 'CHARACTER_UPDATED',
      });
      notify();
      return getState();
    }

    function randomizeCharacter() {
      const options =
        (config &&
          config.screens &&
          config.screens.personalization &&
          config.screens.personalization.options) ||
        {};
      const nextCharacter = Object.assign({}, state.character);

      Object.keys(options).forEach(function (category) {
        const list = options[category];
        if (Array.isArray(list) && list.length > 0) {
          const picked = list[Math.floor(Math.random() * list.length)];
          nextCharacter[category] = picked.id;
        }
      });

      state = Object.assign({}, state, {
        character: nextCharacter,
        lastAction: 'CHARACTER_RANDOMIZED',
      });
      notify();
      return getState();
    }

    function confirmPersonalization() {
      state = Object.assign({}, state, {
        currentScreen: SCREENS.DESTINATION,
        statusNotice: null,
        lastAction: 'PERSONALIZATION_CONFIRMED',
      });
      notify();
      return getState();
    }

    function selectDestination(destinationId) {
      const destinations =
        (config &&
          config.screens &&
          config.screens.destination &&
          config.screens.destination.destinations) ||
        [];
      const target = destinations.find(function (d) {
        return d.id === destinationId;
      });
      const planetId = target ? target.planetId : destinationId;

      const nextProgress = JSON.parse(JSON.stringify(state.experimentProgress));
      if (nextProgress[planetId]) {
        nextProgress[planetId].unlocked = true;
      }

      state = Object.assign({}, state, {
        selectedDestination: destinationId,
        activePlanetId: planetId || 'earth',
        experimentProgress: nextProgress,
        currentScreen: SCREENS.EXPERIMENTS,
        activeExperimentId: null,
        statusNotice: null,
        lastAction: 'DESTINATION_SELECTED',
      });
      notify();
      return getState();
    }

    function selectPlanet(planetId) {
      const planetState = state.experimentProgress[planetId];
      if (!planetState || !planetState.unlocked) {
        const msg =
          (config &&
            config.screens &&
            config.screens.experiments &&
            config.screens.experiments.lockedPlanetMessage) ||
          'Planeta bloqueado.';
        state = Object.assign({}, state, {
          statusNotice: msg,
          lastAction: 'PLANET_LOCKED',
        });
        notify();
        return getState();
      }

      state = Object.assign({}, state, {
        activePlanetId: planetId,
        activeExperimentId: null,
        statusNotice: null,
        lastAction: 'PLANET_SELECTED',
      });
      notify();
      return getState();
    }

    function openExperiment(experimentId) {
      const planetState = state.experimentProgress[state.activePlanetId] || {
        unlocked: true,
        unlockedUpTo: 3,
        starsByExperiment: {},
      };

      if (experimentId > planetState.unlockedUpTo) {
        const msg =
          (config &&
            config.screens &&
            config.screens.experiments &&
            config.screens.experiments.lockedExperimentMessage) ||
          'Experiência bloqueada.';
        state = Object.assign({}, state, {
          statusNotice: msg,
          lastAction: 'EXPERIMENT_LOCKED',
        });
        notify();
        return getState();
      }

      const nextModis =
        experimentId === 1
          ? createFreshModisMissionState()
          : state.modisMission;
      const nextTerrain =
        experimentId === 3
          ? createFreshTerrainMissionState(config)
          : state.terrainMission;

      state = Object.assign({}, state, {
        activeExperimentId: experimentId,
        modisMission: nextModis,
        terrainMission: nextTerrain,
        statusNotice: null,
        lastAction: 'EXPERIMENT_OPENED',
      });
      notify();
      return getState();
    }

    function closeExperiment() {
      state = Object.assign({}, state, {
        activeExperimentId: null,
        lastAction: 'EXPERIMENT_CLOSED',
      });
      notify();
      return getState();
    }

    /* MODIS Mission 1 Methods */
    function setModisTimeOfDay(timeOfDay) {
      const nextTime = timeOfDay === 'night' ? 'night' : 'day';
      const nextModis = Object.assign({}, state.modisMission, {
        timeOfDay: nextTime,
      });

      state = Object.assign({}, state, {
        modisMission: nextModis,
        lastAction: 'MODIS_TIME_CHANGED',
      });
      notify();
      return getState();
    }

    function inspectModisRegion(regionId) {
      if (!regionId) return getState();
      const nextModis = JSON.parse(JSON.stringify(state.modisMission));
      if (!nextModis.inspectedObservations[regionId]) {
        nextModis.inspectedObservations[regionId] = { day: false, night: false };
      }
      nextModis.inspectedObservations[regionId][nextModis.timeOfDay] = true;

      state = Object.assign({}, state, {
        modisMission: nextModis,
        lastAction: 'MODIS_REGION_INSPECTED',
      });
      notify();
      return getState();
    }

    function setModisStep(stepNumber) {
      const clamped = Math.max(1, Math.min(4, stepNumber || 1));
      const nextModis = Object.assign({}, state.modisMission, {
        step: clamped,
      });
      state = Object.assign({}, state, {
        modisMission: nextModis,
        lastAction: 'MODIS_STEP_CHANGED',
      });
      notify();
      return getState();
    }

    function answerModisComparison(questionId, optionId) {
      const missionData = getModisMissionConfig();
      const questions = (missionData && missionData.comparisonQuestions) || [];
      const question = questions.find(function (q) {
        return q.id === questionId;
      });
      if (!question) return getState();

      const option = (question.options || []).find(function (o) {
        return o.id === optionId;
      });
      if (!option) return getState();

      const nextModis = JSON.parse(JSON.stringify(state.modisMission));
      const prevEntry = nextModis.comparisonAnswers[questionId] || {
        attempts: 0,
        correct: false,
      };
      if (prevEntry.correct) return getState();

      const isCorrect = Boolean(option.correct);
      nextModis.comparisonAnswers[questionId] = {
        selectedId: optionId,
        correct: isCorrect,
        attempts: prevEntry.attempts + 1,
      };

      if (!isCorrect) {
        nextModis.mistakes += 1;
      }

      state = Object.assign({}, state, {
        modisMission: nextModis,
        lastAction: isCorrect ? 'MODIS_QUESTION_CORRECT' : 'MODIS_QUESTION_WRONG',
      });
      notify();
      return getState();
    }

    function toggleHabitatLayer(layerId) {
      const missionData = getModisMissionConfig();
      const layers =
        (missionData &&
          missionData.habitatBuilder &&
          missionData.habitatBuilder.layers) ||
        [];
      const layer = layers.find(function (l) {
        return l.id === layerId;
      });
      if (!layer) return getState();

      const nextModis = JSON.parse(JSON.stringify(state.modisMission));
      const idx = nextModis.installedLayers.indexOf(layerId);
      if (idx >= 0) {
        nextModis.installedLayers.splice(idx, 1);
      } else {
        nextModis.installedLayers.push(layerId);
        if (!layer.isThermal) {
          nextModis.mistakes += 1;
        }
      }

      state = Object.assign({}, state, {
        modisMission: nextModis,
        lastAction: 'MODIS_LAYER_TOGGLED',
      });
      notify();
      return getState();
    }

    function validateModisHabitat() {
      const telemetry = computeModisHabitatTelemetry(
        state.modisMission.installedLayers
      );
      if (!telemetry.isFullyProtected) {
        return getState();
      }

      const mistakes = state.modisMission.mistakes || 0;
      const earnedStars = mistakes === 0 ? 3 : mistakes <= 2 ? 2 : 1;

      const nextModis = Object.assign({}, state.modisMission, {
        step: 4,
        completedStars: earnedStars,
      });

      state = Object.assign({}, state, {
        modisMission: nextModis,
        lastAction: 'MODIS_HABITAT_VALIDATED',
      });
      notify();
      return getState();
    }

    function finishModisMission() {
      const stars = state.modisMission.completedStars || 3;
      return completeExperiment(1, stars);
    }

    /* Terrain Explorer Mission 3 Methods */
    function startTerrainMission() {
      const fresh = createFreshTerrainMissionState(config);
      fresh.phase = 'EXPLORING';
      state = Object.assign({}, state, {
        terrainMission: fresh,
        lastAction: 'TERRAIN_MISSION_STARTED',
      });
      notify();
      return getState();
    }

    function restartTerrainMission() {
      return startTerrainMission();
    }

    function toggleTerrainInstructions(isOpen) {
      const nextTerrain = Object.assign({}, state.terrainMission, {
        instructionsOpen: Boolean(isOpen),
      });
      state = Object.assign({}, state, {
        terrainMission: nextTerrain,
      });
      notify();
      return getState();
    }

    function dismissLowBatteryModal() {
      const nextTerrain = Object.assign({}, state.terrainMission, {
        lowBatteryModalOpen: false,
      });
      state = Object.assign({}, state, {
        terrainMission: nextTerrain,
      });
      notify();
      return getState();
    }

    function applyBatteryDrainAndCheck(tm, delta, missionData) {
      const nextBattery = Math.max(0, Math.min(100, tm.battery + delta));
      tm.battery = nextBattery;

      const lowThresh =
        (missionData && missionData.grid && missionData.grid.lowBatteryThreshold) ||
        25;
      if (nextBattery > 0 && nextBattery <= lowThresh && !tm.lowBatteryWarningShown) {
        tm.lowBatteryWarningShown = true;
        tm.lowBatteryModalOpen = true;
      }

      if (nextBattery <= 0) {
        tm.phase = 'RESULTS';
        tm.missionSuccess = false;
        tm.failureReason =
          (missionData &&
            missionData.results &&
            missionData.results.batteryDepletedReason) ||
          'Bateria esgotada.';
        tm.earnedStars = 0;
        tm.activeChallenge = null;
        tm.pendingTarget = null;
      }
    }

    function moveTerrainRover(direction) {
      const missionData = getTerrainMissionConfig();
      if (!missionData || !missionData.grid) return getState();

      const tm = JSON.parse(JSON.stringify(state.terrainMission));
      if (
        tm.phase !== 'EXPLORING' ||
        tm.activeChallenge ||
        tm.lowBatteryModalOpen
      ) {
        return getState();
      }

      const dirs = {
        up: { dx: 0, dy: -1 },
        down: { dx: 0, dy: 1 },
        left: { dx: -1, dy: 0 },
        right: { dx: 1, dy: 0 },
      };
      const delta = dirs[direction];
      if (!delta) return getState();

      tm.rover.facing = direction;

      const nx = tm.rover.x + delta.dx;
      const ny = tm.rover.y + delta.dy;
      const grid = missionData.grid;

      if (nx < 0 || nx >= grid.cols || ny < 0 || ny >= grid.rows) {
        tm.feedbackMessage = 'Limite da área mapeada! Escolhe outra direção.';
        state = Object.assign({}, state, { terrainMission: tm });
        notify();
        return getState();
      }

      const cell = grid.cells[ny][nx];
      if (!cell) return getState();

      if (cell.type === 'rock_obstacle') {
        tm.feedbackMessage = 'Rocha gigante bloqueia o caminho! Contorna este obstáculo.';
        state = Object.assign({}, state, {
          terrainMission: tm,
          lastAction: 'ROVER_BLOCKED',
        });
        notify();
        return getState();
      }

      const cellKey = nx + ',' + ny;
      const alreadyResolved = tm.resolvedChallenges.indexOf(cellKey) >= 0;

      if (
        (cell.type === 'rock_challenge' || cell.type === 'slope_challenge') &&
        !alreadyResolved
      ) {
        tm.activeChallenge = cell.type;
        tm.pendingTarget = { x: nx, y: ny, cell: cell };
        state = Object.assign({}, state, {
          terrainMission: tm,
          lastAction: 'TERRAIN_CHALLENGE_TRIGGERED',
        });
        notify();
        return getState();
      }

      // Move rover to target cell
      tm.rover.x = nx;
      tm.rover.y = ny;

      const isNewCell = tm.visitedCells.indexOf(cellKey) < 0;
      if (isNewCell) {
        tm.visitedCells.push(cellKey);
        tm.score += 10;
      }

      const moveCost = -(grid.moveBatteryCost || 3);
      applyBatteryDrainAndCheck(tm, moveCost, missionData);

      if (tm.phase === 'RESULTS') {
        state = Object.assign({}, state, { terrainMission: tm });
        notify();
        return getState();
      }

      if (
        cell.type === 'sample' &&
        tm.samplesCollected.indexOf(cell.sampleId) < 0
      ) {
        tm.activeChallenge = 'sample';
        tm.pendingTarget = { x: nx, y: ny, cell: cell };
      } else if (cell.type === 'destination') {
        tm.reachedDestination = true;
        tm.score += 40;
        tm.phase = 'LOCATION_SELECT';
        tm.feedbackMessage =
          'Chegaste à zona de inspeção! Escolhe agora o local ideal para a base.';
      } else {
        tm.feedbackMessage =
          'Setor (' + (nx + 1) + ', ' + (ny + 1) + ') · Elevação ' + cell.elevationM + ' m.';
      }

      state = Object.assign({}, state, {
        terrainMission: tm,
        lastAction: 'ROVER_MOVED',
      });
      notify();
      return getState();
    }

    function resolveTerrainChallenge(optionId) {
      const missionData = getTerrainMissionConfig();
      if (!missionData) return getState();

      const tm = JSON.parse(JSON.stringify(state.terrainMission));
      if (!tm.activeChallenge || !tm.pendingTarget) return getState();

      const chType = tm.activeChallenge;
      const chCfg = missionData.challenges && missionData.challenges[chType];
      if (!chCfg) return getState();

      const target = tm.pendingTarget;
      const cellKey = target.x + ',' + target.y;

      if (chType === 'sample') {
        if (tm.samplesCollected.indexOf(target.cell.sampleId) < 0) {
          tm.samplesCollected.push(target.cell.sampleId);
        }
        tm.score += chCfg.scoreDelta || 50;
        tm.feedbackMessage = chCfg.feedback;
        tm.activeChallenge = null;
        tm.pendingTarget = null;
        applyBatteryDrainAndCheck(tm, chCfg.batteryDelta || -2, missionData);

        state = Object.assign({}, state, {
          terrainMission: tm,
          lastAction: 'SAMPLE_COLLECTED',
        });
        notify();
        return getState();
      }

      const chosen = (chCfg.options || []).find(function (o) {
        return o.id === optionId;
      });
      if (!chosen) return getState();

      tm.score += chosen.scoreDelta || 0;
      tm.feedbackMessage = chosen.feedback;

      if (chosen.allowMove) {
        tm.rover.x = target.x;
        tm.rover.y = target.y;
        if (tm.visitedCells.indexOf(cellKey) < 0) {
          tm.visitedCells.push(cellKey);
        }
        if (tm.resolvedChallenges.indexOf(cellKey) < 0) {
          tm.resolvedChallenges.push(cellKey);
        }
      }

      tm.activeChallenge = null;
      tm.pendingTarget = null;
      applyBatteryDrainAndCheck(tm, chosen.batteryDelta || 0, missionData);

      state = Object.assign({}, state, {
        terrainMission: tm,
        lastAction: 'TERRAIN_CHALLENGE_RESOLVED',
      });
      notify();
      return getState();
    }

    function openBaseLocationSelection() {
      const tm = Object.assign({}, state.terrainMission, {
        phase: 'LOCATION_SELECT',
      });
      state = Object.assign({}, state, { terrainMission: tm });
      notify();
      return getState();
    }

    function selectBaseLocation(locationId) {
      const missionData = getTerrainMissionConfig();
      if (!missionData || !missionData.baseLocations) return getState();

      const locations = missionData.baseLocations.locations || [];
      const chosen = locations.find(function (l) {
        return l.id === locationId;
      });
      if (!chosen) return getState();

      const tm = JSON.parse(JSON.stringify(state.terrainMission));
      tm.selectedLocationId = locationId;
      tm.score += chosen.bonusScore || 0;
      tm.phase = 'RESULTS';

      if (chosen.suitable) {
        tm.missionSuccess = true;
        tm.failureReason = null;
        const stars =
          chosen.id === 'loc_a' && tm.samplesCollected.length >= 2
            ? 3
            : chosen.id === 'loc_a'
              ? 2
              : 2;
        tm.earnedStars = stars;
      } else {
        tm.missionSuccess = false;
        tm.failureReason =
          (missionData.results && missionData.results.unsuitableSiteReason) ||
          chosen.analysis;
        tm.earnedStars = 0;
      }

      state = Object.assign({}, state, {
        terrainMission: tm,
        lastAction: 'BASE_LOCATION_SELECTED',
      });
      notify();
      return getState();
    }

    function finishTerrainMission() {
      const tm = state.terrainMission;
      if (tm.missionSuccess) {
        return completeExperiment(3, tm.earnedStars || 2);
      }
      return closeExperiment();
    }

    function completeExperiment(experimentId, earnedStars) {
      const planetId = state.activePlanetId;
      const nextProgress = JSON.parse(JSON.stringify(state.experimentProgress));
      if (!nextProgress[planetId]) {
        nextProgress[planetId] = {
          unlocked: true,
          unlockedUpTo: 3,
          starsByExperiment: {},
        };
      }

      const currentStars = nextProgress[planetId].starsByExperiment[experimentId] || 0;
      const clampedStars = Math.max(1, Math.min(3, earnedStars || 3));
      nextProgress[planetId].starsByExperiment[experimentId] = Math.max(
        currentStars,
        clampedStars
      );

      const totalItems =
        (config &&
          config.screens &&
          config.screens.experiments &&
          Array.isArray(config.screens.experiments.items) &&
          config.screens.experiments.items.length) ||
        6;

      if (
        experimentId >= nextProgress[planetId].unlockedUpTo &&
        nextProgress[planetId].unlockedUpTo < totalItems
      ) {
        nextProgress[planetId].unlockedUpTo = experimentId + 1;
      }

      state = Object.assign({}, state, {
        experimentProgress: nextProgress,
        activeExperimentId: null,
        statusNotice: null,
        lastAction: 'EXPERIMENT_COMPLETED',
      });
      notify();
      return getState();
    }

    function goToScreen(screenName) {
      if (!SCREENS[screenName]) return getState();
      state = Object.assign({}, state, {
        currentScreen: SCREENS[screenName],
        activeExperimentId: null,
        statusNotice: null,
        exitModalOpen: false,
        lastAction: 'NAVIGATED_TO_' + screenName,
      });
      notify();
      return getState();
    }

    function clearNotice() {
      state = Object.assign({}, state, {
        statusNotice: null,
      });
      notify();
      return getState();
    }

    function requestExit() {
      state = Object.assign({}, state, {
        exitModalOpen: true,
        lastAction: 'EXIT_REQUESTED',
      });
      notify();
      return getState();
    }

    function cancelExit() {
      state = Object.assign({}, state, {
        exitModalOpen: false,
        lastAction: 'EXIT_CANCELLED',
      });
      notify();
      return getState();
    }

    function confirmExit() {
      state = Object.assign({}, state, {
        currentScreen: SCREENS.EXITED,
        exitModalOpen: false,
        sessionActive: false,
        lastAction: 'GAME_EXITED',
      });
      notify();
      return getState();
    }

    function returnToInitialScreen() {
      state = Object.assign({}, state, {
        currentScreen: SCREENS.INITIAL,
        exitModalOpen: false,
        activeExperimentId: null,
        statusNotice: null,
        sessionActive: false,
        lastAction: 'RETURNED_TO_INITIAL',
      });
      notify();
      return getState();
    }

    function toggleAudio() {
      state = Object.assign({}, state, {
        audioEnabled: !state.audioEnabled,
        lastAction: state.audioEnabled ? 'AUDIO_MUTED' : 'AUDIO_ENABLED',
      });
      notify();
      return getState();
    }

    return {
      SCREENS: SCREENS,
      init: init,
      getState: getState,
      subscribe: subscribe,
      startGame: startGame,
      updateCharacterPart: updateCharacterPart,
      randomizeCharacter: randomizeCharacter,
      confirmPersonalization: confirmPersonalization,
      selectDestination: selectDestination,
      selectPlanet: selectPlanet,
      openExperiment: openExperiment,
      closeExperiment: closeExperiment,
      setModisTimeOfDay: setModisTimeOfDay,
      inspectModisRegion: inspectModisRegion,
      setModisStep: setModisStep,
      answerModisComparison: answerModisComparison,
      toggleHabitatLayer: toggleHabitatLayer,
      validateModisHabitat: validateModisHabitat,
      finishModisMission: finishModisMission,
      startTerrainMission: startTerrainMission,
      restartTerrainMission: restartTerrainMission,
      toggleTerrainInstructions: toggleTerrainInstructions,
      dismissLowBatteryModal: dismissLowBatteryModal,
      moveTerrainRover: moveTerrainRover,
      resolveTerrainChallenge: resolveTerrainChallenge,
      openBaseLocationSelection: openBaseLocationSelection,
      selectBaseLocation: selectBaseLocation,
      finishTerrainMission: finishTerrainMission,
      completeExperiment: completeExperiment,
      goToScreen: goToScreen,
      clearNotice: clearNotice,
      requestExit: requestExit,
      cancelExit: cancelExit,
      confirmExit: confirmExit,
      returnToInitialScreen: returnToInitialScreen,
      toggleAudio: toggleAudio,
    };
  }

  global.SpaceBaseEngine = createSpaceBaseEngine();
})(window);
