export const SPACE_CALLING_SCREENS = [
  { id: 1, label: '1. Sala de Controlo' },
  { id: 2, label: '2. Laboratório Terra' },
  { id: 3, label: '3. Experiências' },
  { id: 4, label: '4. Preparação' },
];

export const INITIAL_SPACE_CALLING_STATE = {
  screen: 1,
  inspectedStations: [],
  activeLayers: ['modis'],
  exploredLayers: ['modis'],
  selectedRegionId: 'amazon',
  compareRegionId: 'sahara',
  exploredRegions: ['amazon'],
  globeRotationLon: 0,
  globeZoom: 1,
  experimentsCompleted: {
    tempDetective: false,
    terrainExplorer: false,
    waterInvestigator: false,
    atmosphereObserver: false,
  },
  score: 0,
};

export const MISSION_BADGES = [
  {
    id: 'orbital_observer',
    title: 'Observador Orbital',
    description: 'Explorou os 5 conjuntos de dados NASA Earthdata no globo interativo.',
  },
  {
    id: 'science_detective',
    title: 'Detetive Científico',
    description: 'Completou todas as experiências práticas de temperatura, relevo, água e atmosfera.',
  },
  {
    id: 'expedition_ready',
    title: 'Pronto para a Expedição',
    description: 'Concluiu o treino científico antes da viagem espacial!',
  },
];

export function getDestinationLabel(destinationId) {
  if (destinationId === 'mars') return 'Marte';
  return 'Lua';
}

export function computeSpaceCallingStars(state) {
  const expsDone = Object.values(state.experimentsCompleted || {}).filter(Boolean).length;
  const layersDone = (state.exploredLayers || []).length;
  if (expsDone === 4 && layersDone >= 4) return 3;
  if (expsDone >= 2) return 2;
  return 1;
}
