export const RAINFALL_STEPS = [
  { id: 1, label: '1. Briefing' },
  { id: 2, label: '2. Mapa & Chuva' },
  { id: 3, label: '3. Desafios' },
  { id: 4, label: '4. Resultados' },
];

export const RAINFALL_CHALLENGES = [
  {
    id: 'challenge_a',
    title: 'Desafio A — Onde Chove Mais?',
    prompt:
      'No mês de julho (segundo os dados ilustrativos GPM_3IMERGM), qual destas três regiões recebe MAIS precipitação?',
    options: [
      { id: 'monsoon_asia', label: 'Sudeste Asiático — Monção (360 mm)', correct: true },
      { id: 'central_europe', label: 'Europa Central (82 mm)', correct: false },
      { id: 'atacama', label: 'Deserto do Atacama (2 mm)', correct: false },
    ],
    feedbackCorrect:
      'Correto! Em julho, os ventos de monção trazem chuvas muito intensas para o Sudeste Asiático (360 mm).',
    feedbackWrong:
      'Compara os valores de julho: procura a região com o maior número de milímetros de chuva!',
  },
  {
    id: 'challenge_b',
    title: 'Desafio B — Gestão de Recursos Hídricos',
    prompt:
      'A equipa quer estudar a recolha de água da chuva num local com boa disponibilidade hídrica durante todo o ano. Qual é a opção mais equilibrada — e o que devemos lembrar?',
    options: [
      {
        id: 'atacama_only',
        label: 'Deserto do Atacama, porque não há nuvens.',
        correct: false,
      },
      {
        id: 'europe_balanced',
        label: 'Europa Central ou Bacia Amazónica — lembrando que chuva alta não garante por si só água potável.',
        correct: true,
      },
      {
        id: 'rain_equals_clean',
        label: 'Qualquer região com chuva forte tem automaticamente água limpa pronta a beber.',
        correct: false,
      },
    ],
    feedbackCorrect:
      'Excelente análise! Precipitação, disponibilidade de água e recursos hídricos são conceitos diferentes: a água da chuva precisa de captação, armazenamento e tratamento.',
    feedbackWrong:
      'Atenção! Muita chuva não significa automaticamente água potável acessível — e um deserto quase não tem chuva para recolher.',
  },
  {
    id: 'challenge_c',
    title: 'Desafio C — Mudanças Sazonais',
    prompt:
      'Observa o gráfico mensal do Sudeste Asiático e da Savana do Sahel. Como varia a precipitação ao longo do ano?',
    options: [
      {
        id: 'constant',
        label: 'Chove exatamente a mesma quantidade em todos os meses.',
        correct: false,
      },
      {
        id: 'july_peak',
        label: 'Muda conforme as estações: o pico de chuva ocorre em julho e reduz-se bastante em janeiro.',
        correct: true,
      },
      {
        id: 'mars_rain',
        label: 'Estes dados GPM medem tempestades de chuva em Marte.',
        correct: false,
      },
    ],
    feedbackCorrect:
      'Muito bem! Os satélites GPM mostram como a precipitação muda entre estações secas e húmidas na Terra.',
    feedbackWrong:
      'Olha para as barras de Janeiro e Julho no gráfico sazonal e lembra-te que o GPM observa apenas a Terra!',
  },
];

export const INITIAL_RAINFALL_STATE = {
  step: 1,
  selectedMonthId: 'jul',
  selectedRegionId: 'amazon',
  compareRegionId: 'central_europe',
  exploredRegions: ['amazon'],
  exploredMonths: ['jul'],
  recommendedRegionId: null,
  challengeAnswers: {},
  score: 0,
  mistakes: 0,
  completed: false,
};

export function getIntensityLevel(mm) {
  if (mm >= 180) return { id: 'high', label: 'Precipitação Alta', color: '#2563eb' };
  if (mm >= 55) return { id: 'moderate', label: 'Precipitação Moderada', color: '#0ea5e9' };
  return { id: 'low', label: 'Precipitação Baixa', color: '#f59e0b' };
}

export function computeRainfallReport(state, regions) {
  const recRegion = regions.find((r) => r.id === state.recommendedRegionId);
  const solvedCount = RAINFALL_CHALLENGES.filter(
    (c) => state.challengeAnswers[c.id]?.correct
  ).length;

  let starRating = 1;
  if (solvedCount === 3 && recRegion?.suitableForStudy && state.mistakes <= 1) {
    starRating = 3;
  } else if (solvedCount >= 2) {
    starRating = 2;
  }

  return {
    score: state.score,
    exploredRegionsCount: state.exploredRegions.length,
    exploredMonthsCount: state.exploredMonths.length,
    solvedChallenges: solvedCount,
    totalChallenges: RAINFALL_CHALLENGES.length,
    recommendedRegion: recRegion,
    starRating,
  };
}
