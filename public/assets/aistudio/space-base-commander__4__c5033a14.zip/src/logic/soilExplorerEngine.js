export const SOIL_STEPS = [
  { id: 1, label: '1. Briefing' },
  { id: 2, label: '2. Satélite' },
  { id: 3, label: '3. Análise' },
  { id: 4, label: '4. Desafio' },
];

export const SOIL_SCIENTIFIC_INFO = {
  missionName: 'AstroBase – Explorador da Humidade do Solo',
  smapFullName: 'SMAP (Soil Moisture Active Passive)',
  earthOnlyNote:
    'Informação científica: O satélite SMAP da NASA estuda a humidade do solo apenas na Terra através de sensores de micro-ondas. Não mede água ou gelo na Lua nem em Marte.',
  simulatedDataNote:
    'Nota educativa: Os valores apresentados são exemplos simulados para aprendizagem, não sendo medições reais em tempo real da NASA.',
  explanation:
    'A humidade do solo indica a quantidade de água existente na camada superficial da terra. O satélite SMAP da NASA utiliza sensores de micro-ondas para estudar esta característica.',
};

export const SOIL_COLOR_LEGEND = [
  {
    id: 'blue',
    label: 'Azul',
    meaning: 'Maior quantidade de humidade',
    swatch: '#2563eb',
    borderClass: 'border-blue-400 bg-blue-500/20 text-blue-200',
  },
  {
    id: 'green',
    label: 'Verde',
    meaning: 'Humidade moderada',
    swatch: '#16a34a',
    borderClass: 'border-emerald-400 bg-emerald-500/20 text-emerald-200',
  },
  {
    id: 'yellow',
    label: 'Amarelo',
    meaning: 'Pouca humidade',
    swatch: '#eab308',
    borderClass: 'border-yellow-400 bg-yellow-500/20 text-yellow-200',
  },
  {
    id: 'red',
    label: 'Vermelho',
    meaning: 'Solo muito seco',
    swatch: '#dc2626',
    borderClass: 'border-rose-400 bg-rose-500/20 text-rose-200',
  },
];

export const SOIL_REGIONS = [
  {
    id: 'region_a',
    code: 'Região A',
    landscape: 'Zona Árida e Arenosa',
    x: 53,
    y: 42,
    moisturePct: 8,
    statusLabel: 'Solo muito seco.',
    colorName: 'Vermelho',
    hex: '#ef4444',
    cardClass: 'border-rose-400 bg-gradient-to-b from-rose-950/85 to-red-950/90',
    badgeClass: 'bg-rose-500 text-white',
    barClass: 'from-red-500 to-rose-400',
    hint: 'Terreno quente com areia solta e quase sem chuva.',
  },
  {
    id: 'region_b',
    code: 'Região B',
    landscape: 'Planície Agrícola Temperada',
    x: 49,
    y: 25,
    moisturePct: 32,
    statusLabel: 'Solo com humidade moderada.',
    colorName: 'Verde',
    hex: '#22c55e',
    cardClass: 'border-emerald-400 bg-gradient-to-b from-emerald-950/85 to-green-950/90',
    badgeClass: 'bg-emerald-500 text-slate-950',
    barClass: 'from-emerald-500 to-green-400',
    hint: 'Campos verdes com chuvas equilibradas ao longo do ano.',
  },
  {
    id: 'region_c',
    code: 'Região C',
    landscape: 'Floresta Tropical Húmida',
    x: 31,
    y: 60,
    moisturePct: 45,
    statusLabel: 'Solo bastante húmido.',
    colorName: 'Azul',
    hex: '#3b82f6',
    cardClass: 'border-blue-400 bg-gradient-to-b from-blue-950/85 to-indigo-950/90',
    badgeClass: 'bg-blue-500 text-white',
    barClass: 'from-blue-500 to-sky-400',
    hint: 'Solo rico e fértil que absorve bastante água das chuvas tropicais.',
  },
];

export const SOIL_EDU_CARDS = [
  {
    id: 'satellite',
    title: 'Satélite',
    text: 'Observa diferentes regiões da Terra.',
    accentClass: 'border-sky-300 bg-sky-500/15 text-sky-200',
  },
  {
    id: 'microwaves',
    title: 'Micro-ondas',
    text: 'Os sensores recebem sinais naturais emitidos pela superfície terrestre.',
    accentClass: 'border-amber-300 bg-amber-500/15 text-amber-200',
  },
  {
    id: 'soil_moisture',
    title: 'Humidade do solo',
    text: 'Os cientistas utilizam os dados para estimar a quantidade de água existente no solo.',
    accentClass: 'border-emerald-300 bg-emerald-500/15 text-emerald-200',
  },
];

export const SOIL_CHALLENGES = [
  {
    id: 'q1',
    prompt: 'Qual das regiões apresenta a maior quantidade de humidade no solo?',
    options: [
      { id: 'region_a', label: 'Região A', correct: false },
      { id: 'region_b', label: 'Região B', correct: false },
      { id: 'region_c', label: 'Região C', correct: true },
    ],
    feedbackCorrect:
      'Fantástico, pequeno cientista! A Região C tem 45% de humidade (cor azul) — é a região com o solo mais húmido!',
    feedbackWrong:
      'Quase! Repara nos resultados simulados: a Região A tem 8% (vermelho, muito seco) e a Região B tem 32% (verde, moderado). Procura a região azul com 45%! Tenta novamente.',
  },
  {
    id: 'q2',
    prompt: 'Como é que o satélite SMAP da NASA estuda a humidade do solo na Terra?',
    options: [
      { id: 'microwaves', label: 'Com sensores de micro-ondas que lêem sinais naturais da Terra', correct: true },
      { id: 'mars_rocks', label: 'A recolher rochas em Marte', correct: false },
      { id: 'moon_ice', label: 'A medir crateras na Lua', correct: false },
    ],
    feedbackCorrect:
      'Brilhante! O satélite SMAP (Soil Moisture Active Passive) usa sensores de micro-ondas para estudar o solo da Terra.',
    feedbackWrong:
      'Atenção à ciência! O satélite SMAP observa apenas a Terra utilizando sensores de micro-ondas naturais. Tenta outra vez!',
  },
];

export const INITIAL_SOIL_EXPLORER_STATE = {
  step: 1,
  selectedRegionId: null,
  observedRegions: [],
  isScanning: false,
  lastObservedMessage: null,
  answers: {},
  firstTryCorrectCount: 0,
  wrongAttempts: 0,
  score: 0,
  quizCompleted: false,
};

export function computeSoilStars(state) {
  if (state.wrongAttempts === 0 && state.observedRegions.length === 3) return 3;
  if (state.wrongAttempts <= 2 && state.observedRegions.length === 3) return 2;
  return 1;
}
