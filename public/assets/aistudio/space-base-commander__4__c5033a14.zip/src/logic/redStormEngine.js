export const MAX_ENERGY_PRODUCTION = 100;
export const PHASE4_BUDGET = 7;

export const BASE_SYSTEMS = [
  {
    id: 'life_support',
    name: 'LIFE SUPPORT',
    description: 'Keeps the crew safe with breathable air and warm habitats.',
    cost: 4,
    essential: true,
  },
  {
    id: 'communication',
    name: 'COMMUNICATION',
    description: 'Maintains communication with mission control and weather alerts.',
    cost: 2,
    essential: true,
  },
  {
    id: 'research_lab',
    name: 'RESEARCH LAB',
    description: 'Allows scientific experiments to continue during the storm.',
    cost: 3,
    essential: false,
  },
  {
    id: 'entertainment',
    name: 'ENTERTAINMENT',
    description: 'Provides recreational activities for off-duty crew members.',
    cost: 1,
    essential: false,
  },
];

export const PANEL_TOOLS = [
  {
    id: 'dust_cover',
    name: 'Protective Dust Shield',
    description: 'Prevents thick Martian dust from scratching the solar glass.',
    isCorrect: true,
  },
  {
    id: 'wind_anchors',
    name: 'Heavy Wind Anchors',
    description: 'Locks solar panel frames safely against strong storm gusts.',
    isCorrect: true,
  },
  {
    id: 'cleaning_brush',
    name: 'Automated Sweeper Brush',
    description: 'Clears settled dust particles off the panel surface.',
    isCorrect: true,
  },
  {
    id: 'water_hose',
    name: 'Garden Water Hose',
    description: 'Water would freeze instantly on Mars and damage electronics!',
    isCorrect: false,
  },
];

export const REPAIR_COMPONENTS = [
  {
    id: 'solar_cell',
    name: 'Solar Cell Module',
    slotLabel: 'Slot 1: Light Collector',
    hint: 'Captures sunlight and turns it into electricity.',
  },
  {
    id: 'power_cable',
    name: 'Power Conduit Cable',
    slotLabel: 'Slot 2: Energy Transfer',
    hint: 'Carries electricity safely into the base batteries.',
  },
  {
    id: 'dust_seal',
    name: 'Dust Filter Seal',
    slotLabel: 'Slot 3: Dust Protection',
    hint: 'Blocks Martian dust from entering the panel joints.',
  },
];

export const EMERGENCY_PRIORITY_ITEMS = [
  {
    id: 'crew_life_support',
    label: 'Protect the crew and maintain life support.',
    correctRank: 1,
  },
  {
    id: 'preserve_essential_energy',
    label: 'Preserve energy for essential systems.',
    correctRank: 2,
  },
  {
    id: 'continue_experiments',
    label: 'Continue scientific experiments.',
    correctRank: 3,
  },
];

export const INITIAL_RED_STORM_STATE = {
  currentPhase: 1,
  power: 80,
  oxygen: 90,
  protection: 85,
  dustLevel: 0,
  lightFactor: 1.0,
  stormPhase: 'calm',
  batteryLevel: 60,
  solarPanelEfficiency: 100,
  researchProgress: 0,
  crewSafety: 100,
  scientificKnowledge: 0,
  inspectedSystems: [],
  threatSolved: false,
  threatAttempts: 0,
  dustLabSolved: false,
  dustLabAttempts: 0,
  inspectedRegions: [],
  batteriesCharged: false,
  selectedTools: [],
  panelProtectionDone: false,
  activeSystems: ['life_support'],
  phase5Decision: null,
  priorityOrder: [
    'continue_experiments',
    'crew_life_support',
    'preserve_essential_energy',
  ],
  prioritiesSolved: false,
  repairedSlots: [],
  repairSolved: false,
  decisions: [],
  completedTasks: [],
  unlockedRewards: [],
  missionCompleted: false,
};

export function computeEnergyProduced(lightFactor, panelEfficiency) {
  return Math.round(
    MAX_ENERGY_PRODUCTION *
      Math.max(0.05, Math.min(1, lightFactor)) *
      (Math.max(10, Math.min(100, panelEfficiency)) / 100)
  );
}

export function calculateActiveSystemsCost(activeSystems) {
  return (activeSystems || []).reduce((sum, sysId) => {
    const sys = BASE_SYSTEMS.find((s) => s.id === sysId);
    return sum + (sys ? sys.cost : 0);
  }, 0);
}

export function applyPhase5Decision(state, optionId) {
  const hasLifeSupport = state.activeSystems.includes('life_support');
  const hasComms = state.activeSystems.includes('communication');
  const hasProtectedPanels = state.panelProtectionDone;
  const wellCharged = state.batteryLevel >= 80;

  let nextPower = state.power;
  let nextBattery = state.batteryLevel;
  let nextEfficiency = state.solarPanelEfficiency;
  let nextProtection = state.protection;
  let nextCrewSafety = state.crewSafety;
  let nextResearch = state.researchProgress;
  let consequenceSummary = '';

  if (optionId === 'use_batteries') {
    const drain = hasLifeSupport ? 32 : 42;
    nextBattery = Math.max(12, state.batteryLevel - drain);
    nextPower = wellCharged ? 55 : 38;
    nextCrewSafety = Math.min(100, state.crewSafety + (hasLifeSupport ? 0 : -15));
    nextResearch = Math.min(100, state.researchProgress + 10);
    consequenceSummary = wellCharged
      ? 'Your charged batteries kept essential systems running smoothly, though battery reserves dropped!'
      : 'Your batteries supplied immediate power, but because reserves were not fully charged, energy is now critical!';
  } else if (optionId === 'send_rover') {
    const recovery = hasProtectedPanels ? 24 : 12;
    nextEfficiency = Math.min(100, state.solarPanelEfficiency + recovery);
    nextBattery = Math.max(15, state.batteryLevel - 20);
    nextProtection = Math.max(40, state.protection - (hasProtectedPanels ? 6 : 16));
    nextPower = computeEnergyProduced(0.45, nextEfficiency);
    nextCrewSafety = Math.min(100, state.crewSafety + (hasComms ? 0 : -10));
    consequenceSummary = hasProtectedPanels
      ? 'Because you protected the solar panels earlier, the rover quickly swept away loose dust and boosted energy production!'
      : 'The rover braved the storm to clean the unprotected panels, recovering some energy at the cost of extra battery and wear.';
  } else {
    // power_saving
    nextBattery = Math.max(25, state.batteryLevel - 14);
    nextPower = 48;
    nextResearch = Math.max(10, state.researchProgress - 10);
    nextCrewSafety = Math.min(100, state.crewSafety + (hasLifeSupport ? 2 : -10));
    consequenceSummary =
      'Power-saving mode shut down non-essential labs to protect battery reserves, pausing some science experiments.';
  }

  return {
    ...state,
    power: nextPower,
    batteryLevel: nextBattery,
    solarPanelEfficiency: nextEfficiency,
    protection: nextProtection,
    crewSafety: nextCrewSafety,
    researchProgress: nextResearch,
    phase5Decision: optionId,
    decisions: [
      ...state.decisions,
      { phase: 5, choice: optionId, summary: consequenceSummary },
    ],
  };
}

export function computeFinalMissionReport(state) {
  const hasLifeSupport = state.activeSystems.includes('life_support');
  const hasComms = state.activeSystems.includes('communication');

  let crewSafety = state.crewSafety;
  if (hasLifeSupport) crewSafety += 5;
  if (state.prioritiesSolved) crewSafety += 5;
  if (state.repairSolved) crewSafety += 5;
  crewSafety = Math.max(45, Math.min(100, Math.round(crewSafety)));

  const remainingEnergy = Math.max(
    10,
    Math.min(100, Math.round((state.batteryLevel * 0.65) + (state.power * 0.35)))
  );

  let resourceScore = 40;
  if (state.batteriesCharged) resourceScore += 15;
  if (state.panelProtectionDone) resourceScore += 15;
  if (hasLifeSupport) resourceScore += 15;
  if (hasComms) resourceScore += 5;
  if (state.repairSolved) resourceScore += 10;
  resourceScore = Math.max(25, Math.min(100, resourceScore));

  let sciKnowledge = 0;
  if (state.threatSolved && state.threatAttempts <= 1) sciKnowledge += 1;
  else if (state.threatSolved) sciKnowledge += 1;
  if (state.dustLabSolved) sciKnowledge += 1;
  if (state.inspectedRegions.length >= 2) sciKnowledge += 1;
  sciKnowledge = Math.min(3, sciKnowledge);

  const rewards = [];
  if (crewSafety >= 75) {
    rewards.push({
      id: 'survival_medal',
      title: 'SURVIVAL MEDAL',
      description: 'Protected the crew and kept Martian life support running.',
    });
  }
  if (resourceScore >= 75 && state.repairSolved) {
    rewards.push({
      id: 'engineering_star',
      title: 'ENGINEERING STAR',
      description: 'Prepared batteries, protected panels, and repaired the solar array.',
    });
  }
  if (sciKnowledge >= 2) {
    rewards.push({
      id: 'science_explorer',
      title: 'SCIENCE EXPLORER',
      description: 'Investigated atmospheric dust using NASA MERRA-2 Earthdata concepts.',
    });
  }

  const starRating =
    rewards.length >= 3 ? 3 : rewards.length === 2 ? 2 : 1;

  return {
    crewSafety,
    remainingEnergy,
    resourceManagement: resourceScore,
    scientificKnowledge: sciKnowledge,
    rewards,
    starRating,
  };
}
