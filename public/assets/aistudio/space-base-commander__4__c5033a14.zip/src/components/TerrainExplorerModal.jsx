import React, { useEffect } from 'react';
import {
  AlertTriangle,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Battery,
  CheckCircle2,
  Compass,
  Gem,
  HelpCircle,
  MapPin,
  RotateCcw,
  Star,
  Trophy,
  X,
} from 'lucide-react';
import ArcadeButton from './ArcadeButton.jsx';
import AstronautCharacter from './AstronautCharacter.jsx';
import RoverArtwork from './RoverArtwork.jsx';
import TerrainMapGrid from './TerrainMapGrid.jsx';

const ZONE_BADGE_COLOR = {
  flat: 'border-emerald-400 bg-emerald-950/55',
  gentle: 'border-amber-300 bg-amber-950/45',
  steep: 'border-rose-400 bg-rose-950/45',
};

export default function TerrainExplorerModal({
  isOpen,
  mission,
  gameState,
  persOptions,
  onStartMission,
  onRestartMission,
  onMoveRover,
  onResolveChallenge,
  onToggleInstructions,
  onDismissLowBattery,
  onSelectLocation,
  onFinishMission,
  onClose,
}) {
  const tm = gameState.terrainMission || {};
  const data = mission?.missionData;

  useEffect(() => {
    if (!isOpen || tm.phase !== 'EXPLORING') return;

    const handleKeyDown = (e) => {
      if (tm.instructionsOpen || tm.activeChallenge || tm.lowBatteryModalOpen) {
        if (e.key === 'Escape') {
          if (tm.instructionsOpen) onToggleInstructions(false);
          if (tm.lowBatteryModalOpen) onDismissLowBattery();
        }
        return;
      }

      const keyMap = {
        ArrowUp: 'up',
        w: 'up',
        W: 'up',
        ArrowDown: 'down',
        s: 'down',
        S: 'down',
        ArrowLeft: 'left',
        a: 'left',
        A: 'left',
        ArrowRight: 'right',
        d: 'right',
        D: 'right',
      };

      const dir = keyMap[e.key];
      if (dir) {
        e.preventDefault();
        onMoveRover(dir);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isOpen,
    tm.phase,
    tm.instructionsOpen,
    tm.activeChallenge,
    tm.lowBatteryModalOpen,
    onMoveRover,
    onToggleInstructions,
    onDismissLowBattery,
  ]);

  if (!isOpen || !mission || !data) return null;

  const grid = data.grid || {};
  const challenges = data.challenges || {};
  const baseLocations = data.baseLocations || {};
  const resultsCfg = data.results || {};

  const visitedCount = (tm.visitedCells || []).length;
  const totalPlayableEstimate = Math.max(1, (grid.cols || 8) * (grid.rows || 6) - 6);
  const progressPct = tm.reachedDestination
    ? 100
    : Math.min(95, Math.round((visitedCount / Math.min(18, totalPlayableEstimate)) * 100));

  const batteryColor =
    tm.battery <= 25
      ? 'bg-rose-500'
      : tm.battery <= 55
        ? 'bg-amber-400'
        : 'bg-emerald-400';

  const activeChallengeCfg = tm.activeChallenge
    ? challenges[tm.activeChallenge]
    : null;

  const selectedLocation = (baseLocations.locations || []).find(
    (l) => l.id === tm.selectedLocationId
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-5 bg-[#070b1e]/88 backdrop-blur-sm overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="terrain-mission-title"
    >
      <div className="relative w-full max-w-5xl my-auto rounded-[28px] border-4 border-amber-300 bg-gradient-to-b from-[#291764] via-[#1c337d] to-[#111d4a] p-4 sm:p-6 shadow-[0_24px_70px_rgba(0,0,0,0.82)] text-white">
        {/* Top Utility Actions */}
        <div className="flex items-center justify-between gap-2 mb-4 pr-10">
          <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm font-extrabold text-sky-200">
            <Compass size={18} className="text-amber-300" />
            <span>{data.badge}</span>
          </div>

          {tm.phase === 'EXPLORING' && (
            <button
              type="button"
              onClick={() => onToggleInstructions(true)}
              className="inline-flex items-center gap-1.5 rounded-full border-2 border-sky-300/75 bg-slate-900/75 px-3 py-1 text-xs font-extrabold text-sky-100 hover:border-amber-300 cursor-pointer"
            >
              <HelpCircle size={15} />
              <span>Instruções</span>
            </button>
          )}
        </div>

        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Voltar ao AstroBase"
          className="absolute top-4 right-4 w-10 h-10 rounded-full border-2 border-white/80 bg-rose-600 hover:bg-rose-500 flex items-center justify-center text-white shadow-md cursor-pointer"
        >
          <X size={20} strokeWidth={2.75} />
        </button>

        {/* STEP 1: MISSION BRIEFING */}
        {tm.phase === 'BRIEFING' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center py-2">
            <div className="md:col-span-5 flex flex-col items-center justify-center rounded-3xl border-2 border-sky-300/40 bg-slate-950/50 p-5">
              <div className="flex items-end justify-center gap-2">
                <AstronautCharacter
                  character={gameState.character}
                  options={persOptions}
                  size={150}
                  waving
                  className="w-[130px] sm:w-[150px] h-auto"
                />
                <RoverArtwork size={96} className="mb-3 drop-shadow-lg" />
              </div>
              <p className="mt-3 text-xs text-center text-sky-200 leading-snug">
                {data.scientificNote}
              </p>
            </div>

            <div className="md:col-span-7 flex flex-col">
              <h2
                id="terrain-mission-title"
                className="text-2xl sm:text-4xl font-extrabold text-amber-300 mb-3"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {data.briefingTitle}
              </h2>

              <p className="text-sm sm:text-base text-sky-100 leading-relaxed mb-4">
                {data.briefingMessage}
              </p>

              <div className="rounded-2xl border-2 border-sky-300/35 bg-slate-950/55 p-4 mb-5">
                <h3 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-amber-300 mb-2">
                  Objetivos da Missão
                </h3>
                <ul className="space-y-1.5 text-xs sm:text-sm text-sky-100">
                  {(data.objectives || []).map((obj, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                      <span>{obj}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <ArcadeButton
                  variant="yellow"
                  onClick={onStartMission}
                  className="!min-w-[215px] !min-h-[56px] !text-lg"
                >
                  {data.startButtonLabel}
                </ArcadeButton>

                <button
                  type="button"
                  onClick={() => onToggleInstructions(true)}
                  className="inline-flex items-center gap-2 rounded-full border-2 border-white/60 px-4 py-3 text-sm font-extrabold text-white hover:bg-white/10 cursor-pointer"
                >
                  <HelpCircle size={18} />
                  <span>{data.instructionsTitle}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEPS 2–5: TERRAIN EXPLORATION & ROVER CONTROL */}
        {tm.phase === 'EXPLORING' && (
          <div>
            <h2 id="terrain-mission-title" className="sr-only">
              {mission.title}
            </h2>

            {/* Resource Management Dashboard */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4 tabular-nums">
              <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/65 p-2.5 sm:p-3">
                <div className="flex items-center justify-between text-xs font-bold text-sky-200 mb-1">
                  <span className="inline-flex items-center gap-1">
                    <Battery size={14} className="text-emerald-300" /> Bateria
                  </span>
                  <span className="text-white font-extrabold">{tm.battery}%</span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full transition-all duration-200 ${batteryColor}`}
                    style={{ width: `${tm.battery}%` }}
                  />
                </div>
              </div>

              <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/65 p-2.5 sm:p-3 flex flex-col justify-center">
                <div className="text-xs font-bold text-sky-200 flex items-center gap-1">
                  <Gem size={14} className="text-cyan-300" /> Amostras
                </div>
                <div className="text-lg sm:text-xl font-extrabold text-white">
                  {(tm.samplesCollected || []).length} / 3
                </div>
              </div>

              <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/65 p-2.5 sm:p-3 flex flex-col justify-center">
                <div className="text-xs font-bold text-sky-200 flex items-center gap-1">
                  <MapPin size={14} className="text-amber-300" /> Progresso
                </div>
                <div className="text-lg sm:text-xl font-extrabold text-white">
                  {progressPct}%
                </div>
              </div>

              <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/65 p-2.5 sm:p-3 flex flex-col justify-center">
                <div className="text-xs font-bold text-sky-200 flex items-center gap-1">
                  <Trophy size={14} className="text-amber-300" /> Pontuação
                </div>
                <div className="text-lg sm:text-xl font-extrabold text-amber-300">
                  {tm.score} pts
                </div>
              </div>
            </div>

            {/* Map + Rover Controls Split */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
              <div className="lg:col-span-8">
                <TerrainMapGrid
                  grid={grid}
                  legend={data.legend}
                  rover={tm.rover}
                  visitedCells={tm.visitedCells || []}
                  samplesCollected={tm.samplesCollected || []}
                  resolvedChallenges={tm.resolvedChallenges || []}
                  scientificNote={data.scientificNote}
                />
              </div>

              {/* Right Column: Astronaut Feedback + Rover D-Pad Controls */}
              <div className="lg:col-span-4 flex flex-col items-center gap-4">
                <div className="w-full rounded-2xl border-2 border-sky-300/45 bg-slate-950/65 p-3.5 flex items-center gap-3">
                  <div className="w-16 shrink-0">
                    <AstronautCharacter
                      character={gameState.character}
                      options={persOptions}
                      size={64}
                      waving
                      className="w-full h-auto"
                    />
                  </div>
                  <p className="text-xs sm:text-sm font-bold text-sky-100 leading-snug">
                    {tm.feedbackMessage ||
                      'Conduz o rover até à Bandeira de Base, recolhendo amostras pelo caminho!'}
                  </p>
                </div>

                {/* Directional D-Pad Controls */}
                <div className="rounded-3xl border-2 border-amber-300/60 bg-slate-950/65 p-4 flex flex-col items-center gap-2 w-full">
                  <div className="text-xs font-extrabold uppercase tracking-wider text-amber-300 mb-1">
                    Controlo do Rover (Setas / WASD)
                  </div>

                  <button
                    type="button"
                    onClick={() => onMoveRover('up')}
                    aria-label="Mover para cima"
                    className="w-14 h-12 rounded-xl border-2 border-white bg-gradient-to-b from-sky-400 to-blue-600 shadow-[0_4px_0_#1e3a8a] active:translate-y-0.5 flex items-center justify-center cursor-pointer"
                  >
                    <ArrowUp size={24} strokeWidth={3} />
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onMoveRover('left')}
                      aria-label="Mover para a esquerda"
                      className="w-14 h-12 rounded-xl border-2 border-white bg-gradient-to-b from-sky-400 to-blue-600 shadow-[0_4px_0_#1e3a8a] active:translate-y-0.5 flex items-center justify-center cursor-pointer"
                    >
                      <ArrowLeft size={24} strokeWidth={3} />
                    </button>
                    <button
                      type="button"
                      onClick={() => onMoveRover('down')}
                      aria-label="Mover para baixo"
                      className="w-14 h-12 rounded-xl border-2 border-white bg-gradient-to-b from-sky-400 to-blue-600 shadow-[0_4px_0_#1e3a8a] active:translate-y-0.5 flex items-center justify-center cursor-pointer"
                    >
                      <ArrowDown size={24} strokeWidth={3} />
                    </button>
                    <button
                      type="button"
                      onClick={() => onMoveRover('right')}
                      aria-label="Mover para a direita"
                      className="w-14 h-12 rounded-xl border-2 border-white bg-gradient-to-b from-sky-400 to-blue-600 shadow-[0_4px_0_#1e3a8a] active:translate-y-0.5 flex items-center justify-center cursor-pointer"
                    >
                      <ArrowRight size={24} strokeWidth={3} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 6: BASE LOCATION SELECTION */}
        {tm.phase === 'LOCATION_SELECT' && (
          <div className="py-2">
            <h2
              id="terrain-mission-title"
              className="text-2xl sm:text-3xl font-extrabold text-amber-300 text-center mb-2"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {baseLocations.title}
            </h2>
            <p className="text-sm sm:text-base text-sky-100 text-center max-w-2xl mx-auto mb-5">
              {baseLocations.subtitle}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              {(baseLocations.locations || []).map((loc) => (
                <button
                  key={loc.id}
                  type="button"
                  onClick={() => onSelectLocation(loc.id)}
                  className={`flex flex-col text-left rounded-2xl border-3 p-4 transition-transform hover:-translate-y-1 hover:border-amber-300 cursor-pointer ${
                    ZONE_BADGE_COLOR[loc.zone] || 'border-sky-300 bg-slate-900/70'
                  }`}
                >
                  <div className="text-xs font-extrabold uppercase tracking-wider text-amber-300 mb-1">
                    {loc.label}
                  </div>
                  <h3
                    className="text-lg sm:text-xl font-extrabold text-white mb-3"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    {loc.title}
                  </h3>

                  <div className="space-y-1.5 text-xs sm:text-sm text-sky-100 mb-4 tabular-nums">
                    <div>
                      <span className="text-sky-300 font-bold">Inclinação:</span> {loc.slope}
                    </div>
                    <div>
                      <span className="text-sky-300 font-bold">Desnível:</span> {loc.elevationVariation}
                    </div>
                    <div>
                      <span className="text-sky-300 font-bold">Acessibilidade:</span> {loc.accessibility}
                    </div>
                    <div>
                      <span className="text-sky-300 font-bold">Distância:</span> {loc.distanceFromStart}
                    </div>
                  </div>

                  <span className="mt-auto inline-flex items-center justify-center rounded-full border-2 border-white bg-amber-400 text-slate-950 font-extrabold text-xs sm:text-sm py-2 px-4">
                    Escolher {loc.label}
                  </span>
                </button>
              ))}
            </div>

            <p className="text-xs text-center text-sky-200 max-w-2xl mx-auto">
              {baseLocations.disclaimer}
            </p>
          </div>
        )}

        {/* STEP 7: MISSION RESULTS */}
        {tm.phase === 'RESULTS' && (
          <div className="flex flex-col items-center text-center py-3">
            <div className="w-[120px] mb-2">
              <AstronautCharacter
                character={gameState.character}
                options={persOptions}
                size={120}
                waving={tm.missionSuccess}
                className="w-full h-auto"
              />
            </div>

            {tm.missionSuccess && (
              <div className="flex items-center gap-2 mb-2" aria-label={`${tm.earnedStars} estrelas`}>
                {[1, 2, 3].map((idx) => (
                  <Star
                    key={idx}
                    size={32}
                    className={
                      idx <= tm.earnedStars
                        ? 'text-amber-300 fill-amber-300'
                        : 'text-slate-600'
                    }
                  />
                ))}
              </div>
            )}

            <h2
              id="terrain-mission-title"
              className={`text-2xl sm:text-3xl font-extrabold mb-4 ${
                tm.missionSuccess ? 'text-amber-300' : 'text-rose-300'
              }`}
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {tm.missionSuccess ? resultsCfg.successTitle : resultsCfg.failureTitle}
            </h2>

            {/* Metrics Summary Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-2xl mb-4 tabular-nums">
              <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/60 p-3">
                <div className="text-xs text-sky-200 font-bold">Pontuação Final</div>
                <div className="text-xl font-extrabold text-amber-300">{tm.score} pts</div>
              </div>
              <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/60 p-3">
                <div className="text-xs text-sky-200 font-bold">Bateria Restante</div>
                <div className="text-xl font-extrabold text-white">{tm.battery}%</div>
              </div>
              <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/60 p-3">
                <div className="text-xs text-sky-200 font-bold">Amostras</div>
                <div className="text-xl font-extrabold text-white">
                  {(tm.samplesCollected || []).length} / 3
                </div>
              </div>
              <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/60 p-3">
                <div className="text-xs text-sky-200 font-bold">Local Escolhido</div>
                <div className="text-lg font-extrabold text-white">
                  {selectedLocation ? selectedLocation.label : '—'}
                </div>
              </div>
            </div>

            {/* Terrain Analysis & Educational Feedback */}
            <div className="max-w-2xl rounded-2xl border-2 border-sky-300/45 bg-slate-950/60 p-4 mb-6 text-sm sm:text-base text-sky-100 leading-relaxed">
              {selectedLocation ? (
                <>
                  <div className="font-extrabold text-amber-300 mb-1">
                    Análise do Terreno: {selectedLocation.title}
                  </div>
                  <p>{selectedLocation.analysis}</p>
                </>
              ) : (
                <p>{tm.failureReason}</p>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4">
              <ArcadeButton
                variant="red"
                onClick={onRestartMission}
                className="!min-w-[195px] !min-h-[54px] !text-base"
              >
                <RotateCcw size={18} />
                <span>{resultsCfg.playAgainLabel}</span>
              </ArcadeButton>

              <ArcadeButton
                variant="yellow"
                onClick={onFinishMission}
                className="!min-w-[215px] !min-h-[54px] !text-base"
              >
                <span>{resultsCfg.returnLabel}</span>
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* MODAL: INSTRUCTIONS */}
        {tm.instructionsOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75">
            <div className="w-full max-w-md rounded-3xl border-4 border-sky-300 bg-[#1a2e72] p-6 shadow-2xl">
              <h3
                className="text-2xl font-extrabold text-amber-300 mb-3"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {data.instructionsTitle}
              </h3>
              <ul className="space-y-2 text-sm text-sky-100 mb-6 list-disc pl-5">
                {(data.instructionsItems || []).map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
              <div className="flex justify-end">
                <ArcadeButton
                  variant="yellow"
                  onClick={() => onToggleInstructions(false)}
                  className="!min-w-[150px] !min-h-[48px] !text-base"
                >
                  Entendido
                </ArcadeButton>
              </div>
            </div>
          </div>
        )}

        {/* MODAL: INTERACTIVE CHALLENGES (A, B, C) */}
        {activeChallengeCfg && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75">
            <div className="w-full max-w-md rounded-3xl border-4 border-amber-300 bg-gradient-to-b from-[#2b1a69] to-[#172863] p-6 shadow-2xl">
              <h3
                className="text-xl sm:text-2xl font-extrabold text-amber-300 mb-2"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {activeChallengeCfg.title}
              </h3>
              <p className="text-sm sm:text-base text-sky-100 mb-5">
                {activeChallengeCfg.description}
                {tm.pendingTarget?.cell?.sampleName
                  ? ` (${tm.pendingTarget.cell.sampleName})`
                  : ''}
              </p>

              {tm.activeChallenge === 'sample' ? (
                <div className="flex justify-center">
                  <ArcadeButton
                    variant="yellow"
                    onClick={() => onResolveChallenge('collect')}
                    className="!min-w-[230px] !min-h-[54px] !text-base"
                  >
                    <Gem size={18} />
                    <span>{activeChallengeCfg.collectLabel}</span>
                  </ArcadeButton>
                </div>
              ) : (
                <div className="flex flex-col gap-2.5">
                  {(activeChallengeCfg.options || []).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => onResolveChallenge(opt.id)}
                      className="w-full text-left rounded-2xl border-2 border-sky-300/60 bg-slate-900/75 px-4 py-3 text-sm font-bold text-white hover:border-amber-300 hover:bg-slate-800 cursor-pointer"
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* MODAL: LOW BATTERY WARNING */}
        {tm.lowBatteryModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75">
            <div className="w-full max-w-sm rounded-3xl border-4 border-rose-400 bg-[#2a123f] p-6 text-center shadow-2xl">
              <AlertTriangle size={40} className="text-amber-300 mx-auto mb-3" />
              <h3
                className="text-2xl font-extrabold text-amber-300 mb-2"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Bateria Baixa!
              </h3>
              <p className="text-sm text-rose-100 mb-5">
                A bateria do rover está em {tm.battery}%. Escolhe caminhos planos (verdes) para poupar energia até ao destino!
              </p>
              <ArcadeButton
                variant="yellow"
                onClick={onDismissLowBattery}
                className="!min-w-[160px] !min-h-[48px] !text-base"
              >
                Continuar
              </ArcadeButton>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
