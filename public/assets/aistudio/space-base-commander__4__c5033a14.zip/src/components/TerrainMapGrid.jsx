import React from 'react';
import { Flag, Gem, Mountain, TriangleAlert } from 'lucide-react';
import RoverArtwork from './RoverArtwork.jsx';

const ZONE_STYLES = {
  flat: 'bg-emerald-500/90 border-emerald-300/70',
  gentle: 'bg-yellow-400/90 border-yellow-200/80',
  steep: 'bg-orange-400/95 border-orange-200/80',
  rocky: 'bg-amber-800/95 border-amber-600/80',
};

export default function TerrainMapGrid({
  grid,
  legend,
  rover,
  visitedCells,
  samplesCollected,
  resolvedChallenges,
  scientificNote,
}) {
  const cells = grid?.cells || [];

  return (
    <div className="flex flex-col gap-3">
      {/* 2D Topographic Grid */}
      <div
        className="rounded-2xl border-4 border-sky-300 bg-slate-950/80 p-2 sm:p-3 shadow-inner"
        role="grid"
        aria-label="Mapa topográfico de exploração"
      >
        <div className="grid grid-cols-8 gap-1 sm:gap-1.5">
          {cells.map((row, y) =>
            row.map((cell, x) => {
              const key = `${x},${y}`;
              const isRoverHere = rover.x === x && rover.y === y;
              const isVisited = visitedCells.includes(key);
              const isSampleCollected =
                cell.type === 'sample' && samplesCollected.includes(cell.sampleId);
              const isChallengeResolved = resolvedChallenges.includes(key);
              const zoneStyle = ZONE_STYLES[cell.zone] || ZONE_STYLES.flat;

              return (
                <div
                  key={key}
                  title={`(${x + 1},${y + 1}) · ${cell.elevationM} m`}
                  className={`relative aspect-square rounded-lg sm:rounded-xl border-2 flex items-center justify-center overflow-hidden transition-transform ${zoneStyle} ${
                    isRoverHere ? 'ring-3 ring-white scale-[1.04] z-10' : ''
                  }`}
                >
                  {/* Elevation Micro Label */}
                  <span className="absolute top-0.5 left-1 text-[8px] sm:text-[9px] font-extrabold text-slate-950/70 leading-none tabular-nums pointer-events-none">
                    {cell.elevationM}m
                  </span>

                  {/* Start Pad */}
                  {cell.type === 'start' && !isRoverHere && (
                    <span className="text-[9px] sm:text-[10px] font-extrabold text-white bg-indigo-800/85 px-1.5 py-0.5 rounded-md">
                      INÍCIO
                    </span>
                  )}

                  {/* Destination Flag */}
                  {cell.type === 'destination' && !isRoverHere && (
                    <div className="flex flex-col items-center">
                      <Flag
                        size={18}
                        className="text-white fill-rose-500 drop-shadow animate-bounce"
                      />
                      <span className="text-[8px] font-extrabold text-slate-950 bg-white/85 px-1 rounded">
                        BASE
                      </span>
                    </div>
                  )}

                  {/* Impassable Rock Obstacle */}
                  {cell.type === 'rock_obstacle' && (
                    <div className="flex items-center justify-center w-full h-full bg-stone-900/55">
                      <Mountain
                        size={20}
                        className="text-stone-200 fill-stone-700 drop-shadow"
                      />
                    </div>
                  )}

                  {/* Rocky Challenge */}
                  {cell.type === 'rock_challenge' &&
                    !isChallengeResolved &&
                    !isRoverHere && (
                      <TriangleAlert
                        size={17}
                        className="text-amber-200 fill-amber-900/70 drop-shadow"
                      />
                    )}

                  {/* Steep Slope Challenge */}
                  {cell.type === 'slope_challenge' &&
                    !isChallengeResolved &&
                    !isRoverHere && (
                      <TriangleAlert
                        size={17}
                        className="text-white fill-orange-700/80 drop-shadow"
                      />
                    )}

                  {/* Scientific Sample */}
                  {cell.type === 'sample' && !isSampleCollected && !isRoverHere && (
                    <Gem
                      size={18}
                      className="text-cyan-200 fill-cyan-400 drop-shadow-[0_0_6px_rgba(34,211,238,0.9)] animate-pulse"
                    />
                  )}

                  {/* Visited Trail Dot */}
                  {isVisited && !isRoverHere && cell.type === 'normal' && (
                    <span
                      className="w-2 h-2 rounded-full bg-white/75 shadow"
                      aria-hidden="true"
                    />
                  )}

                  {/* Active Rover Sprite */}
                  {isRoverHere && (
                    <div className="w-[88%] h-[88%] flex items-center justify-center">
                      <RoverArtwork
                        size={42}
                        facing={rover.facing}
                        className="w-full h-full drop-shadow-[0_3px_4px_rgba(0,0,0,0.5)]"
                      />
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Topographic Color Legend */}
      <div className="rounded-2xl border-2 border-sky-300/35 bg-slate-950/65 p-2.5 sm:p-3">
        <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5 text-xs font-bold text-sky-100">
          {(legend || []).map((item) => (
            <span key={item.zone} className="inline-flex items-center gap-1.5">
              <span
                className="w-3.5 h-3.5 rounded-sm border border-white/70 inline-block"
                style={{ backgroundColor: item.color }}
                aria-hidden="true"
              />
              <span>{item.label}</span>
            </span>
          ))}
        </div>
        {scientificNote && (
          <p className="mt-2 text-[11px] text-sky-200/85 text-center leading-snug">
            {scientificNote}
          </p>
        )}
      </div>
    </div>
  );
}
