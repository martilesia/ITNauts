import React from 'react';

export default function RoverArtwork({ size = 56, facing = 'right', className = '' }) {
  const flip = facing === 'left' ? 'scale(-1, 1)' : '';

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 80 80"
      fill="none"
      className={className}
      role="img"
      aria-label="Rover espacial"
    >
      <g transform={flip ? 'translate(80, 0) scale(-1, 1)' : undefined}>
        {/* Solar Panel Wing */}
        <rect
          x="10"
          y="34"
          width="24"
          height="10"
          rx="3"
          fill="#1D4ED8"
          stroke="#93C5FD"
          strokeWidth="2"
        />
        <line x1="18" y1="34" x2="18" y2="44" stroke="#93C5FD" strokeWidth="1.2" />
        <line x1="26" y1="34" x2="26" y2="44" stroke="#93C5FD" strokeWidth="1.2" />

        {/* Mast & Camera Head */}
        <rect x="48" y="16" width="5" height="18" rx="2.5" fill="#E2E8F0" />
        <rect
          x="42"
          y="10"
          width="22"
          height="12"
          rx="5"
          fill="#F8FAFC"
          stroke="#1E293B"
          strokeWidth="2"
        />
        <circle cx="57" cy="16" r="3.8" fill="#22D3EE" stroke="#0F172A" strokeWidth="1.5" />

        {/* Rover Chassis Body */}
        <rect
          x="18"
          y="32"
          width="44"
          height="22"
          rx="7"
          fill="#F59E0B"
          stroke="#FFFFFF"
          strokeWidth="2.5"
        />
        <rect x="24" y="37" width="26" height="10" rx="4" fill="#FEF3C7" />
        <circle cx="55" cy="42" r="3" fill="#EF4444" />

        {/* 3 Knobby Wheels */}
        <circle cx="24" cy="59" r="9" fill="#1E293B" stroke="#E2E8F0" strokeWidth="2.5" />
        <circle cx="24" cy="59" r="3.5" fill="#94A3B8" />

        <circle cx="42" cy="59" r="9" fill="#1E293B" stroke="#E2E8F0" strokeWidth="2.5" />
        <circle cx="42" cy="59" r="3.5" fill="#94A3B8" />

        <circle cx="58" cy="59" r="9" fill="#1E293B" stroke="#E2E8F0" strokeWidth="2.5" />
        <circle cx="58" cy="59" r="3.5" fill="#94A3B8" />
      </g>
    </svg>
  );
}
