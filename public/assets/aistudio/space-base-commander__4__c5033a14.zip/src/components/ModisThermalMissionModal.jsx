import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Moon,
  Satellite,
  ShieldCheck,
  Star,
  Sun,
  Thermometer,
  X,
} from 'lucide-react';
import ArcadeButton from './ArcadeButton.jsx';
import AstronautCharacter from './AstronautCharacter.jsx';

function RegionIllustration({ regionId, isNight }) {
  const skyTop = isNight ? '#0f172a' : '#38bdf8';
  const skyBottom = isNight ? '#1e1b4b' : '#bae6fd';

  return (
    <svg viewBox="0 0 180 96" className="w-full h-24 rounded-xl overflow-hidden" aria-hidden="true">
      <defs>
        <linearGradient id={`sky-${regionId}-${isNight ? 'n' : 'd'}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={skyTop} />
          <stop offset="100%" stopColor={skyBottom} />
        </linearGradient>
      </defs>
      <rect width="180" height="96" fill={`url(#sky-${regionId}-${isNight ? 'n' : 'd'})`} />
      {isNight ? (
        <>
          <circle cx="146" cy="22" r="10" fill="#FEF08A" />
          <circle cx="34" cy="18" r="2" fill="#FFFFFF" />
          <circle cx="78" cy="26" r="1.5" fill="#FFFFFF" />
          <circle cx="114" cy="14" r="2" fill="#FFFFFF" />
        </>
      ) : (
        <circle cx="146" cy="22" r="11" fill="#FDE047" />
      )}

      {regionId === 'desert' && (
        <>
          <path d="M0 70 Q45 48 95 66 T180 58 L180 96 L0 96 Z" fill={isNight ? '#92400e' : '#f59e0b'} />
          <path d="M0 80 Q65 62 130 78 T180 74 L180 96 L0 96 Z" fill={isNight ? '#78350f' : '#d97706'} />
        </>
      )}

      {regionId === 'forest' && (
        <>
          <rect x="0" y="68" width="180" height="28" fill={isNight ? '#064e3b' : '#16a34a'} />
          <circle cx="30" cy="64" r="16" fill={isNight ? '#065f46' : '#22c55e'} />
          <circle cx="62" cy="58" r="20" fill={isNight ? '#047857' : '#15803d'} />
          <circle cx="102" cy="62" r="18" fill={isNight ? '#065f46' : '#22c55e'} />
          <circle cx="142" cy="56" r="21" fill={isNight ? '#047857' : '#16a34a'} />
          <path d="M0 84 Q85 78 180 88 L180 96 L0 96 Z" fill="#0284c7" opacity="0.7" />
        </>
      )}

      {regionId === 'polar' && (
        <>
          <polygon points="0,96 0,66 48,46 92,68 136,42 180,62 180,96" fill={isNight ? '#93c5fd' : '#e0f2fe'} />
          <path d="M0 76 L180 76 L180 96 L0 96 Z" fill={isNight ? '#1e3a8a' : '#38bdf8'} opacity="0.55" />
        </>
      )}

      {/* Subtle 1 km MODIS Satellite Grid Overlay */}
      <path
        d="M45 0 V96 M90 0 V96 M135 0 V96 M0 32 H180 M0 64 H180"
        stroke="#FFFFFF"
        strokeOpacity="0.22"
        strokeWidth="1"
        strokeDasharray="3 3"
      />
      <rect x="45" y="32" width="45" height="32" stroke="#FDE047" strokeWidth="1.5" fill="rgba(253,224,71,0.12)" />
    </svg>
  );
}

function HabitatDomeIllustration({ installedLayers, isNight, destinationId, isSafe }) {
  const hasFoil = installedLayers.includes('reflective_foil');
  const hasAerogel = installedLayers.includes('aerogel_blanket');
  const hasGlass = installedLayers.includes('thermal_glass');
  const hasBanners = installedLayers.includes('party_banners');
  const groundColor = destinationId === 'mars' ? '#b45309' : '#64748b';
  const groundShade = destinationId === 'mars' ? '#7c2d12' : '#475569';

  return (
    <svg viewBox="0 0 320 200" className="w-full max-w-[320px] h-auto mx-auto" role="img" aria-label="Habitat espacial com camadas térmicas">
      {/* Space Sky */}
      <rect
        width="320"
        height="200"
        rx="20"
        fill={isNight ? '#090d24' : '#172554'}
      />
      {isNight ? (
        <circle cx="268" cy="36" r="14" fill="#E2E8F0" opacity="0.85" />
      ) : (
        <>
          <circle cx="268" cy="36" r="18" fill="#FDE047" />
          <circle cx="268" cy="36" r="26" fill="#FACC15" opacity="0.22" />
        </>
      )}
      <circle cx="42" cy="32" r="2" fill="#FFFFFF" />
      <circle cx="94" cy="24" r="1.5" fill="#FFFFFF" />
      <circle cx="170" cy="28" r="2" fill="#FFFFFF" />

      {/* Planetary Surface */}
      <path d="M0 152 Q160 132 320 152 L320 200 L0 200 Z" fill={groundColor} />
      <ellipse cx="64" cy="172" rx="22" ry="7" fill={groundShade} opacity="0.6" />
      <ellipse cx="256" cy="176" rx="26" ry="8" fill={groundShade} opacity="0.6" />

      {/* Decorative Party Banners (fun decoy) */}
      {hasBanners && (
        <g>
          <line x1="68" y1="150" x2="68" y2="110" stroke="#F8FAFC" strokeWidth="3" />
          <polygon points="68,110 92,118 68,126" fill="#EC4899" />
          <line x1="252" y1="150" x2="252" y2="110" stroke="#F8FAFC" strokeWidth="3" />
          <polygon points="252,110 228,118 252,126" fill="#22D3EE" />
        </g>
      )}

      {/* Aerogel Insulation Blanket Layer */}
      {hasAerogel && (
        <path
          d="M84 152 C84 96 236 96 236 152 Z"
          fill="#38BDF8"
          stroke="#BAE6FD"
          strokeWidth="5"
          opacity="0.9"
        />
      )}

      {/* Main Habitat Dome Body */}
      <path
        d="M94 152 C94 104 226 104 226 152 Z"
        fill={isSafe ? '#DCFCE7' : '#E2E8F0'}
        stroke="#FFFFFF"
        strokeWidth="3.5"
      />

      {/* Double Thermal Glass Window */}
      <path
        d="M124 148 C124 118 196 118 196 148 Z"
        fill={hasGlass ? '#7DD3FC' : '#334155'}
        stroke={hasGlass ? '#E0F2FE' : '#94A3B8'}
        strokeWidth={hasGlass ? '4.5' : '2'}
      />
      {hasGlass && (
        <path
          d="M138 134 C146 124 162 122 174 126"
          stroke="#FFFFFF"
          strokeWidth="3"
          strokeLinecap="round"
          opacity="0.85"
        />
      )}

      {/* Golden Reflective MLI Foil Shield */}
      {hasFoil && (
        <>
          <rect
            x="88"
            y="142"
            width="144"
            height="16"
            rx="8"
            fill="#FBBF24"
            stroke="#FEF08A"
            strokeWidth="2.5"
          />
          <path
            d="M110 112 Q160 88 210 112"
            stroke="#FBBF24"
            strokeWidth="6"
            strokeLinecap="round"
            fill="none"
          />
        </>
      )}

      {/* Airlock Door */}
      <rect x="148" y="136" width="24" height="22" rx="5" fill="#1E3A8A" stroke="#FFFFFF" strokeWidth="2" />
    </svg>
  );
}

export default function ModisThermalMissionModal({
  isOpen,
  mission,
  gameState,
  persOptions,
  onSetTimeOfDay,
  onInspectRegion,
  onSetStep,
  onAnswerComparison,
  onToggleLayer,
  onValidateHabitat,
  onFinishMission,
  onClose,
}) {
  const [selectedRegionId, setSelectedRegionId] = useState('desert');
  const [simTime, setSimTime] = useState('day');

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen || !mission || !mission.missionData) return null;

  const data = mission.missionData;
  const modisState = gameState.modisMission || {};
  const telemetry = gameState.modisHabitatTelemetry || {};
  const currentStep = modisState.step || 1;
  const timeOfDay = modisState.timeOfDay || 'day';
  const isNight = timeOfDay === 'night';
  const inspected = modisState.inspectedObservations || {};
  const regions = data.regions || [];

  const spaceRef =
    data.spaceReferenceByDestination?.[gameState.selectedDestination] ||
    data.spaceReferenceByDestination?.default;

  const totalReadingsCount = regions.reduce((sum, reg) => {
    const entry = inspected[reg.id] || {};
    return sum + (entry.day ? 1 : 0) + (entry.night ? 1 : 0);
  }, 0);
  const canProceedToStep2 = totalReadingsCount >= 2 && Object.keys(inspected).length >= 2;

  const questions = data.comparisonQuestions || [];
  const allQuestionsSolved = questions.every(
    (q) => modisState.comparisonAnswers?.[q.id]?.correct
  );

  const builder = data.habitatBuilder || {};
  const installedLayers = modisState.installedLayers || [];

  const handleRegionCardClick = (regionId) => {
    setSelectedRegionId(regionId);
    onInspectRegion(regionId);
  };

  const selectedRegion =
    regions.find((r) => r.id === selectedRegionId) || regions[0];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#070b1e]/85 backdrop-blur-sm overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modis-mission-title"
    >
      <div className="relative w-full max-w-4xl my-auto rounded-[28px] border-4 border-amber-300 bg-gradient-to-b from-[#291764] via-[#1c337d] to-[#111d4a] p-4 sm:p-6 md:p-7 shadow-[0_24px_70px_rgba(0,0,0,0.8)] text-white">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Fechar missão"
          className="absolute top-4 right-4 w-10 h-10 rounded-full border-2 border-white/80 bg-rose-600 hover:bg-rose-500 flex items-center justify-center text-white shadow-md cursor-pointer"
        >
          <X size={20} strokeWidth={2.75} />
        </button>

        {/* Top Mission Header */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-4 pr-10 mb-5">
          <div className="hidden sm:flex items-center justify-center w-16 h-16 rounded-2xl border-2 border-sky-300 bg-sky-900/60 shrink-0">
            <Satellite size={34} className="text-amber-300" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm font-extrabold text-sky-200 mb-1">
              <span>{data.sourceLabel}</span>
              <span aria-hidden="true">·</span>
              <span className="text-amber-300">{data.productCode}</span>
              <span aria-hidden="true">·</span>
              <span>Resolução {data.resolution}</span>
            </div>
            <h2
              id="modis-mission-title"
              className="text-xl sm:text-3xl font-extrabold text-white leading-tight"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {mission.title}
            </h2>
          </div>
        </div>

        {/* 3-Step Visual Progress Bar */}
        {currentStep <= 3 && (
          <div className="grid grid-cols-3 gap-2 mb-5">
            {(data.steps || []).map((st) => {
              const isActive = currentStep === st.id;
              const isDone = currentStep > st.id;
              return (
                <div
                  key={st.id}
                  className={`rounded-xl border-2 px-2.5 py-2 text-center text-xs sm:text-sm font-extrabold transition-colors ${
                    isActive
                      ? 'border-amber-300 bg-amber-400/20 text-amber-200'
                      : isDone
                        ? 'border-emerald-400 bg-emerald-500/20 text-emerald-200'
                        : 'border-white/20 bg-slate-900/40 text-slate-300'
                  }`}
                >
                  {st.label}
                </div>
              );
            })}
          </div>
        )}

        {/* STEP 1: MODIS Day & Night Observation */}
        {currentStep === 1 && (
          <div>
            <p className="text-sm sm:text-base text-sky-100 leading-relaxed mb-4">
              {data.intro}
            </p>

            {/* Day / Night Observation Toggle */}
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4 rounded-2xl border-2 border-sky-300/40 bg-slate-950/45 p-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onSetTimeOfDay('day')}
                  className={`inline-flex items-center gap-2 rounded-full border-2 px-4 py-2 text-sm font-extrabold transition-transform cursor-pointer ${
                    !isNight
                      ? 'border-white bg-gradient-to-b from-amber-300 to-orange-500 text-slate-950 shadow-md scale-[1.02]'
                      : 'border-white/30 bg-slate-800/80 text-sky-100 hover:border-amber-300'
                  }`}
                >
                  <Sun size={18} />
                  <span>{data.dayLabel}</span>
                </button>
                <button
                  type="button"
                  onClick={() => onSetTimeOfDay('night')}
                  className={`inline-flex items-center gap-2 rounded-full border-2 px-4 py-2 text-sm font-extrabold transition-transform cursor-pointer ${
                    isNight
                      ? 'border-white bg-gradient-to-b from-indigo-400 to-purple-700 text-white shadow-md scale-[1.02]'
                      : 'border-white/30 bg-slate-800/80 text-sky-100 hover:border-indigo-300'
                  }`}
                >
                  <Moon size={18} />
                  <span>{data.nightLabel}</span>
                </button>
              </div>

              <div className="text-xs sm:text-sm font-bold text-amber-200 tabular-nums">
                Leituras registadas: {totalReadingsCount} / {regions.length * 2}
              </div>
            </div>

            {/* 3 Earth MODIS 1 km Region Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
              {regions.map((reg) => {
                const obs = inspected[reg.id] || {};
                const currentObserved = isNight ? obs.night : obs.day;
                const tempValue = isNight ? reg.nightTempC : reg.dayTempC;
                const isSelected = selectedRegionId === reg.id;

                return (
                  <button
                    key={reg.id}
                    type="button"
                    onClick={() => handleRegionCardClick(reg.id)}
                    className={`flex flex-col text-left rounded-2xl border-3 p-3 transition-transform cursor-pointer ${
                      isSelected
                        ? 'border-amber-300 bg-indigo-900/75 shadow-[0_0_20px_rgba(251,191,36,0.25)] scale-[1.01]'
                        : 'border-white/25 bg-slate-900/65 hover:border-sky-300'
                    }`}
                  >
                    <RegionIllustration regionId={reg.id} isNight={isNight} />

                    <div className="flex items-start justify-between gap-2 mt-2.5">
                      <div>
                        <h3
                          className="text-base sm:text-lg font-extrabold text-white"
                          style={{ fontFamily: 'var(--font-display)' }}
                        >
                          {reg.name}
                        </h3>
                        <p className="text-xs text-sky-200">{reg.biome}</p>
                      </div>

                      <div className="text-right tabular-nums">
                        <div
                          className={`text-xl font-extrabold ${
                            tempValue >= 35
                              ? 'text-orange-300'
                              : tempValue <= 0
                                ? 'text-cyan-300'
                                : 'text-emerald-300'
                          }`}
                        >
                          {currentObserved ? `${tempValue > 0 ? `+${tempValue}` : tempValue} °C` : '? °C'}
                        </div>
                      </div>
                    </div>

                    <div className="mt-2.5 flex items-center justify-between text-xs font-bold text-slate-300">
                      <span className={obs.day ? 'text-amber-300' : 'text-slate-400'}>
                        {obs.day ? `✓ Dia: ${reg.dayTempC}°C` : '○ Dia'}
                      </span>
                      <span className={obs.night ? 'text-indigo-300' : 'text-slate-400'}>
                        {obs.night ? `✓ Noite: ${reg.nightTempC}°C` : '○ Noite'}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selected Region Insight + Space Destination Comparison Strip */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-5">
              <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/55 p-3.5 text-xs sm:text-sm text-sky-100 leading-relaxed">
                <span className="font-extrabold text-amber-300 block mb-1">
                  {selectedRegion?.name} (MOD11A1 V061 · 1 km)
                </span>
                {selectedRegion?.hint}
              </div>

              {spaceRef && (
                <div className="rounded-2xl border-2 border-rose-300/45 bg-rose-950/35 p-3.5 text-xs sm:text-sm text-rose-100 leading-relaxed tabular-nums">
                  <span className="font-extrabold text-amber-300 block mb-1">
                    Comparação Espacial — {spaceRef.name}: Dia +{spaceRef.dayTempC} °C / Noite {spaceRef.nightTempC} °C
                  </span>
                  {spaceRef.note}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between gap-3">
              <p className="text-xs sm:text-sm font-bold text-sky-200">
                {canProceedToStep2
                  ? 'Ótimo! Já recolheste dados diurnos e nocturnos.'
                  : data.scanInstruction}
              </p>
              <ArcadeButton
                variant="yellow"
                onClick={() => canProceedToStep2 && onSetStep(2)}
                className={`!min-w-[165px] !min-h-[50px] !text-base ${
                  !canProceedToStep2 ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                <span>{data.nextStepLabel}</span>
                <ArrowRight size={18} />
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* STEP 2: Compare Temperatures */}
        {currentStep === 2 && (
          <div>
            {/* Quick MODIS Reference Summary Strip */}
            <div className="grid grid-cols-3 gap-2 mb-4 text-center text-xs sm:text-sm tabular-nums">
              {regions.map((reg) => (
                <div
                  key={reg.id}
                  className="rounded-xl border border-sky-300/35 bg-slate-950/55 px-2 py-2"
                >
                  <div className="font-extrabold text-white">{reg.name}</div>
                  <div className="text-amber-300 font-bold">
                    Dia: {reg.dayTempC}°C · Noite: {reg.nightTempC}°C
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-col gap-4 mb-5">
              {questions.map((q, idx) => {
                const ans = modisState.comparisonAnswers?.[q.id];
                const isSolved = Boolean(ans?.correct);

                return (
                  <div
                    key={q.id}
                    className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/55 p-4"
                  >
                    <h3 className="text-sm sm:text-base font-extrabold text-amber-200 mb-3">
                      {idx + 1}. {q.prompt}
                    </h3>

                    <div className="grid grid-cols-1 gap-2">
                      {q.options.map((opt) => {
                        const isPicked = ans?.selectedId === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            disabled={isSolved}
                            onClick={() => onAnswerComparison(q.id, opt.id)}
                            className={`text-left rounded-xl border-2 px-3.5 py-2.5 text-xs sm:text-sm font-bold transition-colors cursor-pointer ${
                              isPicked && opt.correct
                                ? 'border-emerald-400 bg-emerald-600/35 text-white'
                                : isPicked && !opt.correct
                                  ? 'border-rose-400 bg-rose-600/35 text-white'
                                  : 'border-white/20 bg-slate-900/70 text-sky-50 hover:border-amber-300'
                            }`}
                          >
                            {opt.text}
                          </button>
                        );
                      })}
                    </div>

                    {ans && (
                      <p
                        className={`mt-2.5 text-xs sm:text-sm font-bold ${
                          ans.correct ? 'text-emerald-300' : 'text-rose-300'
                        }`}
                      >
                        {ans.correct ? q.feedbackCorrect : q.feedbackWrong}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => onSetStep(1)}
                className="inline-flex items-center gap-1.5 rounded-full border-2 border-white/50 px-4 py-2 text-sm font-bold text-white hover:bg-white/10 cursor-pointer"
              >
                <ArrowLeft size={16} />
                <span>{data.prevStepLabel}</span>
              </button>

              <ArcadeButton
                variant="yellow"
                onClick={() => allQuestionsSolved && onSetStep(3)}
                className={`!min-w-[165px] !min-h-[50px] !text-base ${
                  !allQuestionsSolved ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                <span>{data.nextStepLabel}</span>
                <ArrowRight size={18} />
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* STEP 3: Space Habitat Thermal Insulation Builder */}
        {currentStep === 3 && (
          <div>
            <p className="text-sm sm:text-base text-sky-100 mb-4">
              {builder.instruction}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center mb-5">
              {/* Left: Live Space Habitat Dome & Day/Night Internal Gauges */}
              <div className="md:col-span-6 rounded-2xl border-2 border-sky-300/45 bg-slate-950/60 p-4">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <button
                    type="button"
                    onClick={() => setSimTime('day')}
                    className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-extrabold cursor-pointer ${
                      simTime === 'day'
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-slate-800 text-slate-200'
                    }`}
                  >
                    <Sun size={14} /> Simular Dia
                  </button>
                  <button
                    type="button"
                    onClick={() => setSimTime('night')}
                    className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-extrabold cursor-pointer ${
                      simTime === 'night'
                        ? 'bg-indigo-500 text-white'
                        : 'bg-slate-800 text-slate-200'
                    }`}
                  >
                    <Moon size={14} /> Simular Noite
                  </button>
                </div>

                <HabitatDomeIllustration
                  installedLayers={installedLayers}
                  isNight={simTime === 'night'}
                  destinationId={gameState.selectedDestination}
                  isSafe={telemetry.isFullyProtected}
                />

                {/* Internal Temperature Readouts */}
                <div className="grid grid-cols-2 gap-2.5 mt-3 tabular-nums">
                  <div
                    className={`rounded-xl border-2 p-2.5 text-center ${
                      telemetry.isDaySafe
                        ? 'border-emerald-400 bg-emerald-950/50'
                        : 'border-orange-400 bg-orange-950/45'
                    }`}
                  >
                    <div className="text-xs font-bold text-slate-200 flex items-center justify-center gap-1">
                      <Thermometer size={14} /> Interior (Dia)
                    </div>
                    <div className="text-xl font-extrabold text-white">
                      {telemetry.dayInternalC > 0 ? `+${telemetry.dayInternalC}` : telemetry.dayInternalC} °C
                    </div>
                    <div className="text-xs font-extrabold text-emerald-300">
                      {telemetry.isDaySafe ? 'SEGURO' : 'MUITO QUENTE'}
                    </div>
                  </div>

                  <div
                    className={`rounded-xl border-2 p-2.5 text-center ${
                      telemetry.isNightSafe
                        ? 'border-emerald-400 bg-emerald-950/50'
                        : 'border-cyan-400 bg-cyan-950/45'
                    }`}
                  >
                    <div className="text-xs font-bold text-slate-200 flex items-center justify-center gap-1">
                      <Thermometer size={14} /> Interior (Noite)
                    </div>
                    <div className="text-xl font-extrabold text-white">
                      {telemetry.nightInternalC > 0 ? `+${telemetry.nightInternalC}` : telemetry.nightInternalC} °C
                    </div>
                    <div className="text-xs font-extrabold text-emerald-300">
                      {telemetry.isNightSafe ? 'SEGURO' : 'MUITO FRIO'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: Selectable Insulation Layers */}
              <div className="md:col-span-6 flex flex-col gap-2.5">
                {(builder.layers || []).map((layer) => {
                  const isEquipped = installedLayers.includes(layer.id);
                  return (
                    <button
                      key={layer.id}
                      type="button"
                      onClick={() => onToggleLayer(layer.id)}
                      aria-pressed={isEquipped}
                      className={`flex items-start justify-between gap-3 rounded-2xl border-2 p-3 text-left transition-colors cursor-pointer ${
                        isEquipped
                          ? layer.isThermal
                            ? 'border-emerald-400 bg-emerald-600/25'
                            : 'border-amber-400 bg-amber-600/25'
                          : 'border-white/25 bg-slate-900/65 hover:border-amber-300'
                      }`}
                    >
                      <div>
                        <div className="text-sm font-extrabold text-white">
                          {layer.name}
                        </div>
                        <div className="text-xs text-sky-100 mt-0.5">
                          {layer.description}
                        </div>
                      </div>
                      <span
                        className={`w-7 h-7 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 ${
                          isEquipped
                            ? 'border-white bg-emerald-500 text-white'
                            : 'border-white/40 bg-slate-800 text-transparent'
                        }`}
                      >
                        <Check size={16} strokeWidth={3} />
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => onSetStep(2)}
                className="inline-flex items-center gap-1.5 rounded-full border-2 border-white/50 px-4 py-2 text-sm font-bold text-white hover:bg-white/10 cursor-pointer"
              >
                <ArrowLeft size={16} />
                <span>{data.prevStepLabel}</span>
              </button>

              <ArcadeButton
                variant="yellow"
                onClick={() => telemetry.isFullyProtected && onValidateHabitat()}
                className={`!min-w-[225px] !min-h-[52px] !text-base ${
                  !telemetry.isFullyProtected ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                <ShieldCheck size={20} />
                <span>{builder.completeButtonLabel}</span>
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* STEP 4: Mission Completion Celebration */}
        {currentStep === 4 && (
          <div className="flex flex-col items-center text-center py-3">
            <div className="w-[125px] mb-2">
              <AstronautCharacter
                character={gameState.character}
                options={persOptions}
                size={125}
                waving
                className="w-full h-auto"
              />
            </div>

            <div className="flex items-center gap-2 mb-3" aria-label={`${modisState.completedStars || 3} estrelas`}>
              {[1, 2, 3].map((idx) => (
                <Star
                  key={idx}
                  size={34}
                  className={
                    idx <= (modisState.completedStars || 3)
                      ? 'text-amber-300 fill-amber-300 drop-shadow-[0_0_10px_rgba(251,191,36,0.6)]'
                      : 'text-slate-600'
                  }
                />
              ))}
            </div>

            <h3
              className="text-2xl sm:text-3xl font-extrabold text-amber-300 mb-3"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {data.completionTitle}
            </h3>

            <p className="text-sm sm:text-base text-sky-100 max-w-xl leading-relaxed mb-6">
              {data.completionSummary}
            </p>

            <ArcadeButton
              variant="yellow"
              onClick={onFinishMission}
              className="!min-w-[210px] !min-h-[56px] !text-lg"
            >
              <span>{mission.continueLabel || 'Continuar'}</span>
            </ArcadeButton>
          </div>
        )}
      </div>
    </div>
  );
}
