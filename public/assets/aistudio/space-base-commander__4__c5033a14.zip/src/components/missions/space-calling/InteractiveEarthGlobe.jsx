import React, { useRef, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';

function normalizeLonDiff(lonDeg, rotDeg) {
  let diff = ((lonDeg - rotDeg + 540) % 360) - 180;
  return diff;
}

function projectPoint(lonDeg, latDeg, rotDeg, cx = 170, cy = 170, r = 132) {
  const diffDeg = normalizeLonDiff(lonDeg, rotDeg);
  const visible = Math.abs(diffDeg) <= 88;
  const lambda = (diffDeg * Math.PI) / 180;
  const phi = (latDeg * Math.PI) / 180;

  const x = cx + r * Math.cos(phi) * Math.sin(lambda);
  const y = cy - r * Math.sin(phi);
  return { x, y, visible, diffDeg };
}

export default function InteractiveEarthGlobe({
  regions,
  selectedRegionId,
  compareRegionId,
  activeLayers,
  rotationLon,
  zoom,
  onChangeRotation,
  onChangeZoom,
  onSelectRegion,
}) {
  const dragRef = useRef({ dragging: false, startX: 0, startLon: 0 });
  const [isDragging, setIsDragging] = useState(false);

  const handlePointerDown = (e) => {
    dragRef.current = {
      dragging: true,
      startX: e.clientX,
      startLon: rotationLon,
    };
    setIsDragging(true);
  };

  const handlePointerMove = (e) => {
    if (!dragRef.current.dragging) return;
    const dx = e.clientX - dragRef.current.startX;
    onChangeRotation(dragRef.current.startLon - dx * 0.6);
  };

  const handlePointerUp = () => {
    dragRef.current.dragging = false;
    setIsDragging(false);
  };

  const hasLayer = (id) => activeLayers.includes(id);

  // Stylized continent anchors projected smoothly as the globe rotates
  const continentBlobs = [
    { id: 'americas_n', lon: -95, lat: 40, rx: 32, ry: 26, fill: '#22c55e' },
    { id: 'americas_s', lon: -60, lat: -14, rx: 24, ry: 30, fill: '#16a34a' },
    { id: 'europe_c', lon: 14, lat: 50, rx: 24, ry: 18, fill: '#22c55e' },
    { id: 'africa', lon: 18, lat: 8, rx: 28, ry: 34, fill: '#eab308' },
    { id: 'asia', lon: 88, lat: 36, rx: 38, ry: 28, fill: '#22c55e' },
    { id: 'arctic', lon: -30, lat: 74, rx: 46, ry: 14, fill: '#e0f2fe' },
  ];

  return (
    <div className="rounded-2xl border-2 border-sky-400/60 bg-[#050b20] p-3 flex flex-col items-center">
      <div className="w-full flex items-center justify-between gap-2 mb-2">
        <span className="text-xs font-extrabold uppercase tracking-wider text-sky-300">
          Globo Terrestre Interativo
        </span>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => onChangeRotation(rotationLon - 35)}
            aria-label="Rodar globo para a esquerda"
            className="w-8 h-8 rounded-lg border border-sky-300/40 bg-slate-900 hover:border-amber-300 flex items-center justify-center text-sky-100 cursor-pointer"
          >
            <ChevronLeft size={16} />
          </button>
          <button
            type="button"
            onClick={() => onChangeRotation(rotationLon + 35)}
            aria-label="Rodar globo para a direita"
            className="w-8 h-8 rounded-lg border border-sky-300/40 bg-slate-900 hover:border-amber-300 flex items-center justify-center text-sky-100 cursor-pointer"
          >
            <ChevronRight size={16} />
          </button>
          <button
            type="button"
            onClick={() => onChangeZoom(Math.min(1.36, Number((zoom + 0.14).toFixed(2))))}
            aria-label="Aumentar zoom do globo"
            className="w-8 h-8 rounded-lg border border-sky-300/40 bg-slate-900 hover:border-amber-300 flex items-center justify-center text-sky-100 cursor-pointer"
          >
            <ZoomIn size={15} />
          </button>
          <button
            type="button"
            onClick={() => onChangeZoom(Math.max(0.86, Number((zoom - 0.14).toFixed(2))))}
            aria-label="Diminuir zoom do globo"
            className="w-8 h-8 rounded-lg border border-sky-300/40 bg-slate-900 hover:border-amber-300 flex items-center justify-center text-sky-100 cursor-pointer"
          >
            <ZoomOut size={15} />
          </button>
          <button
            type="button"
            onClick={() => {
              onChangeRotation(0);
              onChangeZoom(1);
            }}
            aria-label="Repor vista do globo"
            title="Repor vista"
            className="w-8 h-8 rounded-lg border border-sky-300/40 bg-slate-900 hover:border-amber-300 flex items-center justify-center text-sky-100 cursor-pointer"
          >
            <RotateCcw size={14} />
          </button>
        </div>
      </div>

      {/* Interactive SVG Globe */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        className={`relative w-full max-w-[330px] aspect-square flex items-center justify-center select-none touch-none ${
          isDragging ? 'cursor-grabbing' : 'cursor-grab'
        }`}
      >
        <svg
          viewBox="0 0 340 340"
          className="w-full h-full transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
          role="img"
          aria-label="Globo interativo da Terra com camadas NASA Earthdata"
        >
          <defs>
            <clipPath id="earthSphereClip">
              <circle cx="170" cy="170" r="132" />
            </clipPath>
            <radialGradient id="oceanGrad" cx="35%" cy="32%" r="72%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="55%" stopColor="#0284c7" />
              <stop offset="100%" stopColor="#0f172a" />
            </radialGradient>
            <radialGradient id="limbShade" cx="50%" cy="50%" r="52%">
              <stop offset="72%" stopColor="rgba(15,23,42,0)" />
              <stop offset="100%" stopColor="rgba(2,6,23,0.58)" />
            </radialGradient>
          </defs>

          {/* Outer Atmospheric Halo */}
          <circle cx="170" cy="170" r="142" fill="rgba(56,189,248,0.16)" />
          {/* Base Ocean Sphere */}
          <circle cx="170" cy="170" r="132" fill="url(#oceanGrad)" stroke="#7dd3fc" strokeWidth="2.5" />

          {/* Clipped Continents & Earthdata Overlays */}
          <g clipPath="url(#earthSphereClip)">
            {/* Subtle Latitude Grid */}
            {[-45, 0, 45].map((lat) => {
              const py = 170 - 132 * Math.sin((lat * Math.PI) / 180);
              return (
                <line
                  key={lat}
                  x1="38"
                  y1={py}
                  x2="302"
                  y2={py}
                  stroke="rgba(255,255,255,0.12)"
                  strokeWidth="1"
                  strokeDasharray="4 4"
                />
              );
            })}

            {/* Continents */}
            {continentBlobs.map((blob) => {
              const p = projectPoint(blob.lon, blob.lat, rotationLon);
              if (!p.visible) return null;
              const foreshorten = Math.max(0.25, Math.cos((p.diffDeg * Math.PI) / 180));
              return (
                <ellipse
                  key={blob.id}
                  cx={p.x}
                  cy={p.y}
                  rx={blob.rx * foreshorten}
                  ry={blob.ry}
                  fill={blob.fill}
                  opacity="0.88"
                />
              );
            })}

            {/* Layer Overlay: MODIS (Temperature Zones) */}
            {hasLayer('modis') &&
              regions.map((reg) => {
                const p = projectPoint(reg.lon, reg.lat, rotationLon);
                if (!p.visible) return null;
                const hot = reg.modisTempC >= 28;
                const cold = reg.modisTempC < 0;
                const fill = hot ? '#f97316' : cold ? '#67e8f9' : '#facc15';
                return (
                  <circle
                    key={`modis-${reg.id}`}
                    cx={p.x}
                    cy={p.y}
                    r={hot ? 28 : 22}
                    fill={fill}
                    opacity="0.42"
                  />
                );
              })}

            {/* Layer Overlay: MERRA-2 (Atmospheric Aerosols) */}
            {hasLayer('merra2') &&
              regions.map((reg) => {
                const p = projectPoint(reg.lon, reg.lat, rotationLon);
                if (!p.visible) return null;
                const intense = reg.id === 'sahara';
                return (
                  <g key={`merra-${reg.id}`} opacity={intense ? 0.72 : 0.38}>
                    <ellipse cx={p.x} cy={p.y} rx={intense ? 34 : 18} ry={intense ? 18 : 10} fill="#a855f7" />
                    <ellipse cx={p.x + 12} cy={p.y - 6} rx={intense ? 22 : 12} ry={9} fill="#c084fc" />
                  </g>
                );
              })}

            {/* Layer Overlay: SRTM (Elevation Rings & Mountain Peaks) */}
            {hasLayer('srtm') &&
              regions.map((reg) => {
                const p = projectPoint(reg.lon, reg.lat, rotationLon);
                if (!p.visible) return null;
                const isHigh = reg.srtmElevationM >= 1000;
                return (
                  <g key={`srtm-${reg.id}`}>
                    <circle
                      cx={p.x}
                      cy={p.y}
                      r={isHigh ? 24 : 16}
                      fill="none"
                      stroke="#4ade80"
                      strokeWidth="2.5"
                      strokeDasharray={isHigh ? '3 2' : 'none'}
                    />
                    {isHigh && (
                      <polygon
                        points={`${p.x},${p.y - 18} ${p.x - 10},${p.y + 4} ${p.x + 10},${p.y + 4}`}
                        fill="#86efac"
                        opacity="0.8"
                      />
                    )}
                  </g>
                );
              })}

            {/* Layer Overlay: GPM IMERG (Rainfall Clouds & Drops) */}
            {hasLayer('gpm') &&
              regions.map((reg) => {
                const p = projectPoint(reg.lon, reg.lat, rotationLon);
                if (!p.visible || reg.gpmRainMm < 30) return null;
                const heavy = reg.gpmRainMm >= 200;
                return (
                  <g key={`gpm-${reg.id}`} opacity={heavy ? 0.85 : 0.55}>
                    <ellipse cx={p.x - 6} cy={p.y - 12} rx={heavy ? 22 : 15} ry={10} fill="#7dd3fc" />
                    <line x1={p.x - 8} y1={p.y} x2={p.x - 11} y2={p.y + 10} stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
                    <line x1={p.x + 2} y1={p.y} x2={p.x - 1} y2={p.y + 10} stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />
                  </g>
                );
              })}

            {/* Layer Overlay: SMAP (Soil Moisture Rings) */}
            {hasLayer('smap') &&
              regions.map((reg) => {
                const p = projectPoint(reg.lon, reg.lat, rotationLon);
                if (!p.visible) return null;
                const wet = reg.id === 'amazon' || reg.id === 'europe';
                return (
                  <circle
                    key={`smap-${reg.id}`}
                    cx={p.x}
                    cy={p.y}
                    r="20"
                    fill="none"
                    stroke={wet ? '#14b8a6' : '#f59e0b'}
                    strokeWidth="3"
                    opacity="0.85"
                  />
                );
              })}

            {/* 3D Spherical Shading */}
            <circle cx="170" cy="170" r="132" fill="url(#limbShade)" pointerEvents="none" />
          </g>

          {/* Clickable Region Markers */}
          {regions.map((reg) => {
            const p = projectPoint(reg.lon, reg.lat, rotationLon);
            if (!p.visible) return null;
            const isSelected = reg.id === selectedRegionId;
            const isCompare = reg.id === compareRegionId;

            return (
              <g
                key={reg.id}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectRegion(reg.id);
                }}
                className="cursor-pointer"
                role="button"
                tabIndex={0}
                aria-label={`Selecionar região ${reg.name}`}
              >
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={isSelected ? 11 : 8}
                  fill={isSelected ? '#fde047' : isCompare ? '#2dd4bf' : '#ffffff'}
                  stroke="#0f172a"
                  strokeWidth="2.5"
                />
                <text
                  x={p.x}
                  y={p.y - 14}
                  textAnchor="middle"
                  fontSize="10"
                  fontWeight="800"
                  fill="#ffffff"
                  stroke="#0f172a"
                  strokeWidth="3"
                  paintOrder="stroke"
                >
                  {reg.name.split(' ').slice(-1)[0]}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Quick Region Jump Buttons (works even if a region is on the back side of the globe) */}
      <div className="w-full mt-2">
        <div className="text-[11px] font-bold text-sky-300 text-center mb-1.5">
          Arrasta o globo ou clica numa região para focar:
        </div>
        <div className="flex flex-wrap items-center justify-center gap-1.5">
          {regions.map((reg) => {
            const isSelected = reg.id === selectedRegionId;
            return (
              <button
                key={reg.id}
                type="button"
                onClick={() => {
                  onChangeRotation(reg.lon);
                  onSelectRegion(reg.id);
                }}
                className={`rounded-xl border px-2.5 py-1 text-[11px] font-extrabold transition-colors cursor-pointer ${
                  isSelected
                    ? 'border-amber-300 bg-amber-400 text-slate-950'
                    : 'border-sky-300/35 bg-slate-900 text-sky-100 hover:border-amber-300'
                }`}
              >
                {reg.name}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
