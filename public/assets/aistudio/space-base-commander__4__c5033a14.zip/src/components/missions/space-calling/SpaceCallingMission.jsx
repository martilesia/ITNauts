import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import AstronautCharacter from '../../AstronautCharacter.jsx';
import {
  INITIAL_SPACE_CALLING_STATE,
  SPACE_CALLING_SCREENS,
  getDestinationLabel,
} from '../../../logic/spaceCallingEngine.js';
import {
  playClickSound,
  playErrorSound,
  playStartFanfare,
  playSuccessSound,
} from '../../../utils/soundFx.js';
import MissionControlRoom from './MissionControlRoom.jsx';
import EarthDataLaboratory from './EarthDataLaboratory.jsx';
import ScientificExperiments from './ScientificExperiments.jsx';
import MissionCompletion from './MissionCompletion.jsx';

const FALLBACK_EARTHDATA = {
  sourceNote:
    'Dados educativos ilustrativos baseados nos produtos NASA Earthdata para a Terra (não representam medições da Lua ou de Marte).',
  layers: [
    {
      id: 'modis',
      name: 'MODIS',
      fullTitle: 'Temperatura da Superfície Terrestre',
      color: '#f97316',
      shortDesc: 'Mede o calor e o frio da superfície da Terra de dia e de noite.',
      practicalTip: 'Clica nas regiões do globo para comparar zonas escaldantes e geladas.',
    },
    {
      id: 'merra2',
      name: 'MERRA-2',
      fullTitle: 'Aerossóis na Atmosfera',
      color: '#a855f7',
      shortDesc: 'Mostra poeiras e partículas minúsculas que flutuam no ar terrestre.',
      practicalTip: 'Observa as manchas roxas sobre os grandes desertos.',
    },
    {
      id: 'srtm',
      name: 'SRTM',
      fullTitle: 'Relevo e Altitude',
      color: '#22c55e',
      shortDesc: 'Mapeia montanhas altas, vales profundos e planícies planas.',
      practicalTip: 'Identifica cordilheiras altas e zonas planas ideais para aterrar.',
    },
    {
      id: 'gpm',
      name: 'GPM IMERG',
      fullTitle: 'Precipitação Global',
      color: '#38bdf8',
      shortDesc: 'Regista onde e com que intensidade cai chuva na Terra.',
      practicalTip: 'Nota como as zonas tropicais recebem muito mais chuva.',
    },
    {
      id: 'smap',
      name: 'SMAP',
      fullTitle: 'Humidade do Solo',
      color: '#14b8a6',
      shortDesc: 'Mede quanta água está retida na camada superior do solo.',
      practicalTip: 'Compara solos secos de deserto com solos húmidos de floresta.',
    },
  ],
  regions: [
    {
      id: 'sahara',
      name: 'Deserto do Saara',
      lon: 12,
      lat: 23,
      modisTempC: 49,
      merra2Aerosol: 'Alto (Poeira intensa)',
      srtmElevationM: 420,
      srtmType: 'Planalto arenoso',
      gpmRainMm: 5,
      smapMoisture: '8% (Muito seco)',
    },
    {
      id: 'amazon',
      name: 'Bacia Amazónica',
      lon: -62,
      lat: -4,
      modisTempC: 30,
      merra2Aerosol: 'Baixo (Ar limpo)',
      srtmElevationM: 110,
      srtmType: 'Planície extensa',
      gpmRainMm: 295,
      smapMoisture: '78% (Muito húmido)',
    },
    {
      id: 'himalayas',
      name: 'Cordilheira dos Himalaias',
      lon: 86,
      lat: 29,
      modisTempC: -8,
      merra2Aerosol: 'Baixo a Moderado',
      srtmElevationM: 5400,
      srtmType: 'Montanhas íngremes',
      gpmRainMm: 110,
      smapMoisture: '34% (Moderado)',
    },
    {
      id: 'europe',
      name: 'Europa Central',
      lon: 14,
      lat: 50,
      modisTempC: 21,
      merra2Aerosol: 'Baixo',
      srtmElevationM: 260,
      srtmType: 'Vale e colinas suaves',
      gpmRainMm: 78,
      smapMoisture: '52% (Equilibrado)',
    },
    {
      id: 'arctic',
      name: 'Região Ártica',
      lon: -40,
      lat: 72,
      modisTempC: -24,
      merra2Aerosol: 'Muito baixo',
      srtmElevationM: 850,
      srtmType: 'Calota gelada',
      gpmRainMm: 18,
      smapMoisture: '15% (Solo gelado)',
    },
  ],
};

export default function SpaceCallingMission({
  isOpen,
  mission,
  gameState,
  persOptions,
  onCompleteMission,
  onClose,
}) {
  const [state, setState] = useState(INITIAL_SPACE_CALLING_STATE);
  const [activeStationId, setActiveStationId] = useState(null);
  const [earthdata, setEarthdata] = useState(FALLBACK_EARTHDATA);

  const audioEnabled = Boolean(gameState?.audioEnabled);

  useEffect(() => {
    if (!isOpen) return;
    setState(INITIAL_SPACE_CALLING_STATE);
    setActiveStationId(null);

    const url = mission?.earthdataUrl || '/data/earthdata-overview.json';
    fetch(url)
      .then((res) => (res.ok ? res.json() : FALLBACK_EARTHDATA))
      .then((json) => {
        if (json && Array.isArray(json.layers) && Array.isArray(json.regions)) {
          setEarthdata(json);
        }
      })
      .catch(() => setEarthdata(FALLBACK_EARTHDATA));
  }, [isOpen, mission]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen || !mission) return null;

  const currentScreen = state.screen;
  const destinationName = getDestinationLabel(gameState?.selectedDestination);

  const goToScreen = (nextScreen) => {
    setState((prev) => ({ ...prev, screen: nextScreen }));
    if (nextScreen === 4) {
      playStartFanfare(audioEnabled);
    } else {
      playClickSound(audioEnabled);
    }
  };

  const handleInspectStation = (stationId) => {
    playSuccessSound(audioEnabled);
    setActiveStationId(stationId);
    setState((prev) => ({
      ...prev,
      inspectedStations: prev.inspectedStations.includes(stationId)
        ? prev.inspectedStations
        : [...prev.inspectedStations, stationId],
    }));
  };

  const handleToggleLayer = (layerId) => {
    playClickSound(audioEnabled);
    setState((prev) => {
      const isOn = prev.activeLayers.includes(layerId);
      const nextActive = isOn
        ? prev.activeLayers.length > 1
          ? prev.activeLayers.filter((id) => id !== layerId)
          : prev.activeLayers
        : [...prev.activeLayers, layerId];
      const nextExplored = prev.exploredLayers.includes(layerId)
        ? prev.exploredLayers
        : [...prev.exploredLayers, layerId];
      return {
        ...prev,
        activeLayers: nextActive,
        exploredLayers: nextExplored,
      };
    });
  };

  const handleSelectRegion = (regionId) => {
    playClickSound(audioEnabled);
    setState((prev) => ({
      ...prev,
      selectedRegionId: regionId,
      exploredRegions: prev.exploredRegions.includes(regionId)
        ? prev.exploredRegions
        : [...prev.exploredRegions, regionId],
    }));
  };

  const handleSelectCompareRegion = (regionId) => {
    playClickSound(audioEnabled);
    setState((prev) => ({
      ...prev,
      compareRegionId: regionId,
      exploredRegions: prev.exploredRegions.includes(regionId)
        ? prev.exploredRegions
        : [...prev.exploredRegions, regionId],
    }));
  };

  const handleCompleteExperiment = (expKey) => {
    setState((prev) => ({
      ...prev,
      experimentsCompleted: {
        ...prev.experimentsCompleted,
        [expKey]: true,
      },
    }));
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-5 bg-[#050a1e]/90 backdrop-blur-sm overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="space-calling-title"
    >
      <div className="relative w-full max-w-5xl my-auto rounded-[28px] border-4 border-sky-300 bg-gradient-to-b from-[#1f2269] via-[#17286a] to-[#0d163c] p-4 sm:p-6 shadow-[0_24px_70px_rgba(0,0,0,0.85)] text-white">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Voltar à base espacial"
          className="absolute top-4 right-4 w-10 h-10 rounded-full border-2 border-white/80 bg-rose-600 hover:bg-rose-500 flex items-center justify-center text-white shadow-md cursor-pointer"
        >
          <X size={20} strokeWidth={2.75} />
        </button>

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pr-12 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl border-2 border-amber-300 bg-slate-900/80 flex items-center justify-center overflow-hidden shrink-0">
              <AstronautCharacter
                character={gameState?.character}
                options={persOptions}
                size={46}
                className="w-11 h-auto"
              />
            </div>
            <div>
              <div className="text-xs font-extrabold uppercase tracking-wider text-amber-300">
                Missão 1 · Destino: {destinationName}
              </div>
              <h2
                id="space-calling-title"
                className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white leading-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                O Chamamento Espacial
              </h2>
            </div>
          </div>

          <div className="text-xs font-extrabold text-cyan-200 rounded-xl border border-cyan-300/40 bg-slate-950/70 px-3 py-1.5 self-start sm:self-auto">
            Observação NASA Earthdata
          </div>
        </div>

        {/* 4-Screen Progress Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 mb-5">
          {SPACE_CALLING_SCREENS.map((scr) => {
            const isActive = currentScreen === scr.id;
            const isDone = currentScreen > scr.id;
            return (
              <div
                key={scr.id}
                className={`rounded-xl border px-2.5 py-1.5 text-center text-xs font-extrabold truncate ${
                  isActive
                    ? 'border-amber-300 bg-amber-400 text-slate-950'
                    : isDone
                      ? 'border-emerald-400/70 bg-emerald-500/25 text-emerald-200'
                      : 'border-white/15 bg-slate-950/55 text-slate-400'
                }`}
              >
                {scr.label}
              </div>
            );
          })}
        </div>

        {/* Screen 1: Entrada na missão */}
        {currentScreen === 1 && (
          <MissionControlRoom
            character={gameState?.character}
            persOptions={persOptions}
            selectedDestination={gameState?.selectedDestination}
            inspectedStations={state.inspectedStations}
            activeStationId={activeStationId}
            onInspectStation={handleInspectStation}
            onStartLaboratory={() => goToScreen(2)}
          />
        )}

        {/* Screen 2: Laboratório de Observação da Terra */}
        {currentScreen === 2 && (
          <EarthDataLaboratory
            earthdata={earthdata}
            state={state}
            onToggleLayer={handleToggleLayer}
            onSelectRegion={handleSelectRegion}
            onSelectCompareRegion={handleSelectCompareRegion}
            onChangeRotation={(lon) =>
              setState((prev) => ({ ...prev, globeRotationLon: lon }))
            }
            onChangeZoom={(zoom) =>
              setState((prev) => ({ ...prev, globeZoom: zoom }))
            }
            onBackToControlRoom={() => goToScreen(1)}
            onProceedToExperiments={() => goToScreen(3)}
          />
        )}

        {/* Screen 3: Centro de Experiências Científicas */}
        {currentScreen === 3 && (
          <ScientificExperiments
            completedMap={state.experimentsCompleted}
            onCompleteExperiment={handleCompleteExperiment}
            onPlaySuccess={() => playSuccessSound(audioEnabled)}
            onPlayError={() => playErrorSound(audioEnabled)}
            onPlayClick={() => playClickSound(audioEnabled)}
            onBackToLab={() => goToScreen(2)}
            onFinishExperiments={() => goToScreen(4)}
          />
        )}

        {/* Screen 4: Preparação para a Expedição */}
        {currentScreen === 4 && (
          <MissionCompletion
            character={gameState?.character}
            persOptions={persOptions}
            selectedDestination={gameState?.selectedDestination}
            state={state}
            onReturnToBase={(stars) => onCompleteMission(stars)}
          />
        )}
      </div>
    </div>
  );
}
