import React, { useState } from 'react';
import {
  CheckCircle2,
  CloudRain,
  Droplets,
  Mountain,
  ShieldCheck,
  Sparkles,
  Sun,
  Thermometer,
  Wind,
} from 'lucide-react';
import ArcadeButton from '../../ArcadeButton.jsx';

const EXPERIMENT_TABS = [
  { id: 'tempDetective', label: 'A. Temperatura (MODIS)', icon: Thermometer },
  { id: 'terrainExplorer', label: 'B. Relevo (SRTM)', icon: Mountain },
  { id: 'waterInvestigator', label: 'C. Água (GPM + SMAP)', icon: Droplets },
  { id: 'atmosphereObserver', label: 'D. Atmosfera (MERRA-2)', icon: Wind },
];

/* Experiment A: MODIS Thermal Habitat Material Testing */
const THERMAL_ZONES = [
  { id: 'sahara', label: 'Saara (49°C)', extTemp: 49, badge: 'Calor Extremo' },
  { id: 'europe', label: 'Europa (21°C)', extTemp: 21, badge: 'Temperado' },
  { id: 'arctic', label: 'Ártico (-24°C)', extTemp: -24, badge: 'Frio Extremo' },
];

const THERMAL_MATERIALS = [
  {
    id: 'thin_glass',
    label: 'Vidro Fino Simples',
    insulationPower: 15,
    desc: 'Deixa passar quase todo o calor e frio.',
  },
  {
    id: 'reflective_shield',
    label: 'Escudo Refletor Solar',
    insulationPower: 55,
    desc: 'Reflete os raios quentes em zonas escaldantes.',
  },
  {
    id: 'double_thermal',
    label: 'Isolamento Térmico Duplo',
    insulationPower: 85,
    desc: 'Protege contra calor extremo e frio glacial!',
  },
];

/* Experiment B: SRTM Terrain Landing Simulator */
const TERRAIN_ZONES = [
  {
    id: 'mountain',
    label: 'Montanhas Íngremes',
    altitude: '5400 m',
    slopeDeg: 38,
    stability: 28,
    safe: false,
    pathD: 'M10 110 L65 25 L125 90 L185 18 L245 95 L290 110 L290 130 L10 130 Z',
    podX: 185,
    podY: 22,
    podRotate: 26,
    feedback: 'Encosta muito inclinada! O módulo inclina demasiado e o rover não consegue sair em segurança.',
  },
  {
    id: 'valley',
    label: 'Vale Estreito e Colinas',
    altitude: '260 m',
    slopeDeg: 18,
    stability: 64,
    safe: false,
    pathD: 'M10 45 L80 98 L150 106 L220 96 L290 42 L290 130 L10 130 Z',
    podX: 150,
    podY: 98,
    podRotate: -8,
    feedback: 'O fundo do vale é apertado e as encostas bloqueiam parte da comunicação e do sol.',
  },
  {
    id: 'plain',
    label: 'Planície Extensa',
    altitude: '110 m',
    slopeDeg: 2,
    stability: 98,
    safe: true,
    pathD: 'M10 92 Q80 90 150 92 T290 92 L290 130 L10 130 Z',
    podX: 150,
    podY: 84,
    podRotate: 0,
    feedback: 'Perfeito! A planície plana dá 98% de estabilidade para aterrar o módulo e explorar com o rover.',
  },
];

export default function ScientificExperiments({
  completedMap,
  onCompleteExperiment,
  onPlaySuccess,
  onPlayError,
  onPlayClick,
  onBackToLab,
  onFinishExperiments,
}) {
  const [activeTab, setActiveTab] = useState('tempDetective');

  // Exp A state
  const [zoneA, setZoneA] = useState('sahara');
  const [slotMaterialA, setSlotMaterialA] = useState('thin_glass');
  const [testedZonesA, setTestedZonesA] = useState([]);
  const [feedbackA, setFeedbackA] = useState(null);

  // Exp B state
  const [terrainB, setTerrainB] = useState('mountain');
  const [simulatedB, setSimulatedB] = useState(false);

  // Exp C state
  const [rainMmC, setRainMmC] = useState(220);
  const [soilTypeC, setSoilTypeC] = useState('sandy');
  const [testedSoilsC, setTestedSoilsC] = useState([]);
  const [insightC, setInsightC] = useState(null);

  // Exp D state
  const [aerosolPctD, setAerosolPctD] = useState(20);
  const [testedHighDustD, setTestedHighDustD] = useState(false);
  const [feedbackD, setFeedbackD] = useState(null);

  const completedCount = Object.values(completedMap).filter(Boolean).length;
  const allCompleted = completedCount === 4;

  /* Exp A computed internal temp */
  const currentZoneA = THERMAL_ZONES.find((z) => z.id === zoneA) || THERMAL_ZONES[0];
  const currentMatA = THERMAL_MATERIALS.find((m) => m.id === slotMaterialA) || THERMAL_MATERIALS[0];
  const comfortTarget = 21;
  const internalTempA = Math.round(
    comfortTarget + (currentZoneA.extTemp - comfortTarget) * (1 - currentMatA.insulationPower / 100)
  );
  const isHabitatSafeA = internalTempA >= 16 && internalTempA <= 26;

  const handleTestHabitatA = () => {
    const nextZones = testedZonesA.includes(zoneA) ? testedZonesA : [...testedZonesA, zoneA];
    setTestedZonesA(nextZones);

    if (isHabitatSafeA && (zoneA === 'sahara' || zoneA === 'arctic') && slotMaterialA === 'double_thermal') {
      onPlaySuccess();
      setFeedbackA({
        ok: true,
        text: `Excelente! Mesmo com ${currentZoneA.extTemp}°C no exterior, o Isolamento Térmico Duplo manteve o interior confortável a ${internalTempA}°C!`,
      });
      onCompleteExperiment('tempDetective');
    } else if (zoneA === 'europe') {
      onPlayClick();
      setFeedbackA({
        ok: false,
        text: 'Na Europa (21°C) quase não há diferença térmica! Testa o Saara (49°C) ou o Ártico (-24°C) para pôr o isolamento à prova.',
      });
    } else {
      onPlayError();
      setFeedbackA({
        ok: false,
        text: `Temperatura interior a ${internalTempA}°C — desconfortável! Escolhe um material isolante mais forte no painel do habitat.`,
      });
    }
  };

  /* Exp B computed terrain */
  const currentTerrainB = TERRAIN_ZONES.find((t) => t.id === terrainB) || TERRAIN_ZONES[0];
  const handleSimulateLandingB = () => {
    setSimulatedB(true);
    if (currentTerrainB.safe) {
      onPlaySuccess();
      onCompleteExperiment('terrainExplorer');
    } else {
      onPlayError();
    }
  };

  /* Exp C computed SMAP soil moisture */
  const retentionFactor = soilTypeC === 'forest' ? 0.28 : 0.08;
  const computedSoilMoistureC = Math.min(92, Math.round(rainMmC * retentionFactor + (soilTypeC === 'forest' ? 14 : 3)));

  const handleTestWaterC = (soil) => {
    onPlayClick();
    setSoilTypeC(soil);
    setTestedSoilsC((prev) => (prev.includes(soil) ? prev : [...prev, soil]));
  };

  const handleValidateWaterC = (choiceId) => {
    if (choiceId === 'related_distinct') {
      onPlaySuccess();
      setInsightC({
        ok: true,
        text: 'Correto! O GPM mede a chuva que cai do céu, enquanto o SMAP mede quanta água o solo consegue guardar!',
      });
      onCompleteExperiment('waterInvestigator');
    } else {
      onPlayError();
      setInsightC({
        ok: false,
        text: 'Dica: Repara que com a mesma chuva, a Areia Seca guarda muito menos água no solo do que o Solo de Floresta!',
      });
    }
  };

  /* Exp D computed sunlight reaching ground */
  const sunlightPctD = Math.max(18, Math.round(100 - aerosolPctD * 0.72));
  const handleTestAtmosphereD = () => {
    if (aerosolPctD >= 70) {
      setTestedHighDustD(true);
      onPlaySuccess();
      setFeedbackD({
        ok: true,
        text: `Com ${aerosolPctD}% de aerossóis MERRA-2, só ${sunlightPctD}% da luz solar chega ao solo! Os painéis solares produzem muito menos energia.`,
      });
      onCompleteExperiment('atmosphereObserver');
    } else {
      onPlayClick();
      setTestedHighDustD(false);
      setFeedbackD({
        ok: false,
        text: 'Aumenta os aerossóis para pelo menos 70% (ou escolhe o preset Deserto do Saara) para observar o impacto forte na luz solar!',
      });
    }
  };

  return (
    <div className="space-y-4">
      {/* Experiment Selector Tabs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        {EXPERIMENT_TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          const isDone = Boolean(completedMap[tab.id]);

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                onPlayClick();
                setActiveTab(tab.id);
              }}
              className={`rounded-2xl border-2 px-3 py-2.5 text-left transition-all cursor-pointer flex items-center justify-between gap-2 ${
                isActive
                  ? 'border-amber-300 bg-amber-400 text-slate-950 shadow-md'
                  : isDone
                    ? 'border-emerald-400/70 bg-emerald-950/45 text-emerald-100 hover:border-amber-300'
                    : 'border-white/20 bg-slate-950/75 text-sky-100 hover:border-amber-300'
              }`}
            >
              <div className="flex items-center gap-2 min-w-0">
                <Icon size={17} className="shrink-0" />
                <span className="text-xs font-extrabold truncate">{tab.label}</span>
              </div>
              {isDone && (
                <CheckCircle2
                  size={16}
                  className={isActive ? 'text-slate-950 shrink-0' : 'text-emerald-400 shrink-0'}
                />
              )}
            </button>
          );
        })}
      </div>

      {/* EXPERIMENT A — DETETIVE DA TEMPERATURA (MODIS) */}
      {activeTab === 'tempDetective' && (
        <div className="rounded-2xl border-2 border-orange-400/70 bg-slate-950/80 p-4 space-y-4">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-orange-300">
              Experiência A — Detetive da Temperatura (MODIS)
            </h3>
            <p className="text-xs sm:text-sm font-semibold text-sky-100 mt-1">
              Escolhe uma região extrema da Terra, equipa um material de proteção na parede do habitat e testa se os astronautas ficam confortáveis (entre 16°C e 26°C).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div>
                <div className="text-xs font-extrabold uppercase text-amber-300 mb-1.5">
                  1. Ambiente Térmico Exterior (MODIS)
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {THERMAL_ZONES.map((z) => (
                    <button
                      key={z.id}
                      type="button"
                      onClick={() => {
                        onPlayClick();
                        setZoneA(z.id);
                      }}
                      className={`rounded-xl border-2 p-2 text-center text-xs font-extrabold cursor-pointer ${
                        zoneA === z.id
                          ? 'border-orange-300 bg-orange-500/25 text-white'
                          : 'border-white/15 bg-slate-900 text-sky-200 hover:border-orange-300'
                      }`}
                    >
                      <div>{z.label}</div>
                      <div className="text-[10px] text-orange-200 mt-0.5">{z.badge}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-extrabold uppercase text-amber-300 mb-1.5">
                  2. Material Instalado no Habitat
                </div>
                <div className="space-y-2">
                  {THERMAL_MATERIALS.map((mat) => (
                    <button
                      key={mat.id}
                      type="button"
                      onClick={() => {
                        onPlayClick();
                        setSlotMaterialA(mat.id);
                      }}
                      className={`w-full rounded-xl border-2 p-2.5 text-left cursor-pointer flex items-center justify-between gap-2 ${
                        slotMaterialA === mat.id
                          ? 'border-amber-300 bg-amber-400/20 text-white'
                          : 'border-white/15 bg-slate-900 text-sky-100 hover:border-amber-300'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-extrabold">{mat.label}</div>
                        <div className="text-[11px] text-sky-200">{mat.desc}</div>
                      </div>
                      <span className="text-[11px] font-extrabold text-amber-300 shrink-0">
                        Isolamento {mat.insulationPower}%
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Live Habitat Thermal Simulator */}
            <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-900/90 p-4 flex flex-col justify-between gap-3 tabular-nums">
              <div className="flex items-center justify-between text-xs font-extrabold">
                <span className="text-orange-300">Exterior: {currentZoneA.extTemp}°C</span>
                <span className={isHabitatSafeA ? 'text-emerald-300' : 'text-rose-300'}>
                  Interior: {internalTempA}°C ({isHabitatSafeA ? 'Confortável' : 'Perigoso'})
                </span>
              </div>

              {/* SVG Habitat Cross-Section */}
              <svg viewBox="0 0 260 120" className="w-full h-28 rounded-xl bg-slate-950/90 border border-white/10">
                <rect x="0" y="96" width="260" height="24" fill={currentZoneA.extTemp > 30 ? '#c2410c' : currentZoneA.extTemp < 0 ? '#93c5fd' : '#15803d'} />
                <path
                  d="M65 96 C65 40 195 40 195 96 Z"
                  fill={isHabitatSafeA ? '#0f766e' : '#7f1d1d'}
                  stroke={slotMaterialA === 'double_thermal' ? '#fbbf24' : slotMaterialA === 'reflective_shield' ? '#cbd5e1' : '#38bdf8'}
                  strokeWidth={slotMaterialA === 'double_thermal' ? '7' : '3'}
                />
                <circle cx="130" cy="70" r="14" fill="#e0f2fe" />
                <text x="130" y="74" textAnchor="middle" fontSize="10" fontWeight="800" fill="#0f172a">
                  {internalTempA}°C
                </text>
              </svg>

              <button
                type="button"
                onClick={handleTestHabitatA}
                className="w-full rounded-xl border-2 border-amber-300 bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-sm py-2.5 cursor-pointer"
              >
                Testar Habitat Térmico
              </button>

              {feedbackA && (
                <div
                  className={`rounded-xl border p-2.5 text-xs font-bold ${
                    feedbackA.ok
                      ? 'border-emerald-400 bg-emerald-950/55 text-emerald-200'
                      : 'border-rose-400 bg-rose-950/55 text-rose-200'
                  }`}
                >
                  {feedbackA.text}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* EXPERIMENT B — EXPLORADOR DO RELEVO (SRTM) */}
      {activeTab === 'terrainExplorer' && (
        <div className="rounded-2xl border-2 border-emerald-400/70 bg-slate-950/80 p-4 space-y-4">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-emerald-300">
              Experiência B — Explorador do Relevo (SRTM)
            </h3>
            <p className="text-xs sm:text-sm font-semibold text-sky-100 mt-1">
              Testa aterrar o módulo e o rover em 3 tipos de relevo medidos por radar orbital e descobre qual oferece maior segurança!
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {TERRAIN_ZONES.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  onPlayClick();
                  setTerrainB(t.id);
                  setSimulatedB(false);
                }}
                className={`rounded-2xl border-2 p-3 text-left cursor-pointer ${
                  terrainB === t.id
                    ? 'border-emerald-300 bg-emerald-500/20 text-white'
                    : 'border-white/15 bg-slate-900 text-sky-100 hover:border-emerald-300'
                }`}
              >
                <div className="text-xs font-extrabold">{t.label}</div>
                <div className="text-[11px] font-bold text-emerald-300 mt-1 tabular-nums">
                  Altitude SRTM: {t.altitude} · Inclinação: {t.slopeDeg}°
                </div>
              </button>
            ))}
          </div>

          {/* Interactive Terrain Cross-Section SVG */}
          <div className="rounded-2xl border border-sky-300/40 bg-slate-900/90 p-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-extrabold tabular-nums">
              <span className="text-emerald-300">Perfil SRTM: {currentTerrainB.label}</span>
              <span className={currentTerrainB.safe ? 'text-emerald-300' : 'text-amber-300'}>
                Estabilidade prevista: {currentTerrainB.stability}%
              </span>
            </div>

            <svg viewBox="0 0 300 135" className="w-full h-36 rounded-xl bg-[#071128] border border-white/10">
              <path d={currentTerrainB.pathD} fill="#22c55e" opacity="0.78" stroke="#86efac" strokeWidth="2" />
              {simulatedB && (
                <g transform={`translate(${currentTerrainB.podX}, ${currentTerrainB.podY}) rotate(${currentTerrainB.podRotate})`}>
                  <rect x="-14" y="-14" width="28" height="16" rx="5" fill="#fbbf24" stroke="#ffffff" strokeWidth="2" />
                  <line x1="-10" y1="2" x2="-16" y2="10" stroke="#e2e8f0" strokeWidth="2.5" />
                  <line x1="10" y1="2" x2="16" y2="10" stroke="#e2e8f0" strokeWidth="2.5" />
                </g>
              )}
            </svg>

            <button
              type="button"
              onClick={handleSimulateLandingB}
              className="w-full rounded-xl border-2 border-emerald-300 bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-extrabold text-sm py-2.5 cursor-pointer"
            >
              Simular Aterragem do Módulo
            </button>

            {simulatedB && (
              <div
                className={`rounded-xl border p-3 text-xs font-bold ${
                  currentTerrainB.safe
                    ? 'border-emerald-400 bg-emerald-950/55 text-emerald-200'
                    : 'border-rose-400 bg-rose-950/55 text-rose-200'
                }`}
              >
                {currentTerrainB.feedback}
              </div>
            )}
          </div>
        </div>
      )}

      {/* EXPERIMENT C — INVESTIGADOR DA ÁGUA (GPM IMERG + SMAP) */}
      {activeTab === 'waterInvestigator' && (
        <div className="rounded-2xl border-2 border-sky-400/70 bg-slate-950/80 p-4 space-y-4">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-sky-300">
              Experiência C — Investigador da Água (GPM IMERG + SMAP)
            </h3>
            <p className="text-xs sm:text-sm font-semibold text-sky-100 mt-1">
              Ajusta a intensidade de chuva (GPM) e muda o tipo de solo para ver como o sensor SMAP mede a humidade retida na terra!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 tabular-nums">
            <div className="rounded-2xl border border-white/15 bg-slate-900/90 p-3.5 space-y-3">
              <div>
                <div className="flex items-center justify-between text-xs font-extrabold mb-1">
                  <span className="inline-flex items-center gap-1.5 text-sky-300">
                    <CloudRain size={15} /> Chuva GPM IMERG:
                  </span>
                  <span className="text-white">{rainMmC} mm/mês</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={300}
                  step={20}
                  value={rainMmC}
                  onChange={(e) => setRainMmC(Number(e.target.value))}
                  aria-label="Intensidade da chuva GPM IMERG"
                  className="w-full accent-sky-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="text-xs font-extrabold text-teal-300 mb-1.5">
                  Tipo de Solo Observado pelo SMAP:
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleTestWaterC('sandy')}
                    className={`rounded-xl border-2 p-2.5 text-xs font-extrabold cursor-pointer ${
                      soilTypeC === 'sandy'
                        ? 'border-amber-300 bg-amber-400/20 text-white'
                        : 'border-white/15 bg-slate-950 text-sky-200'
                    }`}
                  >
                    Areia Seca (Deserto)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTestWaterC('forest')}
                    className={`rounded-xl border-2 p-2.5 text-xs font-extrabold cursor-pointer ${
                      soilTypeC === 'forest'
                        ? 'border-teal-300 bg-teal-400/20 text-white'
                        : 'border-white/15 bg-slate-950 text-sky-200'
                    }`}
                  >
                    Solo Fértil (Floresta)
                  </button>
                </div>
              </div>

              <div className="rounded-xl bg-slate-950/90 border border-teal-300/40 p-3">
                <div className="flex items-center justify-between text-xs font-extrabold">
                  <span className="text-teal-300">Leitura SMAP (Humidade no Solo):</span>
                  <span className="text-white text-sm">{computedSoilMoistureC}%</span>
                </div>
                <div className="mt-2 h-3 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-sky-400 to-teal-400 transition-all duration-300"
                    style={{ width: `${computedSoilMoistureC}%` }}
                  />
                </div>
                <p className="mt-1.5 text-[11px] font-semibold text-sky-200">
                  {soilTypeC === 'sandy'
                    ? 'A areia deixa a água escorrer depressa, por isso retém pouca humidade.'
                    : 'O solo rico da floresta funciona como uma esponja e retém bastante água!'}
                </p>
              </div>
            </div>

            {/* Scientific Synthesis Check */}
            <div className="rounded-2xl border border-teal-300/40 bg-slate-900/90 p-3.5 flex flex-col justify-between gap-3">
              <div>
                <div className="text-xs font-extrabold uppercase text-amber-300 mb-2">
                  Descoberta Científica ({testedSoilsC.length}/2 solos testados)
                </div>
                <p className="text-xs font-bold text-white mb-2.5">
                  Com base nos teus testes com o GPM e o SMAP, qual é a conclusão correta?
                </p>
                <div className="space-y-2">
                  {[
                    { id: 'same_thing', label: 'Chuva e humidade do solo são exatamente a mesma medição.' },
                    { id: 'related_distinct', label: 'Estão ligadas, mas o GPM mede chuva que cai e o SMAP mede água retida no solo.' },
                    { id: 'no_relation', label: 'A chuva nunca influencia a humidade de nenhum solo.' },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleValidateWaterC(opt.id)}
                      className="w-full rounded-xl border-2 border-white/20 bg-slate-950 hover:border-teal-300 p-2.5 text-left text-xs font-extrabold text-sky-100 cursor-pointer"
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {insightC && (
                <div
                  className={`rounded-xl border p-2.5 text-xs font-bold ${
                    insightC.ok
                      ? 'border-emerald-400 bg-emerald-950/55 text-emerald-200'
                      : 'border-rose-400 bg-rose-950/55 text-rose-200'
                  }`}
                >
                  {insightC.text}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* EXPERIMENT D — OBSERVADOR DA ATMOSFERA (MERRA-2) */}
      {activeTab === 'atmosphereObserver' && (
        <div className="rounded-2xl border-2 border-purple-400/70 bg-slate-950/80 p-4 space-y-4">
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-purple-300">
              Experiência D — Observador da Atmosfera (MERRA-2)
            </h3>
            <p className="text-xs sm:text-sm font-semibold text-sky-100 mt-1">
              Ajusta a quantidade de aerossóis e poeiras atmosféricas e observa quanta luz solar consegue atravessar até aos painéis solares!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center tabular-nums">
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2">
                {[
                  { label: 'Amazónia (15%)', val: 15 },
                  { label: 'Europa (25%)', val: 25 },
                  { label: 'Deserto do Saara (85%)', val: 85 },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      onPlayClick();
                      setAerosolPctD(preset.val);
                    }}
                    className={`rounded-xl border px-3 py-1.5 text-xs font-extrabold cursor-pointer ${
                      aerosolPctD === preset.val
                        ? 'border-purple-300 bg-purple-500/30 text-white'
                        : 'border-white/20 bg-slate-900 text-purple-200 hover:border-purple-300'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-extrabold mb-1">
                  <span className="text-purple-300">Concentração de Aerossóis (MERRA-2):</span>
                  <span className="text-white">{aerosolPctD}%</span>
                </div>
                <input
                  type="range"
                  min={5}
                  max={95}
                  step={5}
                  value={aerosolPctD}
                  onChange={(e) => setAerosolPctD(Number(e.target.value))}
                  aria-label="Concentração de aerossóis MERRA-2"
                  className="w-full accent-purple-400 cursor-pointer"
                />
              </div>

              <button
                type="button"
                onClick={handleTestAtmosphereD}
                className="w-full rounded-xl border-2 border-purple-300 bg-purple-400 hover:bg-purple-300 text-slate-950 font-extrabold text-sm py-2.5 cursor-pointer"
              >
                Testar Impacto na Luz Solar
              </button>

              {feedbackD && (
                <div
                  className={`rounded-xl border p-2.5 text-xs font-bold ${
                    feedbackD.ok
                      ? 'border-emerald-400 bg-emerald-950/55 text-emerald-200'
                      : 'border-amber-400 bg-amber-950/55 text-amber-200'
                  }`}
                >
                  {feedbackD.text}
                </div>
              )}
            </div>

            {/* Live Sunlight Attenuation Visualizer */}
            <div className="rounded-2xl border border-purple-300/40 bg-slate-900/90 p-4">
              <div className="flex items-center justify-between text-xs font-extrabold mb-2">
                <span className="inline-flex items-center gap-1 text-amber-300">
                  <Sun size={15} /> Luz Solar Transmitida:
                </span>
                <span className="text-white">{sunlightPctD}%</span>
              </div>
              <svg viewBox="0 0 260 130" className="w-full h-32 rounded-xl bg-[#0a0f28] border border-white/10">
                <circle cx="40" cy="26" r="16" fill="#fde047" />
                {/* Solar Beams */}
                <line x1="56" y1="32" x2="180" y2="105" stroke="#fde047" strokeWidth="4" opacity={sunlightPctD / 100} />
                <line x1="48" y1="42" x2="140" y2="108" stroke="#fde047" strokeWidth="3" opacity={sunlightPctD / 100} />
                {/* Aerosol Dust Band */}
                <rect x="0" y="54" width="260" height="28" fill="#a855f7" opacity={aerosolPctD / 145} />
                {/* Solar Panel on ground */}
                <rect x="130" y="102" width="66" height="14" rx="3" fill="#2563eb" stroke="#93c5fd" strokeWidth="2" />
              </svg>
              <div className="mt-2 text-[11px] font-bold text-purple-200 text-center">
                {testedHighDustD
                  ? 'Observação concluída! Partículas no ar reduzem a energia solar disponível.'
                  : 'Observa como a faixa roxa de aerossóis atenua os raios solares.'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Progress & Navigation */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
        <button
          type="button"
          onClick={onBackToLab}
          className="rounded-full border-2 border-sky-300/60 bg-slate-900 px-4 py-2 text-xs font-extrabold text-sky-100 hover:border-amber-300 cursor-pointer"
        >
          Voltar ao Laboratório da Terra
        </button>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <span className="inline-flex items-center gap-1.5 text-xs font-extrabold text-amber-300">
            {allCompleted ? (
              <>
                <ShieldCheck size={16} className="text-emerald-400" /> Todas as 4 experiências concluídas!
              </>
            ) : (
              <>
                <Sparkles size={15} /> Experiências concluídas: {completedCount}/4
              </>
            )}
          </span>
          <ArcadeButton
            variant="yellow"
            onClick={onFinishExperiments}
            className={`!min-w-[260px] !min-h-[52px] !text-base ${
              !allCompleted ? 'opacity-50 pointer-events-none' : ''
            }`}
          >
            Concluir Treino Científico
          </ArcadeButton>
        </div>
      </div>
    </div>
  );
}
