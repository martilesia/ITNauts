import React from 'react';
import { ArrowLeftRight, Info, Sparkles } from 'lucide-react';
import ArcadeButton from '../../ArcadeButton.jsx';
import InteractiveEarthGlobe from './InteractiveEarthGlobe.jsx';
import DataLayerSelector from './DataLayerSelector.jsx';

export default function EarthDataLaboratory({
  earthdata,
  state,
  onToggleLayer,
  onSelectRegion,
  onSelectCompareRegion,
  onChangeRotation,
  onChangeZoom,
  onBackToControlRoom,
  onProceedToExperiments,
}) {
  const layers = earthdata.layers || [];
  const regions = earthdata.regions || [];

  const primaryRegion =
    regions.find((r) => r.id === state.selectedRegionId) || regions[0];
  const compareRegion =
    regions.find((r) => r.id === state.compareRegionId) || regions[1] || regions[0];

  const readyForExperiments =
    state.exploredLayers.length >= 3 && state.exploredRegions.length >= 2;

  return (
    <div className="space-y-4">
      {/* Scientific Scope Notice */}
      <div className="rounded-2xl border-2 border-cyan-300/60 bg-cyan-950/45 px-3.5 py-2.5 flex items-start gap-2.5 text-xs font-bold text-cyan-100">
        <Info size={18} className="text-cyan-300 shrink-0 mt-0.5" />
        <span>
          <strong className="text-amber-300">Nota Científica:</strong>{' '}
          {earthdata.sourceNote}
        </span>
      </div>

      {/* Main 2-Column Laboratory Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left: Interactive Globe */}
        <div className="lg:col-span-6 space-y-3">
          <InteractiveEarthGlobe
            regions={regions}
            selectedRegionId={state.selectedRegionId}
            compareRegionId={state.compareRegionId}
            activeLayers={state.activeLayers}
            rotationLon={state.globeRotationLon}
            zoom={state.globeZoom}
            onChangeRotation={onChangeRotation}
            onChangeZoom={onChangeZoom}
            onSelectRegion={onSelectRegion}
          />
        </div>

        {/* Right: 5 Earthdata Layer Toggles + Side-by-Side Comparison */}
        <div className="lg:col-span-6 space-y-3">
          <DataLayerSelector
            layers={layers}
            activeLayers={state.activeLayers}
            exploredLayers={state.exploredLayers}
            onToggleLayer={onToggleLayer}
          />
        </div>
      </div>

      {/* Region Inspector + Side-by-Side Comparison Panel */}
      {primaryRegion && compareRegion && (
        <div className="rounded-2xl border-2 border-amber-300/70 bg-slate-950/80 p-3.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <ArrowLeftRight size={18} className="text-amber-300" />
              <h3 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-amber-300">
                Comparação Lado a Lado de Regiões da Terra
              </h3>
            </div>
            <div className="flex items-center gap-2 text-xs font-bold">
              <span className="text-sky-200">Comparar com:</span>
              <select
                value={compareRegion.id}
                onChange={(e) => onSelectCompareRegion(e.target.value)}
                aria-label="Selecionar segunda região para comparação"
                className="rounded-xl border border-teal-300/60 bg-slate-900 px-2.5 py-1 text-xs font-extrabold text-teal-200 cursor-pointer"
              >
                {regions.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 tabular-nums">
            {[
              { label: 'Região Selecionada', region: primaryRegion, badgeClass: 'border-amber-300 bg-amber-400/15 text-amber-300' },
              { label: 'Região Comparada', region: compareRegion, badgeClass: 'border-teal-300 bg-teal-400/15 text-teal-300' },
            ].map((col) => (
              <div
                key={col.label}
                className="rounded-2xl border border-white/15 bg-slate-900/85 p-3 space-y-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-extrabold text-white">
                    {col.region.name}
                  </span>
                  <span className={`rounded-lg border px-2 py-0.5 text-[10px] font-extrabold ${col.badgeClass}`}>
                    {col.label}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-1.5 text-[11px] font-bold">
                  <div className="rounded-lg bg-slate-950/75 px-2 py-1.5 text-orange-200">
                    MODIS Temp: <span className="text-white">{col.region.modisTempC}°C</span>
                  </div>
                  <div className="rounded-lg bg-slate-950/75 px-2 py-1.5 text-green-200">
                    SRTM Relevo: <span className="text-white">{col.region.srtmElevationM} m</span>
                  </div>
                  <div className="rounded-lg bg-slate-950/75 px-2 py-1.5 text-sky-200">
                    GPM Chuva: <span className="text-white">{col.region.gpmRainMm} mm</span>
                  </div>
                  <div className="rounded-lg bg-slate-950/75 px-2 py-1.5 text-teal-200">
                    SMAP Solo: <span className="text-white">{col.region.smapMoisture}</span>
                  </div>
                  <div className="col-span-2 rounded-lg bg-slate-950/75 px-2 py-1.5 text-purple-200">
                    MERRA-2 Aerossóis: <span className="text-white">{col.region.merra2Aerosol}</span> · ({col.region.srtmType})
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Footer Navigation */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
        <button
          type="button"
          onClick={onBackToControlRoom}
          className="rounded-full border-2 border-sky-300/60 bg-slate-900 px-4 py-2 text-xs font-extrabold text-sky-100 hover:border-amber-300 cursor-pointer"
        >
          Voltar à Sala de Controlo
        </button>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          {!readyForExperiments && (
            <span className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-200">
              <Sparkles size={14} /> Explora pelo menos 3 camadas ({state.exploredLayers.length}/3) e 2 regiões ({state.exploredRegions.length}/2) para avançar!
            </span>
          )}
          <ArcadeButton
            variant="yellow"
            onClick={onProceedToExperiments}
            className={`!min-w-[260px] !min-h-[52px] !text-base ${
              !readyForExperiments ? 'opacity-50 pointer-events-none' : ''
            }`}
          >
            Centro de Experiências
          </ArcadeButton>
        </div>
      </div>
    </div>
  );
}
