import React from 'react';
import { Award, CheckCircle2, Rocket, Star } from 'lucide-react';
import ArcadeButton from '../../ArcadeButton.jsx';
import AstronautCharacter from '../../AstronautCharacter.jsx';
import PlanetArtwork from '../../PlanetArtwork.jsx';
import { AstroAvatar } from '../red-storm/MissionCharacters.jsx';
import {
  MISSION_BADGES,
  computeSpaceCallingStars,
  getDestinationLabel,
} from '../../../logic/spaceCallingEngine.js';

const ACQUIRED_KNOWLEDGE = [
  { key: 'MODIS', text: 'Temperaturas extremas na superfície exigem bom isolamento térmico nas bases.' },
  { key: 'MERRA-2', text: 'Poeiras e aerossóis na atmosfera reduzem a luz que chega aos painéis solares.' },
  { key: 'SRTM', text: 'Mapear o relevo ajuda a escolher planícies estáveis para aterrar e conduzir o rover.' },
  { key: 'GPM IMERG', text: 'Mede onde e quanta chuva cai sobre as regiões do planeta Terra.' },
  { key: 'SMAP', text: 'Mede quanta água fica retida no solo — diferente da quantidade de chuva que cai.' },
];

export default function MissionCompletion({
  character,
  persOptions,
  selectedDestination,
  state,
  onReturnToBase,
}) {
  const destinationId = selectedDestination === 'mars' ? 'mars' : 'moon';
  const destinationName = getDestinationLabel(destinationId);
  const earnedStars = computeSpaceCallingStars(state);

  return (
    <div className="space-y-4">
      {/* Celebration Hero: Astronaut + ASTRO + Chosen Destination */}
      <div className="rounded-3xl border-3 border-amber-300 bg-gradient-to-b from-[#1a2c6b] via-[#132052] to-[#0b1335] p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="rounded-2xl border-2 border-sky-300 bg-slate-900/80 p-1.5 shrink-0">
            <AstronautCharacter
              character={character}
              options={persOptions}
              size={105}
              waving
              className="w-[88px] h-auto"
            />
          </div>
          <div className="animate-float-slow shrink-0">
            <AstroAvatar size={74} />
          </div>
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-emerald-300">
              Treino Científico Concluído!
            </div>
            <h3
              className="text-xl sm:text-2xl font-extrabold text-white leading-tight"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Parabéns, Comandante!
            </h3>
            <p className="mt-1 text-xs sm:text-sm font-bold text-sky-100 leading-snug max-w-md">
              “Dominaste os dados NASA Earthdata da Terra! Agora estás preparado para liderar a nossa expedição rumo a <span className="text-amber-300">{destinationName}</span>!” — ASTRO
            </p>
          </div>
        </div>

        {/* Already Chosen Destination Badge (No Re-Selection) */}
        <div className="rounded-2xl border-2 border-amber-300/75 bg-slate-950/80 px-4 py-3 flex items-center gap-3 shrink-0">
          <PlanetArtwork planetId={destinationId} size={58} />
          <div>
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-sky-300">
              Destino Confirmado
            </div>
            <div
              className="text-lg font-extrabold text-amber-300"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {destinationName}
            </div>
            <div className="mt-1 flex items-center gap-1" aria-label={`${earnedStars} de 3 estrelas`}>
              {[1, 2, 3].map((s) => (
                <Star
                  key={s}
                  size={18}
                  className={
                    s <= earnedStars
                      ? 'text-amber-300 fill-amber-300'
                      : 'text-slate-600 fill-slate-700'
                  }
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Unlocked Badges */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Award size={18} className="text-amber-300" />
          <h4 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-amber-300">
            Insígnias Desbloqueadas
          </h4>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {MISSION_BADGES.map((badge) => (
            <div
              key={badge.id}
              className="rounded-2xl border-2 border-emerald-400/75 bg-emerald-950/40 p-3 flex items-start gap-2.5 shadow-md"
            >
              <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-300 flex items-center justify-center shrink-0">
                <Award size={20} className="text-amber-300" />
              </div>
              <div>
                <div className="text-xs font-extrabold text-white">
                  {badge.title}
                </div>
                <p className="mt-0.5 text-[11px] font-semibold text-emerald-100/90 leading-snug">
                  {badge.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Acquired Knowledge Summary */}
      <div className="rounded-2xl border-2 border-sky-300/50 bg-slate-950/80 p-3.5">
        <div className="text-xs font-extrabold uppercase tracking-wider text-sky-300 mb-2">
          Conhecimentos Adquiridos na Missão 1
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {ACQUIRED_KNOWLEDGE.map((item) => (
            <div
              key={item.key}
              className="rounded-xl border border-white/10 bg-slate-900/80 px-3 py-2 flex items-start gap-2 text-xs"
            >
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-300">{item.key}:</strong>{' '}
                <span className="text-sky-100 font-semibold">{item.text}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Finish Mission & Return to Base Console */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
        <div className="inline-flex items-center gap-2 text-xs font-bold text-cyan-200">
          <Rocket size={16} className="text-amber-300" />
          As próximas missões da expedição estão desbloqueadas no painel!
        </div>
        <ArcadeButton
          variant="yellow"
          onClick={() => onReturnToBase(earnedStars)}
          className="!min-w-[270px] !min-h-[54px] !text-base"
        >
          Concluir Missão e Voltar
        </ArcadeButton>
      </div>
    </div>
  );
}
