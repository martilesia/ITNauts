import React from 'react';
import {
  CheckCircle2,
  Compass,
  Radio,
  Satellite,
  Sparkles,
  Telescope,
} from 'lucide-react';
import ArcadeButton from '../../ArcadeButton.jsx';
import AstronautCharacter from '../../AstronautCharacter.jsx';
import { AstroAvatar } from '../red-storm/MissionCharacters.jsx';
import { getDestinationLabel } from '../../../logic/spaceCallingEngine.js';

const CONTROL_STATIONS = [
  {
    id: 'panoramic_window',
    title: 'Janela Panorâmica',
    shortRole: 'Observação Visual',
    icon: Telescope,
    accent: 'border-sky-300 bg-sky-500/20 text-sky-200',
    description:
      'Permite observar a Terra azul brilhante lá fora, junto com a Lua e Marte no horizonte espacial.',
  },
  {
    id: 'satellite_console',
    title: 'Consola de Satélites',
    shortRole: 'Controlo Orbital',
    icon: Satellite,
    accent: 'border-amber-300 bg-amber-500/20 text-amber-200',
    description:
      'Liga os satélites da NASA que fotografam a temperatura, a chuva, o relevo e a poeira do planeta Terra.',
  },
  {
    id: 'data_radar',
    title: 'Radar de Dados',
    shortRole: 'Análise Rápida',
    icon: Compass,
    accent: 'border-emerald-300 bg-emerald-500/20 text-emerald-200',
    description:
      'Compara regiões quentes, frias, altas ou chuvosas antes de enviarmos astronautas para novas bases.',
  },
  {
    id: 'comms_terminal',
    title: 'Terminal de Comunicações',
    shortRole: 'Ligação à Expedição',
    icon: Radio,
    accent: 'border-purple-300 bg-purple-500/20 text-purple-200',
    description:
      'Mantém a equipa em contacto direto entre o centro de treino orbital e a futura base espacial.',
  },
];

export default function MissionControlRoom({
  character,
  persOptions,
  selectedDestination,
  inspectedStations,
  activeStationId,
  onInspectStation,
  onStartLaboratory,
}) {
  const destinationName = getDestinationLabel(selectedDestination);
  const destinationFact =
    selectedDestination === 'mars'
      ? 'O teu plano de voo aponta para Marte, o Planeta Vermelho!'
      : 'O teu plano de voo aponta para a Lua, a nossa vizinha brilhante!';

  const activeStation =
    CONTROL_STATIONS.find((s) => s.id === activeStationId) || null;

  return (
    <div className="space-y-4">
      {/* Panoramic Control Room Scene */}
      <div className="relative rounded-3xl border-3 border-sky-400/70 bg-gradient-to-b from-[#070f2b] via-[#0c1d4a] to-[#132963] p-4 sm:p-5 overflow-hidden shadow-inner">
        {/* Panoramic Space Windows */}
        <div className="relative grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
          <div className="md:col-span-2 relative rounded-2xl border-2 border-sky-300/60 bg-[#030716] p-3 overflow-hidden min-h-[168px] flex items-center justify-around">
            {/* Stars */}
            <div className="pointer-events-none absolute inset-0" aria-hidden="true">
              <div className="absolute top-4 left-8 w-1.5 h-1.5 rounded-full bg-white/90 animate-twinkle" />
              <div className="absolute top-12 left-1/3 w-1 h-1 rounded-full bg-sky-200/80" />
              <div className="absolute top-6 right-1/4 w-1.5 h-1.5 rounded-full bg-amber-100/85" />
              <div className="absolute bottom-8 left-1/4 w-1 h-1 rounded-full bg-white/75" />
              <div className="absolute bottom-6 right-12 w-1.5 h-1.5 rounded-full bg-sky-200/80 animate-twinkle" />
            </div>

            {/* Earth outside window */}
            <div className="relative z-10 flex flex-col items-center">
              <svg width="96" height="96" viewBox="0 0 100 100" aria-label="Planeta Terra na janela">
                <defs>
                  <radialGradient id="ctrlEarthGrad" cx="35%" cy="30%" r="70%">
                    <stop offset="0%" stopColor="#60a5fa" />
                    <stop offset="55%" stopColor="#2563eb" />
                    <stop offset="100%" stopColor="#1e3a8a" />
                  </radialGradient>
                </defs>
                <circle cx="50" cy="50" r="42" fill="url(#ctrlEarthGrad)" stroke="#93c5fd" strokeWidth="2" />
                <path d="M28 38C36 28 48 30 50 42C52 52 40 58 34 68C25 60 22 46 28 38Z" fill="#22c55e" />
                <path d="M58 26C68 28 76 38 74 50C70 58 60 62 56 54C52 44 52 32 58 26Z" fill="#16a34a" />
                <ellipse cx="46" cy="30" rx="14" ry="4" fill="#ffffff" opacity="0.65" />
                <ellipse cx="64" cy="64" rx="11" ry="3.5" fill="#ffffff" opacity="0.55" />
              </svg>
              <span className="mt-1 text-[11px] font-extrabold text-sky-200 uppercase tracking-wider">
                Terra
              </span>
            </div>

            {/* Moon outside window */}
            <div className="relative z-10 flex flex-col items-center">
              <svg width="64" height="64" viewBox="0 0 80 80" aria-label="Lua na janela">
                <circle cx="40" cy="40" r="28" fill="#cbd5e1" stroke={selectedDestination !== 'mars' ? '#fde047' : '#94a3b8'} strokeWidth="2.5" />
                <circle cx="30" cy="32" r="6" fill="#94a3b8" />
                <circle cx="48" cy="46" r="7" fill="#94a3b8" />
                <circle cx="46" cy="26" r="4" fill="#94a3b8" />
              </svg>
              <span
                className={`mt-1 text-[11px] font-extrabold uppercase tracking-wider ${
                  selectedDestination !== 'mars' ? 'text-amber-300' : 'text-slate-300'
                }`}
              >
                Lua {selectedDestination !== 'mars' ? '★ Destino' : ''}
              </span>
            </div>

            {/* Mars outside window */}
            <div className="relative z-10 flex flex-col items-center">
              <svg width="70" height="70" viewBox="0 0 80 80" aria-label="Marte na janela">
                <circle cx="40" cy="40" r="30" fill="#ea580c" stroke={selectedDestination === 'mars' ? '#fde047' : '#fb923c'} strokeWidth="2.5" />
                <ellipse cx="32" cy="36" rx="9" ry="5" fill="#9a3412" opacity="0.7" />
                <ellipse cx="50" cy="48" rx="10" ry="6" fill="#c2410c" opacity="0.8" />
                <ellipse cx="40" cy="14" rx="10" ry="3" fill="#fff7ed" opacity="0.7" />
              </svg>
              <span
                className={`mt-1 text-[11px] font-extrabold uppercase tracking-wider ${
                  selectedDestination === 'mars' ? 'text-amber-300' : 'text-orange-200'
                }`}
              >
                Marte {selectedDestination === 'mars' ? '★ Destino' : ''}
              </span>
            </div>
          </div>

          {/* Personalized Astronaut + Selected Destination Card */}
          <div className="rounded-2xl border-2 border-amber-300/70 bg-slate-950/75 p-3 flex items-center gap-3">
            <div className="shrink-0 rounded-2xl border border-sky-300/50 bg-slate-900/80 p-1">
              <AstronautCharacter
                character={character}
                options={persOptions}
                size={84}
                waving
                className="w-[74px] h-auto"
              />
            </div>
            <div className="min-w-0">
              <span className="inline-flex items-center gap-1 rounded-full bg-amber-400/20 border border-amber-300/60 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-amber-300">
                <Sparkles size={11} /> Traje Equipado
              </span>
              <div className="mt-1.5 text-xs font-extrabold text-sky-200">
                Destino da Expedição:
              </div>
              <div
                className="text-lg font-extrabold text-white leading-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {destinationName}
              </div>
              <p className="mt-1 text-[11px] font-semibold text-sky-100/85 leading-snug">
                {destinationFact}
              </p>
            </div>
          </div>
        </div>

        {/* Expressive ASTRO Dialogue */}
        <div className="rounded-2xl border-2 border-cyan-300/80 bg-slate-950/80 p-3.5 flex flex-col sm:flex-row items-center gap-3.5 shadow-lg">
          <div className="animate-float-slow shrink-0">
            <AstroAvatar size={70} />
          </div>
          <div className="text-center sm:text-left">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
              <span className="text-xs font-extrabold uppercase tracking-wider text-amber-300">
                ASTRO · Robô Assistente
              </span>
              <span className="text-[11px] font-bold text-cyan-200">
                · Missão 1: O Chamamento Espacial
              </span>
            </div>
            <p className="text-xs sm:text-sm font-bold text-white leading-snug">
              Olá, Comandante! Antes de partirmos rumo a <span className="text-amber-300">{destinationName}</span>, vamos estudar o planeta Terra com os satélites da NASA! Clica nas estações da sala abaixo para descobrir como cada painel funciona.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Control Room Stations */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-2">
          <h3 className="text-sm sm:text-base font-extrabold text-amber-300">
            Explora a Sala de Controlo ({inspectedStations.length}/{CONTROL_STATIONS.length} estações verificadas)
          </h3>
          <span className="text-xs font-bold text-sky-200">
            Clica em cada monitor interativo
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {CONTROL_STATIONS.map((station) => {
            const Icon = station.icon;
            const isInspected = inspectedStations.includes(station.id);
            const isActive = activeStationId === station.id;

            return (
              <button
                key={station.id}
                type="button"
                onClick={() => onInspectStation(station.id)}
                className={`rounded-2xl border-2 p-3 text-left transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                  isActive
                    ? 'border-amber-300 bg-amber-400/20 shadow-[0_0_20px_rgba(251,191,36,0.28)] -translate-y-0.5'
                    : isInspected
                      ? 'border-emerald-400/80 bg-emerald-950/40 hover:border-amber-300'
                      : 'border-sky-300/40 bg-slate-950/75 hover:border-amber-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${station.accent}`}>
                    <Icon size={18} />
                  </div>
                  {isInspected && (
                    <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />
                  )}
                </div>
                <div>
                  <div className="text-xs font-extrabold text-white">
                    {station.title}
                  </div>
                  <div className="text-[11px] font-bold text-sky-300">
                    {station.shortRole}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Station Readout */}
        <div className="mt-3 rounded-2xl border-2 border-sky-300/60 bg-slate-950/80 px-4 py-3 text-xs sm:text-sm font-bold text-sky-100">
          {activeStation ? (
            <span>
              <strong className="text-amber-300">{activeStation.title}:</strong>{' '}
              {activeStation.description}
            </span>
          ) : (
            <span>
              Objetivo da missão: Aprender a usar dados reais de observação da Terra (temperatura, atmosfera, relevo, chuva e humidade do solo) antes da expedição para {destinationName}.
            </span>
          )}
        </div>
      </div>

      {/* Start Mission CTA */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
        <div className="text-xs font-bold text-sky-200">
          Pronto para observar a Terra em órbita?
        </div>
        <ArcadeButton
          variant="yellow"
          onClick={onStartLaboratory}
          className="!min-w-[260px] !min-h-[54px] !text-base"
        >
          Entrar no Laboratório
        </ArcadeButton>
      </div>
    </div>
  );
}
