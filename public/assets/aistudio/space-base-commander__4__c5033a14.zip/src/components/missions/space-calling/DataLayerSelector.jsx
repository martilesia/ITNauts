import React from 'react';
import {
  CheckCircle2,
  CloudRain,
  Droplets,
  Mountain,
  Thermometer,
  Wind,
} from 'lucide-react';

const LAYER_ICONS = {
  modis: Thermometer,
  merra2: Wind,
  srtm: Mountain,
  gpm: CloudRain,
  smap: Droplets,
};

export default function DataLayerSelector({
  layers,
  activeLayers,
  exploredLayers,
  onToggleLayer,
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-amber-300">
          Camadas NASA Earthdata ({exploredLayers.length}/{layers.length} exploradas)
        </h3>
        <span className="text-[11px] font-bold text-sky-200">
          Ativa ou combina camadas no globo
        </span>
      </div>

      <div className="grid grid-cols-1 gap-2">
        {layers.map((layer) => {
          const Icon = LAYER_ICONS[layer.id] || Thermometer;
          const isActive = activeLayers.includes(layer.id);
          const isExplored = exploredLayers.includes(layer.id);

          return (
            <button
              key={layer.id}
              type="button"
              onClick={() => onToggleLayer(layer.id)}
              className={`rounded-2xl border-2 p-2.5 text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                isActive
                  ? 'border-amber-300 bg-slate-900/95 shadow-md'
                  : 'border-white/15 bg-slate-950/60 hover:border-sky-300/60'
              }`}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border border-white/30"
                style={{ backgroundColor: `${layer.color}33`, color: layer.color }}
              >
                <Icon size={18} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xs font-extrabold text-white">
                      {layer.name}
                    </span>
                    <span
                      className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-md truncate"
                      style={{ backgroundColor: `${layer.color}28`, color: layer.color }}
                    >
                      {layer.fullTitle}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {isExplored && (
                      <CheckCircle2 size={14} className="text-emerald-400" />
                    )}
                    <span
                      className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded-md ${
                        isActive
                          ? 'bg-emerald-500/25 text-emerald-300'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {isActive ? 'ATIVA' : 'LIGAR'}
                    </span>
                  </div>
                </div>
                <p className="mt-1 text-[11px] font-semibold text-sky-100 leading-snug">
                  {layer.shortDesc}
                </p>
                {isActive && (
                  <p className="mt-0.5 text-[10px] font-bold text-amber-200/90">
                    Dica: {layer.practicalTip}
                  </p>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
