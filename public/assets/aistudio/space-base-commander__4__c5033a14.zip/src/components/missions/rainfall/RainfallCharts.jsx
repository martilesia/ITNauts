import React from 'react';
import { BarChart3 } from 'lucide-react';
import { getIntensityLevel } from '../../../logic/rainfallEngine.js';

export default function RainfallCharts({
  regions,
  months,
  selectedMonthId,
  selectedRegion,
  compareRegion,
  onSelectCompareRegion,
}) {
  const maxRegionMm = Math.max(
    100,
    ...regions.map((r) => r.monthlyMm?.[selectedMonthId] || 0)
  );
  const maxSeasonalMm = Math.max(
    100,
    ...months.map((m) => selectedRegion?.monthlyMm?.[m.id] || 0)
  );

  const selectedMm = selectedRegion?.monthlyMm?.[selectedMonthId] || 0;
  const compareMm = compareRegion?.monthlyMm?.[selectedMonthId] || 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 tabular-nums">
      {/* Chart 1: Regional Comparison in Current Month */}
      <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/65 p-3.5">
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <h4 className="text-xs sm:text-sm font-extrabold text-amber-300 flex items-center gap-1.5">
            <BarChart3 size={16} /> Comparação Regional (mm/mês)
          </h4>

          <select
            aria-label="Selecionar região para comparar"
            value={compareRegion?.id || ''}
            onChange={(e) => onSelectCompareRegion(e.target.value)}
            className="rounded-lg border border-pink-400/70 bg-slate-900 px-2 py-1 text-xs font-bold text-pink-200 cursor-pointer"
          >
            {regions.map((r) => (
              <option key={r.id} value={r.id}>
                vs. {r.name.split(' ')[0]}
              </option>
            ))}
          </select>
        </div>

        <div className="space-y-2.5">
          {[
            { region: selectedRegion, mm: selectedMm, tag: 'Principal', barClass: 'from-yellow-300 to-amber-500' },
            { region: compareRegion, mm: compareMm, tag: 'Comparada', barClass: 'from-pink-400 to-rose-500' },
          ].map(({ region, mm, tag, barClass }) => {
            if (!region) return null;
            const pct = Math.max(6, Math.round((mm / maxRegionMm) * 100));
            return (
              <div key={`${tag}-${region.id}`}>
                <div className="flex items-center justify-between text-xs font-bold mb-1">
                  <span className="text-white truncate">
                    {region.name} <span className="text-sky-300">({tag})</span>
                  </span>
                  <span className="text-amber-300 font-extrabold shrink-0">{mm} mm</span>
                </div>
                <div className="w-full h-3.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${barClass} transition-all duration-300`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Chart 2: Seasonal Monthly Variation for Selected Region */}
      <div className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/65 p-3.5">
        <h4 className="text-xs sm:text-sm font-extrabold text-amber-300 mb-2.5">
          Variação Mensal — {selectedRegion?.name}
        </h4>

        <div className="grid grid-cols-4 gap-2 items-end h-[96px] pt-2">
          {months.map((m) => {
            const val = selectedRegion?.monthlyMm?.[m.id] || 0;
            const heightPct = Math.max(10, Math.round((val / maxSeasonalMm) * 100));
            const isCurrent = m.id === selectedMonthId;
            const lvl = getIntensityLevel(val);

            return (
              <div key={m.id} className="flex flex-col items-center justify-end h-full">
                <span className="text-[11px] font-extrabold text-white mb-1">{val}</span>
                <div className="w-full max-w-[38px] flex-1 flex items-end justify-center">
                  <div
                    style={{
                      height: `${heightPct}%`,
                      backgroundColor: lvl.color,
                    }}
                    className={`w-full rounded-t-lg transition-all duration-300 ${
                      isCurrent ? 'ring-2 ring-yellow-300' : 'opacity-80'
                    }`}
                  />
                </div>
                <span
                  className={`mt-1 text-[11px] font-extrabold ${
                    isCurrent ? 'text-amber-300' : 'text-sky-200'
                  }`}
                >
                  {m.short}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
