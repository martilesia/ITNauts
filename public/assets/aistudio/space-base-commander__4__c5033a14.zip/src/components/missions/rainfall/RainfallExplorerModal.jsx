import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Calendar,
  CheckCircle2,
  CloudRain,
  Droplets,
  Info,
  RotateCcw,
  Star,
  Trophy,
  X,
} from 'lucide-react';
import {
  INITIAL_RAINFALL_STATE,
  RAINFALL_CHALLENGES,
  RAINFALL_STEPS,
  computeRainfallReport,
  getIntensityLevel,
} from '../../../logic/rainfallEngine.js';
import {
  playClickSound,
  playErrorSound,
  playStartFanfare,
  playSuccessSound,
} from '../../../utils/soundFx.js';
import ArcadeButton from '../../ArcadeButton.jsx';
import AstronautCharacter from '../../AstronautCharacter.jsx';
import GpmEarthMap from './GpmEarthMap.jsx';
import RainfallCharts from './RainfallCharts.jsx';

const FALLBACK_GPM = {
  dataset: 'NASA GPM — GPM_3IMERGM',
  sourceLabel: 'DADOS ILUSTRATIVOS — NÃO É UMA MEDIÇÃO REAL DA NASA',
  scientificNote:
    'Os dados GPM representam apenas a precipitação na Terra (nunca na Lua ou em Marte).',
  concepts: {
    precipitation: 'Precipitação: água que cai da atmosfera sobre uma região.',
    availability: 'Disponibilidade de Água: água realmente acessível para uso.',
    resources: 'Recursos Hídricos: fontes como rios, lagos e águas subterrâneas.',
  },
  months: [
    { id: 'jan', label: 'Janeiro', short: 'Jan' },
    { id: 'apr', label: 'Abril', short: 'Abr' },
    { id: 'jul', label: 'Julho', short: 'Jul' },
    { id: 'oct', label: 'Outubro', short: 'Out' },
  ],
  regions: [
    {
      id: 'amazon',
      name: 'Bacia Amazónica',
      continent: 'América do Sul',
      x: 31,
      y: 60,
      monthlyMm: { jan: 285, apr: 310, jul: 120, oct: 195 },
      waterAvailability: 'Alta, exigindo filtração.',
      waterResources: 'Rios abundantes.',
      suitableForStudy: true,
      summary: 'Chuva tropical frequente ao longo do ano.',
    },
    {
      id: 'monsoon_asia',
      name: 'Sudeste Asiático (Monção)',
      continent: 'Ásia',
      x: 76,
      y: 47,
      monthlyMm: { jan: 45, apr: 115, jul: 360, oct: 210 },
      waterAvailability: 'Moderada a Alta (sazonal).',
      waterResources: 'Rios sazonais e reservatórios.',
      suitableForStudy: true,
      summary: 'Pico de chuvas intensas em julho.',
    },
    {
      id: 'central_europe',
      name: 'Europa Central',
      continent: 'Europa',
      x: 52,
      y: 27,
      monthlyMm: { jan: 58, apr: 64, jul: 82, oct: 62 },
      waterAvailability: 'Elevada e estável.',
      waterResources: 'Rios, lagos e aquíferos.',
      suitableForStudy: true,
      summary: 'Chuva moderada e regular todo o ano.',
    },
    {
      id: 'atacama',
      name: 'Deserto do Atacama',
      continent: 'América do Sul',
      x: 26,
      y: 71,
      monthlyMm: { jan: 6, apr: 3, jul: 2, oct: 4 },
      waterAvailability: 'Muito baixa.',
      waterResources: 'Reservas mínimas.',
      suitableForStudy: false,
      summary: 'Região extremamente seca.',
    },
  ],
};

export default function RainfallExplorerModal({
  isOpen,
  mission,
  gameState,
  persOptions,
  onCompleteMission,
  onClose,
}) {
  const [dataset, setDataset] = useState(FALLBACK_GPM);
  const [state, setState] = useState(INITIAL_RAINFALL_STATE);

  const audioEnabled = Boolean(gameState?.audioEnabled);

  useEffect(() => {
    if (!isOpen) return;
    setState(INITIAL_RAINFALL_STATE);
    const url = mission?.gpmDataUrl || '/data/gpm-3imergm-sample.json';
    fetch(url)
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error('load failed'))))
      .then((json) => {
        if (json && Array.isArray(json.regions) && Array.isArray(json.months)) {
          setDataset(json);
        }
      })
      .catch(() => {
        // Offline fallback remains active
      });
  }, [isOpen, mission?.gpmDataUrl]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen || !mission) return null;

  const regions = dataset.regions || [];
  const months = dataset.months || [];
  const selectedRegion =
    regions.find((r) => r.id === state.selectedRegionId) || regions[0];
  const compareRegion =
    regions.find((r) => r.id === state.compareRegionId) || regions[1] || regions[0];
  const selectedMm = selectedRegion?.monthlyMm?.[state.selectedMonthId] || 0;
  const selectedIntensity = getIntensityLevel(selectedMm);

  const handleSelectMonth = (monthId) => {
    playClickSound(audioEnabled);
    setState((prev) => ({
      ...prev,
      selectedMonthId: monthId,
      exploredMonths: prev.exploredMonths.includes(monthId)
        ? prev.exploredMonths
        : [...prev.exploredMonths, monthId],
    }));
  };

  const handleSelectRegion = (regionId) => {
    playClickSound(audioEnabled);
    setState((prev) => {
      const isNew = !prev.exploredRegions.includes(regionId);
      return {
        ...prev,
        selectedRegionId: regionId,
        exploredRegions: isNew
          ? [...prev.exploredRegions, regionId]
          : prev.exploredRegions,
        score: isNew ? prev.score + 15 : prev.score,
      };
    });
  };

  const handleRecommendSelected = () => {
    playSuccessSound(audioEnabled);
    setState((prev) => ({
      ...prev,
      recommendedRegionId: selectedRegion.id,
      score: prev.recommendedRegionId ? prev.score : prev.score + 40,
    }));
  };

  const handleAnswerChallenge = (challenge, option) => {
    if (state.challengeAnswers[challenge.id]?.correct) return;

    if (option.correct) {
      playSuccessSound(audioEnabled);
    } else {
      playErrorSound(audioEnabled);
    }

    setState((prev) => ({
      ...prev,
      score: option.correct ? prev.score + 50 : prev.score,
      mistakes: option.correct ? prev.mistakes : prev.mistakes + 1,
      challengeAnswers: {
        ...prev.challengeAnswers,
        [challenge.id]: {
          selectedId: option.id,
          correct: Boolean(option.correct),
        },
      },
    }));
  };

  const allChallengesSolved = RAINFALL_CHALLENGES.every(
    (c) => state.challengeAnswers[c.id]?.correct
  );
  const canEnterChallenges =
    state.exploredRegions.length >= 2 && Boolean(state.recommendedRegionId);

  const report = computeRainfallReport(state, regions);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-5 bg-[#070b1e]/88 backdrop-blur-sm overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="rainfall-mission-title"
    >
      <div className="relative w-full max-w-5xl my-auto rounded-[28px] border-4 border-sky-300 bg-gradient-to-b from-[#172554] via-[#1e3a8a] to-[#0f172a] p-4 sm:p-6 shadow-[0_24px_70px_rgba(0,0,0,0.84)] text-white">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Voltar ao AstroBase"
          className="absolute top-4 right-4 w-10 h-10 rounded-full border-2 border-white/80 bg-rose-600 hover:bg-rose-500 flex items-center justify-center text-white shadow-md cursor-pointer"
        >
          <X size={20} strokeWidth={2.75} />
        </button>

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pr-12 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl border-2 border-sky-300 bg-sky-900/60 flex items-center justify-center shrink-0">
              <CloudRain size={28} className="text-cyan-300" />
            </div>
            <div>
              <div className="text-xs font-extrabold text-cyan-200">
                {dataset.dataset} · {dataset.sourceLabel}
              </div>
              <h2
                id="rainfall-mission-title"
                className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white leading-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {mission.title}
              </h2>
            </div>
          </div>

          <div className="inline-flex items-center gap-2 rounded-xl border border-amber-300/60 bg-slate-950/70 px-3 py-1.5 text-xs sm:text-sm font-extrabold text-amber-300 tabular-nums shrink-0">
            <Trophy size={16} /> {state.score} pts
          </div>
        </div>

        {/* Step Progress Bar */}
        <div className="grid grid-cols-4 gap-1.5 mb-5">
          {RAINFALL_STEPS.map((st) => {
            const isActive = state.step === st.id;
            const isDone = state.step > st.id;
            return (
              <div
                key={st.id}
                className={`rounded-xl border px-2 py-1.5 text-center text-xs font-extrabold ${
                  isActive
                    ? 'border-amber-300 bg-amber-400 text-slate-950'
                    : isDone
                      ? 'border-emerald-400/70 bg-emerald-500/25 text-emerald-200'
                      : 'border-white/20 bg-slate-950/50 text-slate-300'
                }`}
              >
                {st.label}
              </div>
            );
          })}
        </div>

        {/* STEP 1 — MISSION BRIEFING */}
        {state.step === 1 && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center py-2">
            <div className="md:col-span-5 flex flex-col items-center rounded-3xl border-2 border-sky-300/40 bg-slate-950/55 p-5">
              <div className="flex items-center gap-3">
                <AstronautCharacter
                  character={gameState.character}
                  options={persOptions}
                  size={145}
                  waving
                  className="w-[130px] h-auto"
                />
                <Droplets size={72} className="text-cyan-300 drop-shadow-[0_0_16px_rgba(34,211,238,0.5)]" />
              </div>
              <p className="mt-3 text-xs text-center text-cyan-200 leading-snug">
                {dataset.scientificNote}
              </p>
            </div>

            <div className="md:col-span-7 space-y-4">
              <h3
                className="text-2xl sm:text-3xl font-extrabold text-amber-300"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                Por que razão a água é essencial?
              </h3>
              <p className="text-sm sm:text-base text-sky-100 leading-relaxed">
                Antes de planear novas bases espaciais, os cientistas usam o satélite <strong>NASA GPM (GPM_3IMERGM)</strong> para estudar como a chuva se distribui na Terra e onde existem recursos hídricos disponíveis.
              </p>

              {/* Terrain Explorer (SRTM) vs Rainfall Explorer (GPM) */}
              <div className="rounded-2xl border-2 border-sky-300/35 bg-slate-950/60 p-3.5 text-xs sm:text-sm">
                <div className="font-extrabold text-amber-300 mb-1.5">
                  Missões Complementares de Observação da Terra:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sky-100">
                  <div className="rounded-xl bg-slate-900/80 p-2.5 border border-white/10">
                    <strong className="text-emerald-300 block">Terrain Explorer (SRTM)</strong>
                    Analisa elevação, declives e estabilidade do terreno.
                  </div>
                  <div className="rounded-xl bg-slate-900/80 p-2.5 border border-cyan-300/40">
                    <strong className="text-cyan-300 block">Rainfall Explorer (GPM)</strong>
                    Analisa a distribuição e intensidade da chuva e a água disponível.
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <ArcadeButton
                  variant="yellow"
                  onClick={() => {
                    playStartFanfare(audioEnabled);
                    setState((prev) => ({ ...prev, step: 2 }));
                  }}
                  className="!min-w-[210px] !min-h-[54px] !text-lg"
                >
                  Iniciar Missão
                </ArcadeButton>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2 — INTERACTIVE EARTH EXPLORATION, CHARTS & WATER ASSESSMENT */}
        {state.step === 2 && (
          <div className="space-y-4">
            {/* Month Selector Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border-2 border-sky-300/35 bg-slate-950/60 p-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-extrabold text-amber-300 flex items-center gap-1.5 mr-1">
                  <Calendar size={15} /> Mês em Análise:
                </span>
                {months.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => handleSelectMonth(m.id)}
                    className={`rounded-full border px-3.5 py-1 text-xs font-extrabold transition-colors cursor-pointer ${
                      state.selectedMonthId === m.id
                        ? 'border-white bg-amber-400 text-slate-950'
                        : 'border-white/25 bg-slate-900 text-sky-100 hover:border-sky-300'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
              <span className="text-xs font-bold text-cyan-200 tabular-nums">
                Regiões exploradas: {state.exploredRegions.length}/{regions.length}
              </span>
            </div>

            {/* Map + Selected Region Info Panel */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
              <div className="lg:col-span-7">
                <GpmEarthMap
                  regions={regions}
                  selectedMonthId={state.selectedMonthId}
                  selectedRegionId={selectedRegion?.id}
                  compareRegionId={compareRegion?.id}
                  onSelectRegion={handleSelectRegion}
                />
              </div>

              <div className="lg:col-span-5 rounded-2xl border-2 border-sky-300/45 bg-slate-950/70 p-4 flex flex-col justify-between">
                {selectedRegion && (
                  <div className="space-y-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3
                          className="text-lg sm:text-xl font-extrabold text-white"
                          style={{ fontFamily: 'var(--font-display)' }}
                        >
                          {selectedRegion.name}
                        </h3>
                        <p className="text-xs text-sky-300">{selectedRegion.continent}</p>
                      </div>
                      <div className="text-right tabular-nums">
                        <div className="text-2xl font-extrabold text-cyan-300">
                          {selectedMm} mm
                        </div>
                        <div className="text-[11px] font-extrabold text-amber-300">
                          {selectedIntensity.label}
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-sky-100 leading-relaxed">
                      {selectedRegion.summary}
                    </p>

                    {/* Scientific Distinction: Precipitation vs Availability vs Resources */}
                    <div className="space-y-1.5 rounded-xl border border-cyan-300/30 bg-slate-900/80 p-2.5 text-[11px]">
                      <div>
                        <strong className="text-cyan-300">Disponibilidade de Água:</strong>{' '}
                        {selectedRegion.waterAvailability}
                      </div>
                      <div>
                        <strong className="text-emerald-300">Recursos Hídricos:</strong>{' '}
                        {selectedRegion.waterResources}
                      </div>
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleRecommendSelected}
                  className={`mt-3 w-full rounded-xl border-2 py-2.5 px-3 text-xs sm:text-sm font-extrabold transition-colors cursor-pointer ${
                    state.recommendedRegionId === selectedRegion?.id
                      ? 'border-emerald-300 bg-emerald-600 text-white'
                      : 'border-white bg-gradient-to-b from-amber-300 to-orange-500 text-slate-950 hover:brightness-105'
                  }`}
                >
                  {state.recommendedRegionId === selectedRegion?.id
                    ? `✓ Recomendada para Estudo: ${selectedRegion.name}`
                    : `Recomendar ${selectedRegion?.name} para Estudo Hídrico`}
                </button>
              </div>
            </div>

            {/* Comparison & Seasonal Charts */}
            <RainfallCharts
              regions={regions}
              months={months}
              selectedMonthId={state.selectedMonthId}
              selectedRegion={selectedRegion}
              compareRegion={compareRegion}
              onSelectCompareRegion={(id) =>
                setState((prev) => ({ ...prev, compareRegionId: id }))
              }
            />

            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-xs font-bold text-sky-200">
                {canEnterChallenges
                  ? 'Excelente exploração! Avança para os Desafios Científicos.'
                  : 'Explora pelo menos 2 regiões no mapa e recomenda uma região para estudo hídrico.'}
              </p>
              <ArcadeButton
                variant="yellow"
                onClick={() => {
                  playClickSound(audioEnabled);
                  setState((prev) => ({ ...prev, step: 3 }));
                }}
                className={`!min-w-[205px] !min-h-[50px] !text-base ${
                  !canEnterChallenges ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                <span>Ir para Desafios</span>
                <ArrowRight size={18} />
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* STEP 3 — EDUCATIONAL CHALLENGES (A, B, C) */}
        {state.step === 3 && (
          <div className="space-y-4">
            <div className="rounded-2xl border border-cyan-300/40 bg-cyan-950/35 p-3 text-xs text-cyan-100 flex items-start gap-2">
              <Info size={16} className="text-amber-300 shrink-0 mt-0.5" />
              <span>
                <strong>Distinção Científica:</strong> {dataset.concepts?.precipitation} ·{' '}
                {dataset.concepts?.availability} · {dataset.concepts?.resources}
              </span>
            </div>

            <div className="space-y-3">
              {RAINFALL_CHALLENGES.map((ch) => {
                const ans = state.challengeAnswers[ch.id];
                const isSolved = Boolean(ans?.correct);

                return (
                  <div
                    key={ch.id}
                    className="rounded-2xl border-2 border-sky-300/40 bg-slate-950/65 p-4"
                  >
                    <h3 className="text-sm sm:text-base font-extrabold text-amber-300 mb-1">
                      {ch.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-sky-100 mb-3">{ch.prompt}</p>

                    <div className="grid grid-cols-1 gap-2">
                      {ch.options.map((opt) => {
                        const isPicked = ans?.selectedId === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            disabled={isSolved}
                            onClick={() => handleAnswerChallenge(ch, opt)}
                            className={`text-left rounded-xl border-2 px-3.5 py-2.5 text-xs sm:text-sm font-bold transition-colors cursor-pointer ${
                              isPicked && opt.correct
                                ? 'border-emerald-400 bg-emerald-600/35 text-white'
                                : isPicked && !opt.correct
                                  ? 'border-rose-400 bg-rose-600/35 text-white'
                                  : 'border-white/20 bg-slate-900 text-sky-50 hover:border-amber-300'
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>

                    {ans && (
                      <p
                        className={`mt-2.5 text-xs sm:text-sm font-bold ${
                          ans.correct ? 'text-emerald-300' : 'text-rose-300'
                        }`}
                      >
                        {ans.correct ? ch.feedbackCorrect : ch.feedbackWrong}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setState((prev) => ({ ...prev, step: 2 }))}
                className="inline-flex items-center gap-1.5 rounded-full border-2 border-white/50 px-4 py-2 text-sm font-bold text-white hover:bg-white/10 cursor-pointer"
              >
                <ArrowLeft size={16} />
                <span>Voltar ao Mapa</span>
              </button>

              <ArcadeButton
                variant="yellow"
                onClick={() => {
                  playStartFanfare(audioEnabled);
                  setState((prev) => ({ ...prev, step: 4, completed: true }));
                }}
                className={`!min-w-[205px] !min-h-[50px] !text-base ${
                  !allChallengesSolved ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                Ver Resultados
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* STEP 4 — MISSION RESULTS */}
        {state.step === 4 && (
          <div className="flex flex-col items-center text-center py-2 space-y-4">
            <div className="w-[115px]">
              <AstronautCharacter
                character={gameState.character}
                options={persOptions}
                size={115}
                waving
                className="w-full h-auto"
              />
            </div>

            <div className="flex items-center gap-2" aria-label={`${report.starRating} estrelas`}>
              {[1, 2, 3].map((idx) => (
                <Star
                  key={idx}
                  size={32}
                  className={
                    idx <= report.starRating
                      ? 'text-amber-300 fill-amber-300 drop-shadow-[0_0_10px_rgba(251,191,36,0.6)]'
                      : 'text-slate-600'
                  }
                />
              ))}
            </div>

            <h3
              className="text-2xl sm:text-3xl font-extrabold text-amber-300"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Missão Rainfall Explorer Concluída!
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 w-full max-w-2xl tabular-nums">
              <div className="rounded-xl border border-amber-300/50 bg-slate-950/60 p-3">
                <div className="text-[11px] font-bold text-sky-200">Pontuação</div>
                <div className="text-xl font-extrabold text-amber-300">{report.score} pts</div>
              </div>
              <div className="rounded-xl border border-sky-300/50 bg-slate-950/60 p-3">
                <div className="text-[11px] font-bold text-sky-200">Regiões</div>
                <div className="text-xl font-extrabold text-white">{report.exploredRegionsCount}/{regions.length}</div>
              </div>
              <div className="rounded-xl border border-emerald-300/50 bg-slate-950/60 p-3">
                <div className="text-[11px] font-bold text-sky-200">Desafios</div>
                <div className="text-xl font-extrabold text-white">
                  {report.solvedChallenges}/{report.totalChallenges}
                </div>
              </div>
              <div className="rounded-xl border border-cyan-300/50 bg-slate-950/60 p-3">
                <div className="text-[11px] font-bold text-sky-200">Recomendação</div>
                <div className="text-xs font-extrabold text-cyan-200 mt-1">
                  {report.recommendedRegion?.name || '—'}
                </div>
              </div>
            </div>

            <div className="w-full max-w-2xl rounded-2xl border-2 border-sky-300/45 bg-slate-950/65 p-4 text-left text-xs sm:text-sm text-sky-100 space-y-1.5">
              <div className="font-extrabold text-amber-300 mb-1">
                O que aprendeste com os dados NASA GPM (GPM_3IMERGM):
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <span>{dataset.concepts?.precipitation}</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <span>{dataset.concepts?.availability}</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <span>{dataset.concepts?.resources}</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4">
              <ArcadeButton
                variant="red"
                onClick={() => {
                  playClickSound(audioEnabled);
                  setState(INITIAL_RAINFALL_STATE);
                }}
                className="!min-w-[190px] !min-h-[52px] !text-base"
              >
                <RotateCcw size={18} />
                <span>Jogar Novamente</span>
              </ArcadeButton>

              <ArcadeButton
                variant="yellow"
                onClick={() => onCompleteMission(report.starRating)}
                className="!min-w-[225px] !min-h-[52px] !text-base"
              >
                Voltar ao AstroBase
              </ArcadeButton>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
