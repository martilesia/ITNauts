import React from 'react';
import { CloudRain, Droplets } from 'lucide-react';
import { getIntensityLevel } from '../../../logic/rainfallEngine.js';

export default function GpmEarthMap({
  regions,
  selectedMonthId,
  selectedRegionId,
  compareRegionId,
  onSelectRegion,
}) {
  return (
    <div className="rounded-2xl border-3 border-sky-300 bg-[#0b2545] p-3 flex flex-col justify-between">
      <div className="relative w-full aspect-[16/9] rounded-xl overflow-hidden bg-gradient-to-b from-[#0c4a6e] to-[#082f49] border border-sky-400/35">
        {/* Stylized World Continents Silhouette */}
        <svg viewBox="0 0 100 60" className="w-full h-full opacity-60" aria-hidden="true">
          <path d="M10 13 L30 11 L33 25 L20 30 L11 22 Z" fill="#22c55e" />
          <path d="M23 32 L39 35 L35 55 L24 52 Z" fill="#16a34a" />
          <path d="M44 10 L59 10 L57 22 L45 20 Z" fill="#22c55e" />
          <path d="M44 22 L60 24 L56 48 L45 43 Z" fill="#eab308" />
          <path d="M59 12 L88 14 L85 36 L63 34 Z" fill="#22c55e" />
          <path d="M76 40 L89 42 L86 52 L75 50 Z" fill="#16a34a" />
        </svg>

        {/* Rainfall Visualization Overlay Halos */}
        {regions.map((reg) => {
          const mm = reg.monthlyMm?.[selectedMonthId] || 0;
          const intensity = getIntensityLevel(mm);
          const haloSize = Math.max(28, Math.min(84, 24 + mm * 0.17));

          return (
            <div
              key={`halo-${reg.id}`}
              style={{
                left: `${reg.x}%`,
                top: `${reg.y}%`,
                width: `${haloSize}px`,
                height: `${haloSize}px`,
                backgroundColor: intensity.color,
              }}
              className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 rounded-full opacity-35 blur-[4px] transition-all duration-300"
              aria-hidden="true"
            />
          );
        })}

        {/* Interactive Clickable Region Pins */}
        {regions.map((reg) => {
          const mm = reg.monthlyMm?.[selectedMonthId] || 0;
          const intensity = getIntensityLevel(mm);
          const isPrimary = reg.id === selectedRegionId;
          const isCompare = reg.id === compareRegionId;

          return (
            <button
              key={reg.id}
              type="button"
              onClick={() => onSelectRegion(reg.id)}
              style={{ left: `${reg.x}%`, top: `${reg.y}%` }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 px-2.5 py-1 text-[11px] font-extrabold shadow-lg transition-transform cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                intensity.id === 'high'
                  ? 'bg-blue-600 border-white text-white'
                  : intensity.id === 'moderate'
                    ? 'bg-sky-400 border-white text-slate-950'
                    : 'bg-amber-400 border-white text-slate-950'
              } ${
                isPrimary
                  ? 'ring-4 ring-yellow-300 scale-115 z-20'
                  : isCompare
                    ? 'ring-3 ring-pink-400 scale-105 z-10'
                    : 'hover:scale-105'
              }`}
            >
              {intensity.id === 'high' ? (
                <CloudRain size={12} />
              ) : (
                <Droplets size={12} />
              )}
              <span>{reg.name.split(' ')[0]} · {mm} mm</span>
            </button>
          );
        })}
      </div>

      {/* Rainfall Intensity Legend */}
      <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs font-bold">
        <div className="flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-blue-600 border border-white/70 inline-block" />
            Alta (≥180 mm)
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-sky-400 border border-white/70 inline-block" />
            Moderada (55–179 mm)
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-400 border border-white/70 inline-block" />
            Baixa (&lt;55 mm)
          </span>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-sky-200">
          <span className="inline-flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-300 inline-block" /> Selecionada
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-pink-400 inline-block" /> Comparação
          </span>
        </div>
      </div>
    </div>
  );
}
