import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  Award,
  CheckCircle2,
  Droplets,
  Info,
  Radio,
  RotateCcw,
  Satellite,
  ScanLine,
  Sparkles,
  Star,
  Trophy,
  Waves,
  X,
} from 'lucide-react';
import {
  INITIAL_SOIL_EXPLORER_STATE,
  SOIL_CHALLENGES,
  SOIL_COLOR_LEGEND,
  SOIL_EDU_CARDS,
  SOIL_REGIONS,
  SOIL_SCIENTIFIC_INFO,
  SOIL_STEPS,
  computeSoilStars,
} from '../../../logic/soilExplorerEngine.js';
import {
  playChargeSound,
  playClickSound,
  playErrorSound,
  playStartFanfare,
  playSuccessSound,
} from '../../../utils/soundFx.js';
import ArcadeButton from '../../ArcadeButton.jsx';
import AstronautCharacter from '../../AstronautCharacter.jsx';
import SmapEarthMap from './SmapEarthMap.jsx';

export default function SoilExplorerModal({
  isOpen,
  mission,
  gameState,
  persOptions,
  onCompleteMission,
  onClose,
}) {
  const [state, setState] = useState(INITIAL_SOIL_EXPLORER_STATE);
  const scanTimerRef = useRef(null);

  const audioEnabled = Boolean(gameState?.audioEnabled);

  useEffect(() => {
    if (!isOpen) return;
    setState(INITIAL_SOIL_EXPLORER_STATE);
    return () => {
      if (scanTimerRef.current) {
        clearTimeout(scanTimerRef.current);
      }
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen || !mission) return null;

  const selectedRegion =
    SOIL_REGIONS.find((r) => r.id === state.selectedRegionId) || null;
  const allRegionsObserved = state.observedRegions.length === SOIL_REGIONS.length;

  const correctCount = SOIL_CHALLENGES.filter(
    (ch) => state.answers[ch.id]?.correct
  ).length;
  const allQuizSolved = correctCount === SOIL_CHALLENGES.length;
  const earnedStars = computeSoilStars(state);

  const handleStartMission = () => {
    playStartFanfare(audioEnabled);
    setState((prev) => ({ ...prev, step: 2 }));
  };

  const handleSelectRegion = (regionId) => {
    if (state.isScanning) return;
    playClickSound(audioEnabled);
    setState((prev) => ({
      ...prev,
      selectedRegionId: regionId,
      lastObservedMessage: null,
    }));
  };

  const handleStartObservation = () => {
    if (!state.selectedRegionId || state.isScanning) return;
    const targetId = state.selectedRegionId;
    playChargeSound(audioEnabled);

    setState((prev) => ({
      ...prev,
      isScanning: true,
      lastObservedMessage: null,
    }));

    scanTimerRef.current = setTimeout(() => {
      playSuccessSound(audioEnabled);
      setState((prev) => {
        const isNew = !prev.observedRegions.includes(targetId);
        return {
          ...prev,
          isScanning: false,
          observedRegions: isNew
            ? [...prev.observedRegions, targetId]
            : prev.observedRegions,
          score: isNew ? prev.score + 30 : prev.score,
          lastObservedMessage:
            'Observação concluída! Os dados sobre a humidade do solo foram recebidos.',
        };
      });
    }, 1450);
  };

  const handleAnswerQuiz = (challenge, option) => {
    if (state.answers[challenge.id]?.correct) return;

    const alreadyTried = Boolean(state.answers[challenge.id]);
    if (option.correct) {
      playSuccessSound(audioEnabled);
    } else {
      playErrorSound(audioEnabled);
    }

    setState((prev) => {
      const nextAnswers = {
        ...prev.answers,
        [challenge.id]: {
          selectedId: option.id,
          correct: Boolean(option.correct),
        },
      };
      const solvedNow = SOIL_CHALLENGES.every((c) => nextAnswers[c.id]?.correct);
      if (solvedNow) {
        playStartFanfare(audioEnabled);
      }
      const addedScore = option.correct ? (alreadyTried ? 60 : 100) : 0;

      return {
        ...prev,
        answers: nextAnswers,
        score: prev.score + addedScore,
        firstTryCorrectCount:
          option.correct && !alreadyTried
            ? prev.firstTryCorrectCount + 1
            : prev.firstTryCorrectCount,
        wrongAttempts: option.correct ? prev.wrongAttempts : prev.wrongAttempts + 1,
        quizCompleted: solvedNow,
      };
    });
  };

  const handlePlayAgain = () => {
    if (scanTimerRef.current) clearTimeout(scanTimerRef.current);
    playClickSound(audioEnabled);
    setState(INITIAL_SOIL_EXPLORER_STATE);
  };

  const getEduCardIcon = (id) => {
    if (id === 'satellite') return Satellite;
    if (id === 'microwaves') return Waves;
    return Droplets;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-5 bg-[#070b1e]/90 backdrop-blur-sm overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="soil-explorer-title"
    >
      <div className="relative w-full max-w-5xl my-auto rounded-[28px] border-4 border-emerald-300 bg-gradient-to-b from-[#162d68] via-[#12265c] to-[#0a1438] p-4 sm:p-6 shadow-[0_24px_70px_rgba(0,0,0,0.85)] text-white">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Voltar à AstroBase"
          className="absolute top-4 right-4 w-10 h-10 rounded-full border-2 border-white/80 bg-rose-600 hover:bg-rose-500 flex items-center justify-center text-white shadow-md cursor-pointer"
        >
          <X size={20} strokeWidth={2.75} />
        </button>

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pr-12 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl border-2 border-emerald-300 bg-emerald-900/60 flex items-center justify-center shrink-0">
              <Satellite size={28} className="text-amber-300" />
            </div>
            <div>
              <div className="text-xs font-extrabold uppercase tracking-wider text-emerald-300">
                Missão 5 · NASA {SOIL_SCIENTIFIC_INFO.smapFullName}
              </div>
              <h2
                id="soil-explorer-title"
                className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white leading-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {SOIL_SCIENTIFIC_INFO.missionName}
              </h2>
            </div>
          </div>

          <div className="inline-flex items-center gap-2 rounded-xl border border-amber-300/65 bg-slate-950/75 px-3 py-1.5 text-xs sm:text-sm font-extrabold text-amber-300 tabular-nums self-start sm:self-auto">
            <Trophy size={16} /> Pontuação: {state.score} pts
          </div>
        </div>

        {/* 4-Interface Progress Bar */}
        <div className="grid grid-cols-4 gap-1.5 mb-5">
          {SOIL_STEPS.map((st) => {
            const isActive = state.step === st.id;
            const isDone = state.step > st.id || (st.id === 4 && state.quizCompleted);
            return (
              <div
                key={st.id}
                className={`rounded-xl border px-2 py-1.5 text-center text-[11px] sm:text-xs font-extrabold truncate ${
                  isActive
                    ? 'border-amber-300 bg-amber-400 text-slate-950'
                    : isDone
                      ? 'border-emerald-400/75 bg-emerald-500/25 text-emerald-200'
                      : 'border-white/20 bg-slate-950/55 text-slate-300'
                }`}
              >
                {st.label}
              </div>
            );
          })}
        </div>

        {/* INTERFACE 1 — BRIEFING DA MISSÃO */}
        {state.step === 1 && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center py-2">
            {/* Illustrations Card: Astronaut + Satellite + Planet Earth */}
            <div className="md:col-span-5 rounded-3xl border-2 border-sky-300/50 bg-slate-950/65 p-5 flex flex-col items-center gap-3">
              <div className="flex items-center justify-center gap-4">
                <div className="animate-float-slow">
                  <AstronautCharacter
                    character={gameState?.character}
                    options={persOptions}
                    size={135}
                    waving
                    className="w-[120px] h-auto"
                  />
                </div>

                {/* Custom Friendly 2D SMAP Satellite SVG */}
                <svg
                  width="110"
                  height="110"
                  viewBox="0 0 120 120"
                  role="img"
                  aria-label="Ilustração do satélite SMAP da NASA"
                  className="drop-shadow-[0_0_18px_rgba(56,189,248,0.4)]"
                >
                  {/* Solar Wings */}
                  <rect x="6" y="42" width="32" height="26" rx="4" fill="#2563eb" stroke="#93c5fd" strokeWidth="2.5" />
                  <line x1="16" y1="42" x2="16" y2="68" stroke="#bae6fd" strokeWidth="1.5" />
                  <line x1="27" y1="42" x2="27" y2="68" stroke="#bae6fd" strokeWidth="1.5" />
                  <rect x="82" y="42" width="32" height="26" rx="4" fill="#2563eb" stroke="#93c5fd" strokeWidth="2.5" />
                  <line x1="93" y1="42" x2="93" y2="68" stroke="#bae6fd" strokeWidth="1.5" />
                  <line x1="104" y1="42" x2="104" y2="68" stroke="#bae6fd" strokeWidth="1.5" />
                  {/* Satellite Body */}
                  <rect x="42" y="34" width="36" height="42" rx="10" fill="#fbbf24" stroke="#ffffff" strokeWidth="2.5" />
                  <circle cx="60" cy="52" r="9" fill="#0f172a" stroke="#38bdf8" strokeWidth="2.5" />
                  <circle cx="60" cy="52" r="4" fill="#38bdf8" />
                  {/* Dish Antenna */}
                  <path d="M44 82 Q60 98 76 82" stroke="#e2e8f0" strokeWidth="3.5" fill="none" strokeLinecap="round" />
                  <line x1="60" y1="76" x2="60" y2="90" stroke="#e2e8f0" strokeWidth="2.5" />
                  {/* Signal Waves */}
                  <path d="M48 98 Q60 107 72 98" stroke="#38bdf8" strokeWidth="2.5" fill="none" strokeLinecap="round" />
                  <path d="M40 106 Q60 118 80 106" stroke="#22d3ee" strokeWidth="2" fill="none" strokeLinecap="round" />
                </svg>
              </div>

              <div className="rounded-2xl border border-cyan-300/40 bg-cyan-950/45 px-3 py-2 text-[11px] font-bold text-cyan-100 text-center">
                {SOIL_SCIENTIFIC_INFO.earthOnlyNote}
              </div>
            </div>

            {/* Welcome Dialogue & Start CTA */}
            <div className="md:col-span-7 space-y-4">
              <div className="rounded-2xl border-2 border-amber-300 bg-slate-950/75 p-4 shadow-lg">
                <div className="text-xs font-extrabold uppercase tracking-wider text-amber-300 mb-1">
                  Boas-vindas da Equipa Espacial
                </div>
                <p className="text-base sm:text-lg font-extrabold text-white leading-snug">
                  “Olá, pequeno cientista! Hoje vamos ajudar a NASA a estudar a quantidade de água existente no solo da Terra. Estás preparado para esta missão?”
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs font-bold">
                <div className="rounded-2xl border border-emerald-300/40 bg-slate-950/60 p-3 text-emerald-100">
                  <strong className="text-emerald-300 block mb-0.5">O que vais fazer:</strong>
                  Escolher 3 regiões no mapa da Terra, ativar o satélite SMAP e descobrir quanta água há em cada solo.
                </div>
                <div className="rounded-2xl border border-sky-300/40 bg-slate-950/60 p-3 text-sky-100">
                  <strong className="text-sky-300 block mb-0.5">Missão Científica:</strong>
                  Aprender como as micro-ondas ajudam a medir a humidade sem tocar no chão!
                </div>
              </div>

              <div className="flex justify-end pt-1">
                <ArcadeButton
                  variant="yellow"
                  onClick={handleStartMission}
                  className="!min-w-[235px] !min-h-[58px] !text-lg"
                >
                  INICIAR MISSÃO
                </ArcadeButton>
              </div>
            </div>
          </div>
        )}

        {/* INTERFACE 2 — EXPLORAÇÃO POR SATÉLITE */}
        {state.step === 2 && (
          <div className="space-y-4">
            <SmapEarthMap
              regions={SOIL_REGIONS}
              selectedRegionId={state.selectedRegionId}
              observedRegions={state.observedRegions}
              isScanning={state.isScanning}
              onSelectRegion={handleSelectRegion}
            />

            {/* Region Selection Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {SOIL_REGIONS.map((reg) => {
                const isSelected = state.selectedRegionId === reg.id;
                const isObserved = state.observedRegions.includes(reg.id);

                return (
                  <button
                    key={reg.id}
                    type="button"
                    disabled={state.isScanning}
                    onClick={() => handleSelectRegion(reg.id)}
                    className={`rounded-2xl border-2 p-3 text-left transition-all cursor-pointer flex items-center justify-between gap-2 ${
                      isSelected
                        ? 'border-amber-300 bg-amber-400/20 shadow-md -translate-y-0.5'
                        : isObserved
                          ? 'border-emerald-400/75 bg-emerald-950/45 hover:border-amber-300'
                          : 'border-white/20 bg-slate-950/70 hover:border-sky-300'
                    }`}
                  >
                    <div>
                      <div className="text-sm font-extrabold text-white">{reg.code}</div>
                      <div className="text-[11px] font-bold text-sky-200">{reg.landscape}</div>
                      <div className="mt-1 text-[11px] font-extrabold text-amber-300">
                        {isObserved ? '✓ Dados recebidos' : isSelected ? 'Selecionada' : 'Clica para selecionar'}
                      </div>
                    </div>
                    {isObserved ? (
                      <CheckCircle2 size={22} className="text-emerald-400 shrink-0" />
                    ) : (
                      <Radio size={20} className={isSelected ? 'text-amber-300 shrink-0' : 'text-sky-400 shrink-0'} />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Observation Control + Feedback Message */}
            <div className="rounded-2xl border-2 border-sky-300/60 bg-slate-950/80 p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs sm:text-sm font-bold text-sky-100 text-center sm:text-left">
                {state.isScanning ? (
                  <span className="inline-flex items-center gap-2 text-amber-300 font-extrabold">
                    <ScanLine size={18} className="animate-spin" />
                    Satélite SMAP a digitalizar a {selectedRegion?.code}...
                  </span>
                ) : state.lastObservedMessage ? (
                  <span className="inline-flex items-center gap-2 text-emerald-300 font-extrabold">
                    <CheckCircle2 size={18} />
                    {state.lastObservedMessage}
                  </span>
                ) : selectedRegion ? (
                  <span>
                    <strong className="text-amber-300">{selectedRegion.code}</strong> selecionada ({selectedRegion.hint}). Clica em <strong>INICIAR OBSERVAÇÃO</strong>!
                  </span>
                ) : (
                  <span>Seleciona uma das três regiões no mapa da Terra para iniciar a observação.</span>
                )}
              </div>

              {selectedRegion && (
                <ArcadeButton
                  variant="yellow"
                  onClick={handleStartObservation}
                  className={`!min-w-[235px] !min-h-[50px] !text-sm sm:!text-base ${
                    state.isScanning ? 'opacity-60 pointer-events-none' : ''
                  }`}
                >
                  <Satellite size={18} className="mr-1.5" />
                  INICIAR OBSERVAÇÃO
                </ArcadeButton>
              )}
            </div>

            {/* Step 2 -> Step 3 Footer */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs font-bold text-sky-200">
                {allRegionsObserved
                  ? 'Excelente! Já observaste as 3 regiões. Podes analisar os resultados!'
                  : `Observa as três regiões para continuar (${state.observedRegions.length}/3 concluídas).`}
              </span>
              <ArcadeButton
                variant="yellow"
                onClick={() => {
                  playClickSound(audioEnabled);
                  setState((prev) => ({ ...prev, step: 3 }));
                }}
                className={`!min-w-[230px] !min-h-[50px] !text-base ${
                  !allRegionsObserved ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                <span>Analisar Dados</span>
                <ArrowRight size={18} className="ml-1.5" />
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* INTERFACE 3 — ANÁLISE DA HUMIDADE DO SOLO */}
        {state.step === 3 && (
          <div className="space-y-4">
            {/* Simulated Note */}
            <div className="rounded-2xl border border-amber-300/60 bg-amber-950/35 px-3.5 py-2 flex items-center gap-2 text-xs font-bold text-amber-200">
              <Info size={16} className="text-amber-300 shrink-0" />
              <span>{SOIL_SCIENTIFIC_INFO.simulatedDataNote}</span>
            </div>

            {/* Colored Results Cards for Regions A, B, C */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 tabular-nums">
              {SOIL_REGIONS.map((reg) => (
                <div
                  key={reg.id}
                  className={`rounded-3xl border-3 p-4 shadow-lg flex flex-col justify-between gap-3 ${reg.cardClass}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-base font-extrabold text-white">{reg.code}</div>
                      <div className="text-[11px] font-bold text-white/80">{reg.landscape}</div>
                    </div>
                    <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-extrabold ${reg.badgeClass}`}>
                      {reg.colorName}
                    </span>
                  </div>

                  <div>
                    <div
                      className="text-3xl font-extrabold text-white leading-none"
                      style={{ fontFamily: 'var(--font-display)' }}
                    >
                      {reg.moisturePct}%
                    </div>
                    <div className="mt-1 text-sm font-extrabold text-white/95">
                      {reg.statusLabel}
                    </div>
                    <div className="mt-2 h-3 rounded-full bg-slate-950/60 overflow-hidden border border-white/15">
                      <div
                        className={`h-full bg-gradient-to-r ${reg.barClass}`}
                        style={{ width: `${reg.moisturePct * 1.9}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Color Scale Legend (Azul, Verde, Amarelo, Vermelho) */}
            <div className="rounded-2xl border-2 border-white/15 bg-slate-950/75 p-3">
              <div className="text-xs font-extrabold uppercase tracking-wider text-sky-300 mb-2">
                Escala de Cores da Humidade do Solo
              </div>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
                {SOIL_COLOR_LEGEND.map((item) => (
                  <div
                    key={item.id}
                    className={`rounded-xl border px-2.5 py-2 flex items-center gap-2 text-xs font-bold ${item.borderClass}`}
                  >
                    <span
                      className="w-4 h-4 rounded-full border border-white shrink-0"
                      style={{ backgroundColor: item.swatch }}
                    />
                    <span>
                      <strong>{item.label}:</strong> {item.meaning}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Simple SMAP Explanation + 3 Educational Cards */}
            <div className="rounded-2xl border-2 border-cyan-300/60 bg-slate-950/80 p-4 space-y-3">
              <p className="text-xs sm:text-sm font-bold text-white leading-relaxed">
                {SOIL_SCIENTIFIC_INFO.explanation}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                {SOIL_EDU_CARDS.map((card) => {
                  const Icon = getEduCardIcon(card.id);
                  return (
                    <div
                      key={card.id}
                      className={`rounded-2xl border-2 p-3 flex items-start gap-2.5 ${card.accentClass}`}
                    >
                      <div className="w-9 h-9 rounded-xl bg-slate-950/60 border border-white/25 flex items-center justify-center shrink-0">
                        <Icon size={18} />
                      </div>
                      <div>
                        <div className="text-xs font-extrabold text-white">{card.title}</div>
                        <p className="mt-0.5 text-[11px] font-semibold text-white/90 leading-snug">
                          {card.text}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setState((prev) => ({ ...prev, step: 2 }))}
                className="rounded-full border-2 border-sky-300/60 bg-slate-900 px-4 py-2 text-xs font-extrabold text-sky-100 hover:border-amber-300 cursor-pointer"
              >
                Voltar ao Mapa
              </button>

              <ArcadeButton
                variant="yellow"
                onClick={() => {
                  playClickSound(audioEnabled);
                  setState((prev) => ({ ...prev, step: 4 }));
                }}
                className="!min-w-[250px] !min-h-[52px] !text-base"
              >
                <span>Desafio Científico</span>
                <ArrowRight size={18} className="ml-1.5" />
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* INTERFACE 4 — DESAFIO DO PEQUENO CIENTISTA */}
        {state.step === 4 && (
          <div className="space-y-4">
            {/* Interactive Questions */}
            {!state.quizCompleted && (
              <div className="space-y-3">
                {SOIL_CHALLENGES.map((ch, idx) => {
                  const ans = state.answers[ch.id];
                  const isSolved = Boolean(ans?.correct);

                  return (
                    <div
                      key={ch.id}
                      className="rounded-2xl border-2 border-amber-300/70 bg-slate-950/80 p-4 space-y-3"
                    >
                      <div className="text-xs font-extrabold uppercase tracking-wider text-amber-300">
                        Desafio {idx + 1} de {SOIL_CHALLENGES.length}
                      </div>
                      <h3 className="text-base sm:text-lg font-extrabold text-white">
                        {ch.prompt}
                      </h3>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        {ch.options.map((opt) => {
                          const picked = ans?.selectedId === opt.id;
                          return (
                            <button
                              key={opt.id}
                              type="button"
                              disabled={isSolved}
                              onClick={() => handleAnswerQuiz(ch, opt)}
                              className={`rounded-2xl border-2 px-4 py-3 text-sm font-extrabold transition-all cursor-pointer text-center ${
                                picked && opt.correct
                                  ? 'border-emerald-300 bg-emerald-500/35 text-white scale-[1.02]'
                                  : picked && !opt.correct
                                    ? 'border-rose-400 bg-rose-600/35 text-white'
                                    : 'border-sky-300/40 bg-slate-900 text-sky-100 hover:border-amber-300'
                              }`}
                            >
                              {opt.label}
                            </button>
                          );
                        })}
                      </div>

                      {ans && (
                        <div
                          className={`rounded-xl border p-3 text-xs sm:text-sm font-bold flex items-center gap-2 ${
                            ans.correct
                              ? 'border-emerald-400 bg-emerald-950/60 text-emerald-200'
                              : 'border-rose-400 bg-rose-950/60 text-rose-200'
                          }`}
                        >
                          {ans.correct ? (
                            <Sparkles size={18} className="text-amber-300 shrink-0 animate-pulse" />
                          ) : (
                            <Info size={18} className="text-rose-300 shrink-0" />
                          )}
                          <span>{ans.correct ? ch.feedbackCorrect : ch.feedbackWrong}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Final Celebration, Score, Medal & Action Buttons */}
            {allQuizSolved && (
              <div className="rounded-3xl border-3 border-amber-300 bg-gradient-to-b from-[#1e357d] via-[#172861] to-[#0d163c] p-5 flex flex-col items-center text-center space-y-4 shadow-xl">
                <div className="flex items-center gap-3">
                  <AstronautCharacter
                    character={gameState?.character}
                    options={persOptions}
                    size={105}
                    waving
                    className="w-[92px] h-auto"
                  />
                  <div className="animate-bounce rounded-full border-4 border-amber-300 bg-amber-400/20 p-4 shadow-[0_0_28px_rgba(251,191,36,0.5)]">
                    <Award size={52} className="text-amber-300" />
                  </div>
                </div>

                <div className="flex items-center gap-2" aria-label={`${earnedStars} de 3 estrelas`}>
                  {[1, 2, 3].map((s) => (
                    <Star
                      key={s}
                      size={30}
                      className={
                        s <= earnedStars
                          ? 'text-amber-300 fill-amber-300 drop-shadow-[0_0_10px_rgba(251,191,36,0.65)]'
                          : 'text-slate-600'
                      }
                    />
                  ))}
                </div>

                <div>
                  <div className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300 bg-emerald-500/25 px-3 py-1 text-xs font-extrabold uppercase tracking-wider text-emerald-200 mb-1.5">
                    <Sparkles size={14} /> Medalha de Pequeno Cientista
                  </div>
                  <h3
                    className="text-2xl sm:text-3xl font-extrabold text-amber-300"
                    style={{ fontFamily: 'var(--font-display)' }}
                  >
                    Explorador da Humidade do Solo!
                  </h3>
                  <p className="mt-1 text-xs sm:text-sm font-bold text-sky-100 max-w-xl">
                    Parabéns! Ajudaste a NASA a estudar a humidade do solo da Terra com o satélite SMAP e completaste todos os desafios!
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-xl tabular-nums">
                  <div className="rounded-2xl border border-amber-300/60 bg-slate-950/75 p-3">
                    <div className="text-[11px] font-bold text-sky-200">Pontuação Alcançada</div>
                    <div className="text-xl font-extrabold text-amber-300">{state.score} pts</div>
                  </div>
                  <div className="rounded-2xl border border-emerald-300/60 bg-slate-950/75 p-3">
                    <div className="text-[11px] font-bold text-sky-200">Respostas Correctas</div>
                    <div className="text-xl font-extrabold text-emerald-300">
                      {correctCount}/{SOIL_CHALLENGES.length}
                    </div>
                  </div>
                  <div className="rounded-2xl border border-cyan-300/60 bg-slate-950/75 p-3">
                    <div className="text-[11px] font-bold text-sky-200">Regiões Exploradas</div>
                    <div className="text-xl font-extrabold text-white">
                      {state.observedRegions.length}/{SOIL_REGIONS.length}
                    </div>
                  </div>
                </div>

                <div className="rounded-xl border border-cyan-300/40 bg-slate-950/70 px-4 py-2 text-[11px] font-bold text-cyan-200 max-w-2xl">
                  {SOIL_SCIENTIFIC_INFO.earthOnlyNote}
                </div>

                <div className="flex flex-wrap items-center justify-center gap-4 pt-1">
                  <ArcadeButton
                    variant="red"
                    onClick={handlePlayAgain}
                    className="!min-w-[205px] !min-h-[52px] !text-base"
                  >
                    <RotateCcw size={18} className="mr-1.5" />
                    JOGAR NOVAMENTE
                  </ArcadeButton>

                  <ArcadeButton
                    variant="yellow"
                    onClick={() => onCompleteMission(earnedStars)}
                    className="!min-w-[235px] !min-h-[52px] !text-base"
                  >
                    VOLTAR À ASTROBASE
                  </ArcadeButton>
                </div>
              </div>
            )}

            {!state.quizCompleted && (
              <div className="flex justify-start">
                <button
                  type="button"
                  onClick={() => setState((prev) => ({ ...prev, step: 3 }))}
                  className="rounded-full border-2 border-sky-300/60 bg-slate-900 px-4 py-2 text-xs font-extrabold text-sky-100 hover:border-amber-300 cursor-pointer"
                >
                  Voltar à Análise
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
