import React from 'react';
import { CheckCircle2, Radio, Satellite } from 'lucide-react';

export default function SmapEarthMap({
  regions,
  selectedRegionId,
  observedRegions,
  isScanning,
  onSelectRegion,
}) {
  const selectedRegion = regions.find((r) => r.id === selectedRegionId) || null;

  return (
    <div className="relative rounded-3xl border-3 border-sky-300/75 bg-[#071739] p-3 overflow-hidden shadow-inner">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2 px-1">
        <span className="text-xs font-extrabold uppercase tracking-wider text-cyan-200">
          Mapa 2D da Terra · Observação por Satélite SMAP
        </span>
        <span className="text-xs font-extrabold text-amber-300 tabular-nums">
          Regiões observadas: {observedRegions.length}/{regions.length}
        </span>
      </div>

      {/* 2D Stylized Earth Map SVG */}
      <div className="relative w-full aspect-[16/9] rounded-2xl overflow-hidden border-2 border-sky-400/50 bg-gradient-to-b from-[#0ea5e9] via-[#0284c7] to-[#0369a1]">
        <svg
          viewBox="0 0 800 450"
          className="w-full h-full"
          role="img"
          aria-label="Mapa 2D da Terra com três regiões para observação de humidade do solo"
        >
          {/* Subtle Coordinate Grid */}
          {[90, 180, 270, 360].map((y) => (
            <line
              key={`h-${y}`}
              x1="0"
              y1={y}
              x2="800"
              y2={y}
              stroke="rgba(255,255,255,0.16)"
              strokeWidth="1"
              strokeDasharray="6 6"
            />
          ))}
          {[160, 320, 480, 640].map((x) => (
            <line
              key={`v-${x}`}
              x1={x}
              y1="0"
              x2={x}
              y2="450"
              stroke="rgba(255,255,255,0.16)"
              strokeWidth="1"
              strokeDasharray="6 6"
            />
          ))}

          {/* North America */}
          <path
            d="M80 75 Q145 50 215 80 Q245 125 215 170 Q180 205 150 220 Q125 180 95 145 Z"
            fill="#4ade80"
            stroke="#166534"
            strokeWidth="3"
          />
          {/* South America (contains Region C) */}
          <path
            d="M210 225 Q265 215 295 265 Q305 330 265 395 Q230 390 215 330 Q195 275 210 225 Z"
            fill="#22c55e"
            stroke="#14532d"
            strokeWidth="3"
          />
          {/* Europe (contains Region B) */}
          <path
            d="M350 75 Q410 55 465 80 Q475 125 435 145 Q380 150 355 120 Z"
            fill="#4ade80"
            stroke="#166534"
            strokeWidth="3"
          />
          {/* Africa (contains Region A) */}
          <path
            d="M365 160 Q435 145 485 185 Q505 245 470 315 Q440 365 405 350 Q380 295 360 240 Z"
            fill="#fbbf24"
            stroke="#92400e"
            strokeWidth="3"
          />
          {/* Asia */}
          <path
            d="M475 70 Q585 50 685 95 Q720 155 665 210 Q590 235 515 190 Q475 145 475 70 Z"
            fill="#4ade80"
            stroke="#166534"
            strokeWidth="3"
          />
          {/* Oceania */}
          <path
            d="M615 290 Q675 275 710 315 Q700 365 645 360 Q605 340 615 290 Z"
            fill="#86efac"
            stroke="#166534"
            strokeWidth="3"
          />

          {/* Decorative Clouds */}
          <ellipse cx="145" cy="115" rx="34" ry="11" fill="rgba(255,255,255,0.45)" />
          <ellipse cx="560" cy="135" rx="42" ry="12" fill="rgba(255,255,255,0.4)" />
          <ellipse cx="320" cy="360" rx="36" ry="10" fill="rgba(255,255,255,0.35)" />

          {/* Microwave Scan Cone & Pulse when scanning */}
          {isScanning && selectedRegion && (
            <g>
              <polygon
                points={`400,45 ${selectedRegion.x * 8 - 44},${selectedRegion.y * 4.5} ${selectedRegion.x * 8 + 44},${selectedRegion.y * 4.5}`}
                fill="rgba(56, 189, 248, 0.34)"
                stroke="#fde047"
                strokeWidth="2"
                strokeDasharray="6 4"
              />
              <circle
                cx={selectedRegion.x * 8}
                cy={selectedRegion.y * 4.5}
                r="42"
                fill="rgba(250, 204, 21, 0.22)"
                stroke="#fde047"
                strokeWidth="3"
              >
                <animate attributeName="r" values="18;54;18" dur="1.1s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.9;0.25;0.9" dur="1.1s" repeatCount="indefinite" />
              </circle>
              <circle
                cx={selectedRegion.x * 8}
                cy={selectedRegion.y * 4.5}
                r="24"
                fill="none"
                stroke="#38bdf8"
                strokeWidth="3"
              >
                <animate attributeName="r" values="10;38;10" dur="0.9s" repeatCount="indefinite" />
              </circle>
            </g>
          )}
        </svg>

        {/* Animated Orbiting SMAP Satellite Overlay */}
        <div
          className={`pointer-events-none absolute top-2.5 left-1/2 -translate-x-1/2 flex items-center gap-2 rounded-full border-2 px-3 py-1 shadow-lg transition-all duration-500 ${
            isScanning
              ? 'border-amber-300 bg-slate-950/95 text-amber-300 scale-110'
              : 'border-sky-200/80 bg-slate-950/75 text-sky-100'
          }`}
        >
          <Satellite
            size={18}
            className={isScanning ? 'text-amber-300 animate-bounce' : 'text-cyan-300'}
          />
          <span className="text-[11px] font-extrabold tracking-wide">
            {isScanning ? 'A digitalizar com micro-ondas SMAP...' : 'Satélite SMAP em Órbita'}
          </span>
          {isScanning && <Radio size={15} className="text-cyan-300 animate-pulse" />}
        </div>

        {/* Clickable Region Pins */}
        {regions.map((reg) => {
          const isSelected = reg.id === selectedRegionId;
          const isObserved = observedRegions.includes(reg.id);

          return (
            <button
              key={reg.id}
              type="button"
              disabled={isScanning}
              onClick={() => onSelectRegion(reg.id)}
              style={{ left: `${reg.x}%`, top: `${reg.y}%` }}
              aria-label={`Selecionar ${reg.code}`}
              className={`absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center transition-transform cursor-pointer focus:outline-none ${
                isSelected ? 'scale-115 z-20' : 'hover:scale-110 z-10'
              }`}
            >
              <span
                className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full border-3 flex items-center justify-center font-extrabold text-sm shadow-lg ${
                  isObserved
                    ? 'border-white text-white'
                    : isSelected
                      ? 'border-amber-300 bg-amber-400 text-slate-950 ring-4 ring-amber-300/50'
                      : 'border-white bg-slate-900/90 text-white hover:bg-amber-400 hover:text-slate-950'
                }`}
                style={isObserved ? { backgroundColor: reg.hex } : undefined}
              >
                {isObserved ? <CheckCircle2 size={22} /> : reg.code.slice(-1)}
              </span>
              <span
                className={`mt-1 rounded-full px-2.5 py-0.5 text-[11px] font-extrabold shadow-md border whitespace-nowrap ${
                  isSelected
                    ? 'border-amber-300 bg-slate-950 text-amber-300'
                    : 'border-white/50 bg-slate-950/90 text-white'
                }`}
              >
                {reg.code}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
