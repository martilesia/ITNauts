import React from 'react';
import { Award, CheckCircle2, RotateCcw, Star } from 'lucide-react';
import { computeFinalMissionReport } from '../../../logic/redStormEngine.js';
import { CharacterDialogue } from './MissionCharacters.jsx';
import MartianBaseScene from './MartianBaseScene.jsx';
import ArcadeButton from '../../ArcadeButton.jsx';

const LEARNING_POINTS = [
  'Atmospheric dust can reduce the amount of sunlight reaching solar panels.',
  'Solar panels need sunlight to generate electricity.',
  'Batteries store energy for periods when production decreases.',
  'During emergencies, essential systems must receive priority.',
  'Every engineering decision has consequences.',
];

export default function RedStormResults({
  state,
  onPlayAgain,
  onReturnToBase,
}) {
  const report = computeFinalMissionReport(state);

  return (
    <div className="space-y-4">
      <MartianBaseScene
        stormPhase="clearing"
        lightFactor={0.95}
        batteryLevel={report.remainingEnergy}
        panelProtectionDone={state.panelProtectionDone}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <CharacterDialogue
          speaker="DR. LUNA"
          role="Atmospheric Scientist"
          message="Congratulations, Commander! We successfully protected our crew and kept the base operational during the storm!"
        />
        <CharacterDialogue
          speaker="ASTRO"
          role="Robot Assistant"
          message="Mission accomplished! Your decisions helped save the space base!"
        />
      </div>

      {/* Star Rating & Mission Report */}
      <div className="rounded-2xl border-2 border-amber-300 bg-slate-950/70 p-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-2" aria-label={`${report.starRating} stars`}>
          {[1, 2, 3].map((idx) => (
            <Star
              key={idx}
              size={32}
              className={
                idx <= report.starRating
                  ? 'text-amber-300 fill-amber-300 drop-shadow-[0_0_10px_rgba(251,191,36,0.6)]'
                  : 'text-slate-600'
              }
            />
          ))}
        </div>

        <h3
          className="text-xl sm:text-2xl font-extrabold text-amber-300 mb-4"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          FINAL MISSION REPORT
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4 tabular-nums">
          <div className="rounded-xl border border-emerald-400/50 bg-emerald-950/40 p-2.5">
            <div className="text-[11px] font-bold text-emerald-200">CREW SAFETY</div>
            <div className="text-xl font-extrabold text-white">{report.crewSafety}%</div>
          </div>
          <div className="rounded-xl border border-sky-400/50 bg-sky-950/40 p-2.5">
            <div className="text-[11px] font-bold text-sky-200">REMAINING ENERGY</div>
            <div className="text-xl font-extrabold text-white">{report.remainingEnergy}%</div>
          </div>
          <div className="rounded-xl border border-amber-400/50 bg-amber-950/40 p-2.5">
            <div className="text-[11px] font-bold text-amber-200">RESOURCE MANAGEMENT</div>
            <div className="text-xl font-extrabold text-white">{report.resourceManagement}%</div>
          </div>
          <div className="rounded-xl border border-purple-400/50 bg-purple-950/40 p-2.5">
            <div className="text-[11px] font-bold text-purple-200">SCIENTIFIC KNOWLEDGE</div>
            <div className="text-xl font-extrabold text-white">{report.scientificKnowledge}/3</div>
          </div>
        </div>

        {/* Unlocked Rewards */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-2">
          {report.rewards.map((reward) => (
            <div
              key={reward.id}
              className="rounded-2xl border-2 border-amber-300 bg-gradient-to-b from-amber-500/25 to-orange-600/20 px-4 py-2.5 text-left max-w-[230px]"
            >
              <div className="flex items-center gap-1.5 text-xs font-extrabold text-amber-300">
                <Award size={16} /> {reward.title}
              </div>
              <p className="text-[11px] text-sky-100 mt-0.5">{reward.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* WHAT DID YOU LEARN? */}
      <div className="rounded-2xl border-2 border-sky-300/45 bg-slate-950/65 p-4">
        <h4 className="text-sm font-extrabold text-amber-300 mb-2">
          WHAT DID YOU LEARN?
        </h4>
        <ul className="space-y-1.5 text-xs sm:text-sm text-sky-100">
          {LEARNING_POINTS.map((pt, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>{pt}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-4">
        <ArcadeButton
          variant="red"
          onClick={onPlayAgain}
          className="!min-w-[180px] !min-h-[52px] !text-base"
        >
          <RotateCcw size={18} />
          <span>Play Again</span>
        </ArcadeButton>

        <ArcadeButton
          variant="yellow"
          onClick={() => onReturnToBase(report.starRating)}
          className="!min-w-[235px] !min-h-[52px] !text-base"
        >
          Return to Space Base
        </ArcadeButton>
      </div>
    </div>
  );
}
