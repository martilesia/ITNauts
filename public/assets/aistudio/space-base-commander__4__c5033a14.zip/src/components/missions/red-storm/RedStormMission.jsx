import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Battery,
  CheckCircle2,
  Shield,
  Sparkles,
  Star,
  Sun,
  Wind,
  X,
  Zap,
} from 'lucide-react';
import {
  INITIAL_RED_STORM_STATE,
  PANEL_TOOLS,
  PHASE4_BUDGET,
  applyPhase5Decision,
  calculateActiveSystemsCost,
  computeEnergyProduced,
} from '../../../logic/redStormEngine.js';
import {
  playAlarmSound,
  playChargeSound,
  playClickSound,
  playErrorSound,
  playStartFanfare,
  playSuccessSound,
} from '../../../utils/soundFx.js';
import ArcadeButton from '../../ArcadeButton.jsx';
import AstronautCharacter from '../../AstronautCharacter.jsx';
import MartianBaseScene from './MartianBaseScene.jsx';
import { CharacterDialogue } from './MissionCharacters.jsx';
import DustExplorerLab from './DustExplorerLab.jsx';
import BasePreparationTasks from './BasePreparationTasks.jsx';
import EmergencyMiniGames from './EmergencyMiniGames.jsx';
import RedStormResults from './RedStormResults.jsx';

const PHASE_TITLES = [
  '1. Peaceful Day',
  '2. Storm Alert',
  '3. Research Lab',
  '4. Prepare Base',
  '5. Storm Arrives',
  '6. Emergency',
  '7. Complete',
];

const SYSTEM_INSPECTIONS = {
  energy: {
    label: 'ENERGY',
    value: '80%',
    explanation: 'Solar panels convert bright sunlight into electricity and charge our base batteries.',
  },
  oxygen: {
    label: 'OXYGEN',
    value: '90%',
    explanation: 'Life-support scrubbers circulate clean breathable oxygen inside the astronaut habitats.',
  },
  protection: {
    label: 'PROTECTION',
    value: '85%',
    explanation: 'Base shields, seals, and weather sensors protect the crew from Martian dust.',
  },
};

export default function RedStormMission({
  isOpen,
  mission,
  gameState,
  persOptions,
  onCompleteMission,
  onClose,
}) {
  const [state, setState] = useState(INITIAL_RED_STORM_STATE);
  const [phase1Tip, setPhase1Tip] = useState(
    'Click each of the three base systems below (ENERGY, OXYGEN, PROTECTION) to inspect them!'
  );
  const [threatPick, setThreatPick] = useState(null);
  const [threatFeedback, setThreatFeedback] = useState(null);

  const audioEnabled = Boolean(gameState?.audioEnabled);

  useEffect(() => {
    if (isOpen) {
      setState(INITIAL_RED_STORM_STATE);
      setPhase1Tip(
        'Click each of the three base systems below (ENERGY, OXYGEN, PROTECTION) to inspect them!'
      );
      setThreatPick(null);
      setThreatFeedback(null);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen || !mission) return null;

  const phase = state.currentPhase;

  const goToPhase = (nextPhase) => {
    setState((prev) => {
      const updated = { ...prev, currentPhase: nextPhase };
      if (nextPhase === 2) {
        updated.stormPhase = 'approaching';
        updated.lightFactor = 0.62;
        updated.dustLevel = 40;
        updated.power = computeEnergyProduced(0.62, prev.solarPanelEfficiency);
      } else if (nextPhase === 5) {
        updated.stormPhase = 'storm';
        updated.lightFactor = 0.32;
        updated.dustLevel = 92;
        const effPenalty = prev.panelProtectionDone ? 10 : 28;
        updated.solarPanelEfficiency = Math.max(45, prev.solarPanelEfficiency - effPenalty);
        updated.power = computeEnergyProduced(0.32, updated.solarPanelEfficiency);
      } else if (nextPhase === 7) {
        updated.stormPhase = 'clearing';
        updated.lightFactor = 0.95;
        updated.dustLevel = 10;
        updated.missionCompleted = true;
      }
      return updated;
    });

    if (nextPhase === 2) {
      playAlarmSound(audioEnabled);
    } else if (nextPhase === 7) {
      playStartFanfare(audioEnabled);
    } else {
      playClickSound(audioEnabled);
    }
  };

  /* Phase 1 Handlers */
  const handleInspectSystem = (sysKey) => {
    const info = SYSTEM_INSPECTIONS[sysKey];
    if (!info) return;
    playSuccessSound(audioEnabled);
    setPhase1Tip(`${info.label} (${info.value}): ${info.explanation}`);
    setState((prev) => {
      const already = prev.inspectedSystems.includes(sysKey);
      const nextInspected = already
        ? prev.inspectedSystems
        : [...prev.inspectedSystems, sysKey];
      return {
        ...prev,
        inspectedSystems: nextInspected,
      };
    });
  };

  /* Phase 2 Handler */
  const handleThreatAnswer = (optId) => {
    setThreatPick(optId);
    const isCorrect = optId === 'dust_storm';
    if (isCorrect) {
      playSuccessSound(audioEnabled);
      setThreatFeedback({
        correct: true,
        text: 'Exactly, Commander! Dust can block part of the sunlight. Our solar panels need sunlight to produce electricity!',
      });
    } else {
      playErrorSound(audioEnabled);
      setThreatFeedback({
        correct: false,
        text: 'Hint: Look at the orange dust clouds approaching our solar panels. What blocks the sunlight?',
      });
    }

    setState((prev) => ({
      ...prev,
      threatSolved: prev.threatSolved || isCorrect,
      threatAttempts: prev.threatAttempts + 1,
    }));
  };

  /* Phase 3 Handlers */
  const handleInspectRegion = (regId) => {
    playClickSound(audioEnabled);
    setState((prev) => ({
      ...prev,
      inspectedRegions: prev.inspectedRegions.includes(regId)
        ? prev.inspectedRegions
        : [...prev.inspectedRegions, regId],
      researchProgress: Math.min(100, prev.researchProgress + 20),
    }));
  };

  const handleDustChallengeAnswer = (isCorrect) => {
    if (isCorrect) {
      playSuccessSound(audioEnabled);
    } else {
      playErrorSound(audioEnabled);
    }
    setState((prev) => ({
      ...prev,
      dustLabSolved: prev.dustLabSolved || isCorrect,
      dustLabAttempts: prev.dustLabAttempts + 1,
      researchProgress: isCorrect ? 100 : prev.researchProgress,
    }));
  };

  /* Phase 4 Handlers */
  const handleChargeBattery = () => {
    playChargeSound(audioEnabled);
    setState((prev) => {
      const nextBat = Math.min(100, prev.batteryLevel + 15);
      return {
        ...prev,
        batteryLevel: nextBat,
        batteriesCharged: nextBat >= 90,
      };
    });
  };

  const handleToggleTool = (toolId) => {
    playClickSound(audioEnabled);
    setState((prev) => {
      const exists = prev.selectedTools.includes(toolId);
      const nextTools = exists
        ? prev.selectedTools.filter((id) => id !== toolId)
        : [...prev.selectedTools, toolId];
      const allCorrect = PANEL_TOOLS.filter((t) => t.isCorrect).every((t) =>
        nextTools.includes(t.id)
      );
      const hasWrong = nextTools.some((id) => {
        const tool = PANEL_TOOLS.find((t) => t.id === id);
        return tool && !tool.isCorrect;
      });
      return {
        ...prev,
        selectedTools: nextTools,
        panelProtectionDone: allCorrect && !hasWrong,
      };
    });
  };

  const handleToggleSystem = (sysId) => {
    playClickSound(audioEnabled);
    setState((prev) => {
      const exists = prev.activeSystems.includes(sysId);
      if (exists) {
        return {
          ...prev,
          activeSystems: prev.activeSystems.filter((id) => id !== sysId),
        };
      }
      const next = [...prev.activeSystems, sysId];
      if (calculateActiveSystemsCost(next) > PHASE4_BUDGET) {
        return prev;
      }
      return {
        ...prev,
        activeSystems: next,
      };
    });
  };

  /* Phase 5 Handler */
  const handlePhase5Choice = (optionId) => {
    playClickSound(audioEnabled);
    setState((prev) => applyPhase5Decision(prev, optionId));
  };

  /* Phase 6 Handlers */
  const handleMovePriority = (index, direction) => {
    playClickSound(audioEnabled);
    setState((prev) => {
      const nextIdx = index + direction;
      if (nextIdx < 0 || nextIdx >= prev.priorityOrder.length) return prev;
      const copy = [...prev.priorityOrder];
      const temp = copy[index];
      copy[index] = copy[nextIdx];
      copy[nextIdx] = temp;
      return { ...prev, priorityOrder: copy };
    });
  };

  const handleValidatePriorities = (isCorrect) => {
    if (isCorrect) playSuccessSound(audioEnabled);
    else playErrorSound(audioEnabled);
    setState((prev) => ({
      ...prev,
      prioritiesSolved: prev.prioritiesSolved || isCorrect,
    }));
  };

  const handleInstallRepairComponent = (componentId) => {
    playChargeSound(audioEnabled);
    setState((prev) => {
      const nextSlots = prev.repairedSlots.includes(componentId)
        ? prev.repairedSlots
        : [...prev.repairedSlots, componentId];
      const allRepaired = nextSlots.length >= 3;
      const nextEff = Math.min(100, prev.solarPanelEfficiency + 10);
      return {
        ...prev,
        repairedSlots: nextSlots,
        repairSolved: allRepaired,
        solarPanelEfficiency: nextEff,
        power: allRepaired ? Math.min(100, prev.power + 22) : prev.power,
      };
    });
  };

  const handlePlayAgain = () => {
    playClickSound(audioEnabled);
    setState(INITIAL_RED_STORM_STATE);
    setPhase1Tip(
      'Click each of the three base systems below (ENERGY, OXYGEN, PROTECTION) to inspect them!'
    );
    setThreatPick(null);
    setThreatFeedback(null);
  };

  const phase1AllChecked = state.inspectedSystems.length >= 3;
  const phase5DecisionRecord = state.decisions.find((d) => d.phase === 5);

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-5 backdrop-blur-sm overflow-y-auto transition-colors duration-300 ${
        phase === 5 || phase === 6
          ? 'bg-[#2a0c05]/92'
          : phase === 2
            ? 'bg-[#1a0b1e]/90'
            : 'bg-[#070b1e]/88'
      }`}
      role="dialog"
      aria-modal="true"
      aria-labelledby="red-storm-title"
    >
      <div className="relative w-full max-w-5xl my-auto rounded-[28px] border-4 border-amber-300 bg-gradient-to-b from-[#2b175e] via-[#1d2e75] to-[#111942] p-4 sm:p-6 shadow-[0_24px_70px_rgba(0,0,0,0.85)] text-white">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Return to Space Base"
          className="absolute top-4 right-4 w-10 h-10 rounded-full border-2 border-white/80 bg-rose-600 hover:bg-rose-500 flex items-center justify-center text-white shadow-md cursor-pointer"
        >
          <X size={20} strokeWidth={2.75} />
        </button>

        {/* Mission Header + Commander Badge */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pr-12 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl border-2 border-sky-300 bg-slate-900/70 flex items-center justify-center overflow-hidden shrink-0">
              <AstronautCharacter
                character={gameState.character}
                options={persOptions}
                size={46}
                className="w-11 h-auto"
              />
            </div>
            <div>
              <div className="text-xs font-extrabold uppercase tracking-wider text-amber-300">
                Chapter 9 — ALERT AT THE TWO BASES!
              </div>
              <h2
                id="red-storm-title"
                className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white leading-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                OPERATION: RED STORM
              </h2>
            </div>
          </div>

          {/* Live Resource HUD */}
          <div className="flex flex-wrap items-center gap-2 text-xs font-extrabold tabular-nums">
            <span className="rounded-xl border border-amber-300/60 bg-slate-950/70 px-2.5 py-1.5 inline-flex items-center gap-1">
              <Zap size={14} className="text-amber-300" /> ENERGY: {state.power}%
            </span>
            <span className="rounded-xl border border-emerald-300/60 bg-slate-950/70 px-2.5 py-1.5 inline-flex items-center gap-1">
              <Battery size={14} className="text-emerald-300" /> BATTERY: {state.batteryLevel}%
            </span>
            <span className="rounded-xl border border-sky-300/60 bg-slate-950/70 px-2.5 py-1.5 inline-flex items-center gap-1">
              <Shield size={14} className="text-sky-300" /> SAFETY: {state.crewSafety}%
            </span>
          </div>
        </div>

        {/* 7-Phase Progression Strip */}
        <div className="grid grid-cols-7 gap-1 sm:gap-1.5 mb-5">
          {PHASE_TITLES.map((label, idx) => {
            const pNum = idx + 1;
            const isActive = phase === pNum;
            const isDone = phase > pNum;
            return (
              <div
                key={label}
                className={`rounded-xl border px-1 py-1.5 text-center text-[10px] sm:text-xs font-extrabold truncate ${
                  isActive
                    ? 'border-amber-300 bg-amber-400 text-slate-950'
                    : isDone
                      ? 'border-emerald-400/70 bg-emerald-500/25 text-emerald-200'
                      : 'border-white/15 bg-slate-950/50 text-slate-400'
                }`}
                title={label}
              >
                {label}
              </div>
            );
          })}
        </div>

        {/* PHASE 1 — A PEACEFUL DAY ON MARS */}
        {phase === 1 && (
          <div className="space-y-4">
            <MartianBaseScene
              stormPhase="calm"
              lightFactor={1}
              batteryLevel={state.batteryLevel}
              inspectedSystems={state.inspectedSystems}
              onInspectSystem={handleInspectSystem}
              interactive
            />

            <CharacterDialogue
              speaker="ASTRO"
              role="Robot Assistant"
              message="Good morning, Commander! Everything is working perfectly at our base. Our solar panels are charging the batteries, and the crew is preparing new experiments!"
            />

            {/* Three Interactive Resource Indicators */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 tabular-nums">
              {[
                { key: 'energy', icon: Sun, title: 'ENERGY', val: `${state.power}%`, color: 'border-amber-300 text-amber-300' },
                { key: 'oxygen', icon: Wind, title: 'OXYGEN', val: `${state.oxygen}%`, color: 'border-sky-300 text-sky-300' },
                { key: 'protection', icon: Shield, title: 'PROTECTION', val: `${state.protection}%`, color: 'border-emerald-300 text-emerald-300' },
              ].map((item) => {
                const Icon = item.icon;
                const inspected = state.inspectedSystems.includes(item.key);
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => handleInspectSystem(item.key)}
                    className={`rounded-2xl border-3 p-3.5 text-left transition-transform hover:-translate-y-0.5 cursor-pointer flex items-center justify-between ${
                      inspected
                        ? 'border-emerald-400 bg-emerald-950/45'
                        : 'border-white/30 bg-slate-950/65 hover:border-amber-300'
                    }`}
                  >
                    <div>
                      <div className={`text-xs font-extrabold flex items-center gap-1.5 ${item.color}`}>
                        <Icon size={16} /> {item.title}: {item.val}
                      </div>
                      <div className="text-[11px] text-sky-200 mt-1">
                        {inspected ? 'Inspected!' : 'Click to inspect system'}
                      </div>
                    </div>
                    {inspected && <CheckCircle2 size={22} className="text-emerald-400 shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="rounded-xl border border-sky-300/40 bg-slate-950/60 px-4 py-2.5 text-xs sm:text-sm font-bold text-sky-100 flex items-center justify-between gap-3">
              <span>{phase1Tip}</span>
              {phase1AllChecked && (
                <span className="inline-flex items-center gap-1 text-amber-300 shrink-0">
                  <Star size={18} className="fill-amber-300" /> First Mission Star!
                </span>
              )}
            </div>

            <div className="flex justify-end">
              <ArcadeButton
                variant="yellow"
                onClick={() => goToPhase(2)}
                className={`!min-w-[215px] !min-h-[52px] !text-base ${
                  !phase1AllChecked ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                Continue Mission
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* PHASE 2 — THE UNEXPECTED ALERT! */}
        {phase === 2 && (
          <div className="space-y-4">
            <div className="rounded-2xl border-2 border-rose-400 bg-rose-600/25 px-4 py-2.5 flex items-center justify-between gap-2 animate-pulse">
              <span className="inline-flex items-center gap-2 text-sm sm:text-base font-extrabold text-amber-200">
                <AlertTriangle size={20} className="text-rose-300" />
                EMERGENCY WEATHER ALERT · SOLAR OUTPUT DROPPING TO {state.power}%
              </span>
              <span className="text-xs font-bold text-rose-100 tabular-nums">
                Light Factor: 62%
              </span>
            </div>

            <MartianBaseScene
              stormPhase="approaching"
              lightFactor={state.lightFactor}
              batteryLevel={state.batteryLevel}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <CharacterDialogue
                speaker="ASTRO"
                role="Robot Assistant"
                alert
                message="COMMANDER! WE HAVE A PROBLEM! Our sensors have detected a massive increase in atmospheric dust. A dust storm is approaching our base!"
              />
              <CharacterDialogue
                speaker="DR. LUNA"
                role="Atmospheric Scientist"
                message="We need to analyze the situation. Dust can reduce the amount of sunlight reaching our solar panels. If that happens, our energy production will decrease!"
              />
            </div>

            {/* MINI-GAME: IDENTIFY THE THREAT */}
            <div className="rounded-2xl border-2 border-amber-300 bg-slate-950/75 p-4">
              <h3 className="text-sm sm:text-base font-extrabold text-amber-300 mb-2">
                MINI-GAME: What is the main danger approaching our base?
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {[
                  { id: 'heat', label: 'Rising temperatures.' },
                  { id: 'dust_storm', label: 'A dust storm.' },
                  { id: 'water', label: 'Water shortage.' },
                ].map((opt) => {
                  const picked = threatPick === opt.id;
                  const isCorrect = opt.id === 'dust_storm';
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      disabled={state.threatSolved}
                      onClick={() => handleThreatAnswer(opt.id)}
                      className={`rounded-xl border-2 px-4 py-3 text-sm font-extrabold transition-colors cursor-pointer ${
                        picked && isCorrect
                          ? 'border-emerald-400 bg-emerald-600/40 text-white'
                          : picked && !isCorrect
                            ? 'border-rose-400 bg-rose-600/40 text-white'
                            : 'border-white/25 bg-slate-900 text-white hover:border-amber-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>

              {threatFeedback && (
                <p
                  className={`mt-3 text-xs sm:text-sm font-bold ${
                    threatFeedback.correct ? 'text-emerald-300' : 'text-rose-300'
                  }`}
                >
                  {threatFeedback.text}
                </p>
              )}
            </div>

            <div className="flex justify-end">
              <ArcadeButton
                variant="yellow"
                onClick={() => goToPhase(3)}
                className={`!min-w-[235px] !min-h-[52px] !text-base ${
                  !state.threatSolved ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                Enter Research Lab
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* PHASE 3 — THE RESEARCH LAB: INVESTIGATING THE STORM */}
        {phase === 3 && (
          <DustExplorerLab
            dataUrl={mission.merra2DataUrl}
            inspectedRegions={state.inspectedRegions}
            dustLabSolved={state.dustLabSolved}
            onInspectRegion={handleInspectRegion}
            onAnswerChallenge={handleDustChallengeAnswer}
            onContinue={() => goToPhase(4)}
          />
        )}

        {/* PHASE 4 — PREPARE THE BASE FOR THE STORM */}
        {phase === 4 && (
          <BasePreparationTasks
            state={state}
            onChargeBattery={handleChargeBattery}
            onToggleTool={handleToggleTool}
            onToggleSystem={handleToggleSystem}
            onContinue={() => goToPhase(5)}
          />
        )}

        {/* PHASE 5 — THE STORM HAS ARRIVED! */}
        {phase === 5 && (
          <div className="space-y-4">
            <MartianBaseScene
              stormPhase="storm"
              lightFactor={state.lightFactor}
              batteryLevel={state.batteryLevel}
              panelProtectionDone={state.panelProtectionDone}
            />

            <CharacterDialogue
              speaker="ASTRO"
              role="Robot Assistant"
              alert
              message="COMMANDER! ENERGY PRODUCTION IS DROPPING! WE NEED TO ACT NOW!"
            />

            {/* Environmental Consequences */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs font-bold">
              <div className="rounded-xl border border-orange-400/60 bg-orange-950/50 p-3">
                1. Solar panels receive much less sunlight (Solar Output: {state.power}%).
              </div>
              <div className="rounded-xl border border-amber-400/60 bg-amber-950/50 p-3">
                2. Batteries begin discharging to support active systems.
              </div>
              <div className="rounded-xl border border-rose-400/60 bg-rose-950/50 p-3">
                3. Some exposed equipment requires urgent maintenance.
              </div>
            </div>

            {/* CRITICAL DECISION */}
            <div className="rounded-2xl border-2 border-amber-300 bg-slate-950/75 p-4">
              <h3 className="text-base sm:text-lg font-extrabold text-amber-300 mb-3">
                CRITICAL DECISION: What should we do with our remaining energy?
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {[
                  {
                    id: 'use_batteries',
                    title: 'OPTION A — USE BATTERY RESERVES',
                    pro: 'Advantage: Immediate energy availability.',
                    con: 'Disadvantage: Battery reserves decrease.',
                  },
                  {
                    id: 'send_rover',
                    title: 'OPTION B — SEND ROVER FOR MAINTENANCE',
                    pro: 'Advantage: Potential recovery of solar production.',
                    con: 'Disadvantage: Uses energy & risks dust wear.',
                  },
                  {
                    id: 'power_saving',
                    title: 'OPTION C — POWER-SAVING MODE',
                    pro: 'Advantage: Preserves stored energy.',
                    con: 'Disadvantage: Some science experiments pause.',
                  },
                ].map((opt) => {
                  const chosen = state.phase5Decision === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      disabled={Boolean(state.phase5Decision)}
                      onClick={() => handlePhase5Choice(opt.id)}
                      className={`text-left rounded-2xl border-2 p-3.5 transition-colors cursor-pointer ${
                        chosen
                          ? 'border-amber-300 bg-amber-400/20 text-white'
                          : state.phase5Decision
                            ? 'border-white/10 bg-slate-900/40 text-slate-400'
                            : 'border-sky-300/50 bg-slate-900 text-sky-50 hover:border-amber-300'
                      }`}
                    >
                      <div className="text-xs font-extrabold text-amber-300 mb-1.5">
                        {opt.title}
                      </div>
                      <div className="text-xs text-emerald-300 mb-1">{opt.pro}</div>
                      <div className="text-xs text-rose-300">{opt.con}</div>
                    </button>
                  );
                })}
              </div>

              {phase5DecisionRecord && (
                <div className="mt-3 rounded-xl border border-cyan-300/60 bg-cyan-950/45 p-3 text-xs sm:text-sm font-bold text-cyan-100 flex items-center gap-2">
                  <Sparkles size={18} className="text-amber-300 shrink-0" />
                  <span>{phase5DecisionRecord.summary}</span>
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <ArcadeButton
                variant="yellow"
                onClick={() => goToPhase(6)}
                className={`!min-w-[235px] !min-h-[52px] !text-base ${
                  !state.phase5Decision ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                Handle Base Emergency
              </ArcadeButton>
            </div>
          </div>
        )}

        {/* PHASE 6 — EMERGENCY AT THE BASE! */}
        {phase === 6 && (
          <EmergencyMiniGames
            state={state}
            onMovePriority={handleMovePriority}
            onValidatePriorities={handleValidatePriorities}
            onInstallComponent={handleInstallRepairComponent}
            onContinue={() => goToPhase(7)}
          />
        )}

        {/* PHASE 7 — MISSION COMPLETE! */}
        {phase === 7 && (
          <RedStormResults
            state={state}
            onPlayAgain={handlePlayAgain}
            onReturnToBase={(stars) => onCompleteMission(stars)}
          />
        )}
      </div>
    </div>
  );
}
