import React from 'react';

export default function MartianBaseScene({
  stormPhase = 'calm',
  lightFactor = 1,
  batteryLevel = 70,
  panelProtectionDone = false,
  inspectedSystems = [],
  onInspectSystem,
  interactive = false,
}) {
  const isStorm = stormPhase === 'storm';
  const isApproaching = stormPhase === 'approaching';
  const isClearing = stormPhase === 'clearing';

  const skyTop = isStorm
    ? '#451208'
    : isApproaching
      ? '#6b2214'
      : isClearing
        ? '#7c2d12'
        : '#3b1546';
  const skyBottom = isStorm
    ? '#9a3412'
    : isApproaching
      ? '#b45309'
      : '#c2410c';

  const dustOpacity = isStorm ? 0.55 : isApproaching ? 0.25 : 0;

  return (
    <div className="relative rounded-3xl border-3 border-amber-300/75 overflow-hidden shadow-xl bg-slate-950">
      <svg
        viewBox="0 0 720 280"
        className="w-full h-auto block"
        role="img"
        aria-label="Martian Space Base illustration"
      >
        <defs>
          <linearGradient id="marsSkyGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={skyTop} />
            <stop offset="100%" stopColor={skyBottom} />
          </linearGradient>
          <linearGradient id="marsGroundGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#ea580c" />
            <stop offset="100%" stopColor="#7c2d12" />
          </linearGradient>
        </defs>

        {/* Martian Sky */}
        <rect width="720" height="280" fill="url(#marsSkyGrad)" />

        {/* Distant Sun & Sunlight Rays */}
        <circle
          cx="620"
          cy="52"
          r="24"
          fill="#FDE047"
          opacity={Math.max(0.2, lightFactor)}
        />
        {lightFactor > 0.45 && (
          <polygon
            points="620,52 140,180 260,185"
            fill="#FEF08A"
            opacity={0.1 * lightFactor}
          />
        )}

        {/* Distant Martian Mesas */}
        <path
          d="M0 190 L80 142 L150 142 L210 185 L340 165 L430 135 L520 135 L590 180 L720 158 L720 280 L0 280 Z"
          fill="#9a3412"
          opacity="0.7"
        />

        {/* Martian Ground */}
        <path
          d="M0 202 Q360 186 720 204 L720 280 L0 280 Z"
          fill="url(#marsGroundGrad)"
        />

        {/* 1. SOLAR PANELS (Left) */}
        <g
          onClick={() => interactive && onInspectSystem?.('energy')}
          className={interactive ? 'cursor-pointer' : undefined}
        >
          <rect x="46" y="176" width="8" height="32" fill="#CBD5E1" />
          <rect x="114" y="176" width="8" height="32" fill="#CBD5E1" />
          <polygon
            points="28,150 142,150 132,184 18,184"
            fill="#1D4ED8"
            stroke={panelProtectionDone ? '#FBBF24' : '#93C5FD'}
            strokeWidth={panelProtectionDone ? '4' : '2.5'}
          />
          <line x1="66" y1="150" x2="56" y2="184" stroke="#93C5FD" strokeWidth="1.5" />
          <line x1="104" y1="150" x2="94" y2="184" stroke="#93C5FD" strokeWidth="1.5" />
          <text x="80" y="226" textAnchor="middle" fill="#FEF3C7" fontSize="11" fontWeight="800">
            SOLAR PANELS
          </text>
          {interactive && inspectedSystems.includes('energy') && (
            <circle cx="136" cy="148" r="8" fill="#10B981" stroke="#FFFFFF" strokeWidth="2" />
          )}
        </g>

        {/* 2. BATTERY STORAGE (Near Solar Panels) */}
        <g>
          <rect x="158" y="164" width="44" height="44" rx="8" fill="#1E293B" stroke="#E2E8F0" strokeWidth="2.5" />
          <rect x="172" y="158" width="16" height="6" rx="2" fill="#94A3B8" />
          <rect
            x="166"
            y={172 + (1 - batteryLevel / 100) * 28}
            width="28"
            height={(batteryLevel / 100) * 28}
            rx="3"
            fill={batteryLevel <= 25 ? '#EF4444' : '#22C55E'}
          />
          <text x="180" y="226" textAnchor="middle" fill="#FEF3C7" fontSize="10" fontWeight="800">
            BATTERIES
          </text>
        </g>

        {/* 3. ASTRONAUT HABITATS (Center-Left Dome) */}
        <g
          onClick={() => interactive && onInspectSystem?.('oxygen')}
          className={interactive ? 'cursor-pointer' : undefined}
        >
          <path
            d="M232 208 C232 142 348 142 348 208 Z"
            fill="#F8FAFC"
            stroke="#CBD5E1"
            strokeWidth="3"
          />
          <rect x="262" y="176" width="56" height="16" rx="8" fill="#38BDF8" />
          <rect x="278" y="194" width="24" height="14" rx="3" fill="#1E3A8A" />
          <text x="290" y="226" textAnchor="middle" fill="#FEF3C7" fontSize="11" fontWeight="800">
            HABITATS
          </text>
          {interactive && inspectedSystems.includes('oxygen') && (
            <circle cx="340" cy="154" r="8" fill="#10B981" stroke="#FFFFFF" strokeWidth="2" />
          )}
        </g>

        {/* 4. CONTROL CENTER & 5. COMMUNICATION ANTENNA (Center-Right) */}
        <g
          onClick={() => interactive && onInspectSystem?.('protection')}
          className={interactive ? 'cursor-pointer' : undefined}
        >
          <rect x="372" y="154" width="96" height="54" rx="10" fill="#334155" stroke="#E2E8F0" strokeWidth="3" />
          <rect x="384" y="164" width="72" height="20" rx="5" fill="#0EA5E9" />
          {/* Antenna */}
          <line x1="420" y1="154" x2="420" y2="112" stroke="#E2E8F0" strokeWidth="4" />
          <path d="M404 114 Q420 128 436 114" stroke="#F8FAFC" strokeWidth="4" fill="none" />
          <circle cx="420" cy="108" r="4" fill="#FBBF24" />
          <path d="M402 98 Q420 88 438 98" stroke="#38BDF8" strokeWidth="2.5" fill="none" opacity="0.8" />
          <text x="420" y="226" textAnchor="middle" fill="#FEF3C7" fontSize="11" fontWeight="800">
            CONTROL &amp; COMMS
          </text>
          {interactive && inspectedSystems.includes('protection') && (
            <circle cx="464" cy="154" r="8" fill="#10B981" stroke="#FFFFFF" strokeWidth="2" />
          )}
        </g>

        {/* 6. RESEARCH LABORATORY (Right Dome) */}
        <g>
          <path
            d="M494 208 C494 156 588 156 588 208 Z"
            fill="#E0E7FF"
            stroke="#818CF8"
            strokeWidth="3"
          />
          <circle cx="541" cy="182" r="11" fill="#6366F1" stroke="#FFFFFF" strokeWidth="2" />
          <text x="541" y="226" textAnchor="middle" fill="#FEF3C7" fontSize="11" fontWeight="800">
            RESEARCH LAB
          </text>
        </g>

        {/* 7. EXPLORATION ROVER (Far Right) */}
        <g transform="translate(618, 174)">
          <rect x="4" y="12" width="38" height="16" rx="5" fill="#F59E0B" stroke="#FFFFFF" strokeWidth="2" />
          <rect x="28" y="2" width="12" height="8" rx="3" fill="#E2E8F0" />
          <circle cx="35" cy="6" r="2.5" fill="#22D3EE" />
          <circle cx="10" cy="30" r="6" fill="#1E293B" stroke="#E2E8F0" strokeWidth="2" />
          <circle cx="24" cy="30" r="6" fill="#1E293B" stroke="#E2E8F0" strokeWidth="2" />
          <circle cx="38" cy="30" r="6" fill="#1E293B" stroke="#E2E8F0" strokeWidth="2" />
          <text x="24" y="52" textAnchor="middle" fill="#FEF3C7" fontSize="10" fontWeight="800">
            ROVER
          </text>
        </g>

        {/* Dust Storm Veil & Moving Particles */}
        {dustOpacity > 0 && (
          <g pointerEvents="none">
            <rect width="720" height="280" fill="#ea580c" opacity={dustOpacity} />
            <g opacity={isStorm ? 0.9 : 0.5}>
              <line x1="30" y1="60" x2="180" y2="66" stroke="#FED7AA" strokeWidth="4" strokeLinecap="round" />
              <line x1="240" y1="98" x2="430" y2="106" stroke="#FDBA74" strokeWidth="5" strokeLinecap="round" />
              <line x1="470" y1="74" x2="670" y2="82" stroke="#FED7AA" strokeWidth="4" strokeLinecap="round" />
              <line x1="110" y1="138" x2="310" y2="146" stroke="#FDBA74" strokeWidth="6" strokeLinecap="round" />
              <line x1="380" y1="158" x2="620" y2="164" stroke="#FED7AA" strokeWidth="5" strokeLinecap="round" />
            </g>
          </g>
        )}
      </svg>
    </div>
  );
}
