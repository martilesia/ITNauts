import React from 'react';

export function AstroAvatar({ size = 64, alert = false }) {
  return (
    <svg width={size} height={size} viewBox="0 0 80 80" fill="none" role="img" aria-label="ASTRO robot assistant">
      {/* Antenna */}
      <line x1="40" y1="8" x2="40" y2="18" stroke="#E2E8F0" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="40" cy="7" r="5" fill={alert ? '#EF4444' : '#22D3EE'} />
      {/* Robot Head */}
      <rect x="16" y="18" width="48" height="40" rx="14" fill="#38BDF8" stroke="#FFFFFF" strokeWidth="3" />
      <rect x="23" y="25" width="34" height="20" rx="8" fill="#0F172A" />
      {/* Glowing Eyes */}
      <circle cx="33" cy="35" r="4.5" fill={alert ? '#FBBF24' : '#67E8F9'} />
      <circle cx="47" cy="35" r="4.5" fill={alert ? '#FBBF24' : '#67E8F9'} />
      {/* Smile */}
      <path
        d={alert ? 'M34 50H46' : 'M33 49C36 53 44 53 47 49'}
        stroke="#FFFFFF"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      {/* Ear Panels */}
      <rect x="9" y="30" width="7" height="16" rx="3.5" fill="#F59E0B" stroke="#FFFFFF" strokeWidth="2" />
      <rect x="64" y="30" width="7" height="16" rx="3.5" fill="#F59E0B" stroke="#FFFFFF" strokeWidth="2" />
    </svg>
  );
}

export function DrLunaAvatar({ size = 64 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 80 80" fill="none" role="img" aria-label="Dr. Luna scientist">
      {/* Hair back */}
      <circle cx="40" cy="36" r="24" fill="#4C1D95" />
      {/* Face */}
      <circle cx="40" cy="40" r="19" fill="#FDE1C8" />
      {/* Hair bangs */}
      <path d="M21 36C23 22 36 16 48 20C55 22 59 29 59 36C51 28 33 27 21 36Z" fill="#5B21B6" />
      {/* Glasses */}
      <circle cx="33" cy="40" r="6" stroke="#38BDF8" strokeWidth="2.5" fill="rgba(186,230,253,0.35)" />
      <circle cx="47" cy="40" r="6" stroke="#38BDF8" strokeWidth="2.5" fill="rgba(186,230,253,0.35)" />
      <line x1="39" y1="40" x2="41" y2="40" stroke="#38BDF8" strokeWidth="2.5" />
      {/* Eyes */}
      <circle cx="33" cy="40" r="2.2" fill="#1E293B" />
      <circle cx="47" cy="40" r="2.2" fill="#1E293B" />
      {/* Smile */}
      <path d="M35 50C38 53 42 53 45 50" stroke="#9A3412" strokeWidth="2.2" strokeLinecap="round" />
      {/* Lab Collar */}
      <path d="M20 62C24 55 56 55 60 62L64 74H16L20 62Z" fill="#F8FAFC" stroke="#CBD5E1" strokeWidth="2" />
      <circle cx="40" cy="66" r="3.5" fill="#F59E0B" />
    </svg>
  );
}

export function EngineerMaxAvatar({ size = 64 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 80 80" fill="none" role="img" aria-label="Engineer Max">
      {/* Face */}
      <circle cx="40" cy="42" r="19" fill="#F3C69F" />
      {/* Hard Hat / Engineering Helmet */}
      <path d="M19 36C20 20 30 14 40 14C50 14 60 20 61 36H19Z" fill="#F59E0B" stroke="#FFFFFF" strokeWidth="2.5" />
      <rect x="16" y="33" width="48" height="6" rx="3" fill="#D97706" />
      {/* Safety Goggles on Hat */}
      <rect x="28" y="21" width="24" height="9" rx="4" fill="#38BDF8" stroke="#FFFFFF" strokeWidth="1.5" />
      {/* Eyes & Smile */}
      <circle cx="33" cy="44" r="2.5" fill="#1E293B" />
      <circle cx="47" cy="44" r="2.5" fill="#1E293B" />
      <path d="M34 52C38 55 42 55 46 52" stroke="#7C2D12" strokeWidth="2.3" strokeLinecap="round" />
      {/* Suit */}
      <path d="M20 63C25 57 55 57 60 63L64 74H16L20 63Z" fill="#2563EB" stroke="#FFFFFF" strokeWidth="2" />
    </svg>
  );
}

export function CharacterDialogue({ speaker, role, message, alert = false }) {
  const renderAvatar = () => {
    if (speaker === 'DR. LUNA') return <DrLunaAvatar size={62} />;
    if (speaker === 'ENGINEER MAX') return <EngineerMaxAvatar size={62} />;
    return <AstroAvatar size={62} alert={alert} />;
  };

  const borderStyle = alert
    ? 'border-rose-400 bg-rose-950/65'
    : speaker === 'DR. LUNA'
      ? 'border-purple-300 bg-indigo-950/70'
      : speaker === 'ENGINEER MAX'
        ? 'border-amber-300 bg-slate-900/80'
        : 'border-sky-300 bg-slate-950/75';

  return (
    <div className={`flex items-center gap-3.5 rounded-2xl border-2 p-3.5 shadow-lg ${borderStyle}`}>
      <div className="shrink-0">{renderAvatar()}</div>
      <div className="min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-amber-300">
            {speaker}
          </span>
          {role && (
            <span className="text-[11px] font-bold text-sky-200/80">
              · {role}
            </span>
          )}
        </div>
        <p className="text-xs sm:text-sm md:text-base font-bold text-white leading-snug">
          {message}
        </p>
      </div>
    </div>
  );
}
