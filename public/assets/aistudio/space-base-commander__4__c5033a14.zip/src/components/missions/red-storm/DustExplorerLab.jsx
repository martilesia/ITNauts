import React, { useEffect, useState } from 'react';
import { Calendar, Globe, Info, Sparkles } from 'lucide-react';
import { CharacterDialogue } from './MissionCharacters.jsx';
import ArcadeButton from '../../ArcadeButton.jsx';

const FALLBACK_MERRA2 = {
  dataset: 'NASA MERRA-2 — M2T1NXAER',
  sourceLabel: 'ILLUSTRATIVE DATA — NOT A REAL NASA MEASUREMENT',
  scientificNote:
    'MERRA-2 provides atmospheric aerosol data for Earth (not Mars). Values below are illustrative samples.',
  variables: {
    DUCMASS: {
      name: 'Dust Column Mass (DUCMASS)',
      unit: 'mg/m²',
      description: 'Total dust in a vertical column of air.',
    },
    DUSMASS: {
      name: 'Dust Surface Mass (DUSMASS)',
      unit: 'µg/m³',
      description: 'Dust concentration near the surface.',
    },
    DUEXTTAU: {
      name: 'Dust Extinction AOT (DUEXTTAU)',
      unit: 'optical depth',
      description: 'How much sunlight dust blocks.',
    },
  },
  dates: [
    {
      id: '2024-03-14',
      label: 'March 14, 2024',
      regions: [
        { id: 'sahara', name: 'Sahara Desert', x: 51, y: 42, level: 'high', DUCMASS: 840, DUSMASS: 410, DUEXTTAU: 0.92, summary: 'Strong desert winds lift heavy dust plumes.' },
        { id: 'gobi', name: 'Gobi Basin', x: 74, y: 36, level: 'moderate', DUCMASS: 390, DUSMASS: 185, DUEXTTAU: 0.44, summary: 'Moderate spring winds carry dust.' },
        { id: 'amazon', name: 'Amazon Rainforest', x: 31, y: 62, level: 'low', DUCMASS: 65, DUSMASS: 28, DUEXTTAU: 0.09, summary: 'Humid air keeps dust very low.' },
      ],
      challengeRegions: ['sahara', 'gobi', 'amazon'],
      dustiestRegionId: 'sahara',
    },
  ],
};

const LEVEL_STYLES = {
  high: 'bg-rose-500 border-white text-white',
  moderate: 'bg-amber-400 border-white text-slate-950',
  low: 'bg-emerald-400 border-white text-slate-950',
};

export default function DustExplorerLab({
  dataUrl = '/data/merra2-sample.json',
  inspectedRegions,
  dustLabSolved,
  onInspectRegion,
  onAnswerChallenge,
  onContinue,
}) {
  const [dataset, setDataset] = useState(FALLBACK_MERRA2);
  const [selectedDateId, setSelectedDateId] = useState('2024-03-14');
  const [selectedVar, setSelectedVar] = useState('DUCMASS');
  const [activeRegionId, setActiveRegionId] = useState('sahara');
  const [challengePick, setChallengePick] = useState(null);
  const [challengeFeedback, setChallengeFeedback] = useState(null);

  useEffect(() => {
    let active = true;
    fetch(dataUrl)
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error('load failed'))))
      .then((json) => {
        if (active && json && Array.isArray(json.dates)) {
          setDataset(json);
          setSelectedDateId(json.dates[0].id);
        }
      })
      .catch(() => {
        // Offline fallback already active
      });
    return () => {
      active = false;
    };
  }, [dataUrl]);

  const currentDate =
    dataset.dates.find((d) => d.id === selectedDateId) || dataset.dates[0];
  const regions = currentDate?.regions || [];
  const activeRegion =
    regions.find((r) => r.id === activeRegionId) || regions[0];
  const variables = dataset.variables || FALLBACK_MERRA2.variables;
  const activeVarMeta = variables[selectedVar];

  const challengeOptions = (currentDate?.challengeRegions || [])
    .map((id) => regions.find((r) => r.id === id))
    .filter(Boolean);

  const handleRegionClick = (regId) => {
    setActiveRegionId(regId);
    onInspectRegion(regId);
  };

  const handleAnswer = (regId) => {
    setChallengePick(regId);
    const isCorrect = regId === currentDate.dustiestRegionId;
    if (isCorrect) {
      setChallengeFeedback({
        correct: true,
        text: `Great job! ${
          regions.find((r) => r.id === regId)?.name
        } has the highest ${selectedVar} and dust optical depth on ${currentDate.label}.`,
      });
    } else {
      setChallengeFeedback({
        correct: false,
        text: 'Not quite! Look closely at the red "High Dust" markers and compare the numbers on the map.',
      });
    }
    onAnswerChallenge(isCorrect);
  };

  return (
    <div className="space-y-4">
      <CharacterDialogue
        speaker="DR. LUNA"
        role="Atmospheric Scientist"
        message="Commander, scientists use satellites and computer models to study dust floating in Earth's atmosphere. Let's explore NASA MERRA-2 (M2T1NXAER) data for Earth!"
      />

      {/* Scientific Distinction & Source Banner */}
      <div className="rounded-2xl border-2 border-cyan-300/60 bg-cyan-950/45 p-3 text-xs sm:text-sm text-cyan-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <span className="font-extrabold text-amber-300">{dataset.dataset}</span>
          <span className="mx-2" aria-hidden="true">·</span>
          <span>Earth Atmospheric Aerosols (NOT Mars)</span>
        </div>
        <span className="font-extrabold text-amber-200">{dataset.sourceLabel}</span>
      </div>

      {/* Controls: Date Selector + Variable Selector */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="rounded-2xl border-2 border-sky-300/35 bg-slate-950/60 p-3">
          <div className="text-xs font-extrabold text-amber-300 flex items-center gap-1.5 mb-2">
            <Calendar size={14} /> Observation Date
          </div>
          <div className="flex flex-wrap gap-1.5">
            {dataset.dates.map((d) => (
              <button
                key={d.id}
                type="button"
                onClick={() => {
                  setSelectedDateId(d.id);
                  setChallengePick(null);
                  setChallengeFeedback(null);
                }}
                className={`rounded-xl px-2.5 py-1.5 text-xs font-bold border transition-colors cursor-pointer ${
                  d.id === selectedDateId
                    ? 'border-amber-300 bg-amber-400 text-slate-950'
                    : 'border-white/25 bg-slate-900 text-sky-100 hover:border-sky-300'
                }`}
              >
                {d.id}
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border-2 border-sky-300/35 bg-slate-950/60 p-3">
          <div className="text-xs font-extrabold text-amber-300 flex items-center gap-1.5 mb-2">
            <Sparkles size={14} /> Scientific Variable (Different Properties)
          </div>
          <div className="flex flex-wrap gap-1.5">
            {Object.keys(variables).map((vKey) => (
              <button
                key={vKey}
                type="button"
                onClick={() => setSelectedVar(vKey)}
                className={`rounded-xl px-2.5 py-1.5 text-xs font-bold border transition-colors cursor-pointer ${
                  selectedVar === vKey
                    ? 'border-cyan-300 bg-cyan-400 text-slate-950'
                    : 'border-white/25 bg-slate-900 text-sky-100 hover:border-cyan-300'
                }`}
              >
                {vKey}
              </button>
            ))}
          </div>
          <p className="mt-1.5 text-[11px] text-sky-200 leading-snug">
            <strong>{activeVarMeta?.name}:</strong> {activeVarMeta?.description}
          </p>
        </div>
      </div>

      {/* Interactive Earth Dust Map + Region Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
        <div className="lg:col-span-7 rounded-2xl border-3 border-sky-300 bg-[#0b2545] p-3 flex flex-col justify-between">
          <div className="relative w-full aspect-[16/9] rounded-xl overflow-hidden bg-gradient-to-b from-[#0c4a6e] to-[#082f49] border border-sky-400/30">
            {/* Stylized World Continents Silhouette */}
            <svg viewBox="0 0 100 60" className="w-full h-full opacity-55" aria-hidden="true">
              <path d="M12 14 L28 12 L32 24 L20 29 L12 22 Z" fill="#22c55e" />
              <path d="M25 32 L38 34 L36 52 L27 50 Z" fill="#16a34a" />
              <path d="M44 10 L58 10 L56 20 L45 18 Z" fill="#22c55e" />
              <path d="M44 21 L59 22 L56 46 L46 42 Z" fill="#eab308" />
              <path d="M58 12 L86 14 L84 34 L62 32 Z" fill="#22c55e" />
              <path d="M76 38 L88 40 L86 50 L75 48 Z" fill="#16a34a" />
            </svg>

            {/* Interactive Region Pins */}
            {regions.map((reg) => {
              const isSelected = reg.id === activeRegion?.id;
              return (
                <button
                  key={reg.id}
                  type="button"
                  onClick={() => handleRegionClick(reg.id)}
                  style={{ left: `${reg.x}%`, top: `${reg.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 px-2.5 py-1 text-[11px] font-extrabold shadow-lg transition-transform cursor-pointer whitespace-nowrap ${
                    LEVEL_STYLES[reg.level] || LEVEL_STYLES.low
                  } ${isSelected ? 'scale-115 ring-4 ring-white z-10' : 'hover:scale-105'}`}
                >
                  {reg.name.split(' ')[0]} · {reg[selectedVar]}
                </button>
              );
            })}
          </div>

          {/* Color Legend */}
          <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs font-bold">
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-400 inline-block" /> Low dust
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-amber-400 inline-block" /> Moderate dust
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500 inline-block" /> High dust
              </span>
            </div>
            <span className="text-sky-200">Explored: {inspectedRegions.length} regions</span>
          </div>
        </div>

        {/* Right Side: Region Readout + NASA Science Fact */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          {activeRegion && (
            <div className="rounded-2xl border-2 border-sky-300/45 bg-slate-950/70 p-3.5 tabular-nums">
              <div className="flex items-center gap-2 text-amber-300 font-extrabold text-sm mb-1">
                <Globe size={16} /> {activeRegion.name}
              </div>
              <p className="text-xs text-sky-100 mb-2.5">{activeRegion.summary}</p>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="rounded-xl bg-slate-900 p-2 border border-white/10">
                  <div className="text-sky-300 font-bold">DUCMASS</div>
                  <div className="font-extrabold text-white">{activeRegion.DUCMASS} mg/m²</div>
                </div>
                <div className="rounded-xl bg-slate-900 p-2 border border-white/10">
                  <div className="text-sky-300 font-bold">DUSMASS</div>
                  <div className="font-extrabold text-white">{activeRegion.DUSMASS} µg/m³</div>
                </div>
                <div className="rounded-xl bg-slate-900 p-2 border border-white/10">
                  <div className="text-sky-300 font-bold">DUEXTTAU</div>
                  <div className="font-extrabold text-white">{activeRegion.DUEXTTAU}</div>
                </div>
              </div>
            </div>
          )}

          {/* NASA Science Fact */}
          <div className="rounded-2xl border-2 border-amber-300/50 bg-indigo-950/75 p-3.5 text-xs text-sky-100 leading-relaxed">
            <div className="font-extrabold text-amber-300 flex items-center gap-1.5 mb-1">
              <Info size={15} /> NASA SCIENCE FACT
            </div>
            MERRA-2 helps scientists study Earth&apos;s atmosphere, including dust and other aerosols. We can use this information to learn how atmospheric particles affect sunlight!
          </div>
        </div>
      </div>

      {/* Mini-Game: Find the Dustiest Region! */}
      <div className="rounded-2xl border-2 border-amber-300 bg-slate-950/70 p-4">
        <h3 className="text-sm sm:text-base font-extrabold text-amber-300 mb-2">
          MINI-GAME: Which region has the highest dust concentration on {currentDate?.id}?
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {challengeOptions.map((opt) => {
            const picked = challengePick === opt.id;
            const isCorrect = opt.id === currentDate.dustiestRegionId;
            return (
              <button
                key={opt.id}
                type="button"
                disabled={dustLabSolved}
                onClick={() => handleAnswer(opt.id)}
                className={`rounded-xl border-2 px-3 py-2.5 text-xs sm:text-sm font-extrabold transition-colors cursor-pointer ${
                  picked && isCorrect
                    ? 'border-emerald-400 bg-emerald-600/40 text-white'
                    : picked && !isCorrect
                      ? 'border-rose-400 bg-rose-600/40 text-white'
                      : 'border-white/25 bg-slate-900 text-white hover:border-amber-300'
                }`}
              >
                {opt.name}
              </button>
            );
          })}
        </div>

        {challengeFeedback && (
          <p
            className={`mt-2.5 text-xs sm:text-sm font-bold ${
              challengeFeedback.correct ? 'text-emerald-300' : 'text-rose-300'
            }`}
          >
            {challengeFeedback.text}
          </p>
        )}
      </div>

      <div className="flex justify-end">
        <ArcadeButton
          variant="yellow"
          onClick={onContinue}
          className={`!min-w-[210px] !min-h-[52px] !text-base ${
            !dustLabSolved ? 'opacity-50 pointer-events-none' : ''
          }`}
        >
          Go to Phase 4: Prepare Base
        </ArcadeButton>
      </div>
    </div>
  );
}
