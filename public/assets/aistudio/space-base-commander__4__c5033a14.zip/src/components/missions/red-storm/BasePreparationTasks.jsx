import React from 'react';
import { BatteryCharging, Check, Shield, Wrench, Zap } from 'lucide-react';
import {
  BASE_SYSTEMS,
  PANEL_TOOLS,
  PHASE4_BUDGET,
  calculateActiveSystemsCost,
} from '../../../logic/redStormEngine.js';
import { CharacterDialogue } from './MissionCharacters.jsx';
import ArcadeButton from '../../ArcadeButton.jsx';

export default function BasePreparationTasks({
  state,
  onChargeBattery,
  onToggleTool,
  onToggleSystem,
  onContinue,
}) {
  const totalCost = calculateActiveSystemsCost(state.activeSystems);
  const allCorrectToolsSelected = PANEL_TOOLS.filter((t) => t.isCorrect).every((t) =>
    state.selectedTools.includes(t.id)
  );
  const wrongToolSelected = state.selectedTools.some((id) => {
    const tool = PANEL_TOOLS.find((t) => t.id === id);
    return tool && !tool.isCorrect;
  });

  const canAdvance =
    state.batteriesCharged &&
    state.panelProtectionDone &&
    state.activeSystems.length > 0 &&
    totalCost <= PHASE4_BUDGET;

  return (
    <div className="space-y-4">
      <CharacterDialogue
        speaker="ENGINEER MAX"
        role="Base Engineer"
        message="Commander, we don't have much time! We need to charge our batteries, protect the solar panels, and choose which systems stay powered before the dust storm hits!"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* TASK A — CHARGE THE BATTERIES */}
        <div className="rounded-2xl border-2 border-sky-300/45 bg-slate-950/65 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <h3 className="text-sm font-extrabold text-amber-300 flex items-center gap-1.5">
                <BatteryCharging size={18} /> TASK A — CHARGE BATTERIES
              </h3>
              {state.batteriesCharged && (
                <span className="text-xs font-extrabold text-emerald-300">READY</span>
              )}
            </div>
            <p className="text-xs text-sky-100 mb-3">
              Transfer solar energy into battery storage before sunlight drops! (Target: 90%+)
            </p>

            {/* Animated Battery Meter */}
            <div className="rounded-xl border-2 border-white/25 bg-slate-900 p-3 mb-3 tabular-nums">
              <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                <span>Battery Storage</span>
                <span className="text-emerald-300 font-extrabold">{state.batteryLevel}%</span>
              </div>
              <div className="w-full h-4 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-400 to-cyan-300 transition-all duration-200"
                  style={{ width: `${state.batteryLevel}%` }}
                />
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onChargeBattery}
            disabled={state.batteryLevel >= 100}
            className="w-full rounded-xl border-2 border-white bg-gradient-to-b from-emerald-400 to-emerald-600 py-2.5 px-3 text-sm font-extrabold text-slate-950 shadow-md hover:brightness-105 disabled:opacity-60 cursor-pointer flex items-center justify-center gap-2"
          >
            <Zap size={16} />
            <span>{state.batteryLevel >= 100 ? 'Batteries 100% Charged!' : 'Transfer +15% Energy'}</span>
          </button>
        </div>

        {/* TASK B — PROTECT THE SOLAR PANELS */}
        <div className="rounded-2xl border-2 border-sky-300/45 bg-slate-950/65 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-2">
              <h3 className="text-sm font-extrabold text-amber-300 flex items-center gap-1.5">
                <Shield size={18} /> TASK B — PROTECT PANELS
              </h3>
              {state.panelProtectionDone && (
                <span className="text-xs font-extrabold text-emerald-300">SECURED</span>
              )}
            </div>
            <p className="text-xs text-sky-100 mb-3">
              Select the 3 right tools to protect our solar panels from Martian dust!
            </p>

            <div className="space-y-2">
              {PANEL_TOOLS.map((tool) => {
                const picked = state.selectedTools.includes(tool.id);
                return (
                  <button
                    key={tool.id}
                    type="button"
                    onClick={() => onToggleTool(tool.id)}
                    className={`w-full text-left rounded-xl border-2 p-2.5 text-xs transition-colors cursor-pointer flex items-start justify-between gap-2 ${
                      picked
                        ? tool.isCorrect
                          ? 'border-emerald-400 bg-emerald-600/25 text-white'
                          : 'border-rose-400 bg-rose-600/30 text-rose-100'
                        : 'border-white/20 bg-slate-900 text-sky-100 hover:border-amber-300'
                    }`}
                  >
                    <div>
                      <div className="font-extrabold">{tool.name}</div>
                      <div className="text-[11px] opacity-85">{tool.description}</div>
                    </div>
                    <span className="mt-0.5 shrink-0">
                      {picked ? <Check size={16} /> : <Wrench size={14} className="opacity-50" />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {wrongToolSelected && (
            <p className="mt-2 text-xs font-bold text-rose-300">
              Careful! Water freezes on Mars — unselect the Garden Water Hose!
            </p>
          )}
          {allCorrectToolsSelected && !wrongToolSelected && (
            <p className="mt-2 text-xs font-bold text-emerald-300">
              Solar panels secured with dust shields, anchors, and sweepers!
            </p>
          )}
        </div>

        {/* TASK C — PRIORITIZE BASE SYSTEMS (BUDGET: 7 UNITS) */}
        <div className="rounded-2xl border-2 border-sky-300/45 bg-slate-950/65 p-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-extrabold text-amber-300 mb-1">
              TASK C — PRIORITIZE SYSTEMS
            </h3>
            <p className="text-xs text-sky-100 mb-2.5">
              Choose which base systems stay active without exceeding our 7-unit energy budget.
            </p>

            <div
              className={`rounded-xl border-2 px-3 py-2 text-xs font-extrabold mb-3 tabular-nums ${
                totalCost > PHASE4_BUDGET
                  ? 'border-rose-400 bg-rose-950/50 text-rose-200'
                  : 'border-cyan-300/60 bg-slate-900 text-cyan-200'
              }`}
            >
              TOTAL ENERGY CONSUMPTION: {totalCost} / {PHASE4_BUDGET} UNITS
            </div>

            <div className="space-y-2">
              {BASE_SYSTEMS.map((sys) => {
                const isActive = state.activeSystems.includes(sys.id);
                const wouldExceed = !isActive && totalCost + sys.cost > PHASE4_BUDGET;
                return (
                  <button
                    key={sys.id}
                    type="button"
                    onClick={() => onToggleSystem(sys.id)}
                    disabled={wouldExceed}
                    className={`w-full text-left rounded-xl border-2 p-2.5 text-xs transition-colors cursor-pointer flex items-center justify-between gap-2 ${
                      isActive
                        ? 'border-amber-300 bg-amber-400/20 text-white'
                        : wouldExceed
                          ? 'border-white/10 bg-slate-900/40 text-slate-500 cursor-not-allowed'
                          : 'border-white/20 bg-slate-900 text-sky-100 hover:border-amber-300'
                    }`}
                  >
                    <div>
                      <div className="font-extrabold">
                        {sys.name} ({sys.cost} {sys.cost === 1 ? 'unit' : 'units'})
                      </div>
                      <div className="text-[11px] opacity-85">{sys.description}</div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold ${
                        isActive ? 'bg-emerald-500 text-white' : 'bg-slate-700 text-slate-300'
                      }`}
                    >
                      {isActive ? 'ON' : 'OFF'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <p className="mt-2 text-[11px] text-sky-200/85">
            Fictional gameplay energy units. Pick wisely — your choices affect the storm!
          </p>
        </div>
      </div>

      <div className="flex items-center justify-between gap-3">
        <p className="text-xs font-bold text-sky-200">
          {canAdvance
            ? 'All preparation tasks complete! Ready for the storm.'
            : 'Complete Tasks A, B, and C within the 7-unit budget to continue.'}
        </p>
        <ArcadeButton
          variant="yellow"
          onClick={onContinue}
          className={`!min-w-[210px] !min-h-[52px] !text-base ${
            !canAdvance ? 'opacity-50 pointer-events-none' : ''
          }`}
        >
          Brace for the Storm!
        </ArcadeButton>
      </div>
    </div>
  );
}
