import React, { useState } from 'react';
import { ArrowDown, ArrowUp, CheckCircle2, Wrench } from 'lucide-react';
import {
  EMERGENCY_PRIORITY_ITEMS,
  REPAIR_COMPONENTS,
} from '../../../logic/redStormEngine.js';
import { CharacterDialogue } from './MissionCharacters.jsx';
import ArcadeButton from '../../ArcadeButton.jsx';

export default function EmergencyMiniGames({
  state,
  onMovePriority,
  onValidatePriorities,
  onInstallComponent,
  onContinue,
}) {
  const [selectedPartId, setSelectedPartId] = useState(null);
  const [priorityFeedback, setPriorityFeedback] = useState(null);
  const [repairHint, setRepairHint] = useState(null);

  const handleCheckPriorities = () => {
    const isCorrect =
      state.priorityOrder[0] === 'crew_life_support' &&
      state.priorityOrder[1] === 'preserve_essential_energy';
    onValidatePriorities(isCorrect);
    setPriorityFeedback(
      isCorrect
        ? 'Perfect priority order! Protecting the crew and life support always comes first in an emergency.'
        : 'Hint: What keeps astronauts alive right now? Move "Protect the crew and maintain life support" to #1!'
    );
  };

  const handleSlotClick = (slotComponentId) => {
    if (state.repairedSlots.includes(slotComponentId)) return;
    if (!selectedPartId) {
      setRepairHint('First pick a replacement component on the left, then click its matching slot!');
      return;
    }

    if (selectedPartId === slotComponentId) {
      onInstallComponent(slotComponentId);
      setSelectedPartId(null);
      setRepairHint('Component installed! Great engineering work, Commander!');
    } else {
      setRepairHint('That component fits a different slot — check the label and try matching it!');
    }
  };

  const canFinishPhase6 = state.prioritiesSolved && state.repairSolved;

  return (
    <div className="space-y-4">
      <CharacterDialogue
        speaker="ASTRO"
        role="Robot Assistant"
        alert={!canFinishPhase6}
        message={
          canFinishPhase6
            ? "Excellent work, Commander! We've recovered part of our energy production. The crew is safer now!"
            : 'Commander, we have another problem! Our energy reserves are getting dangerously low. Set emergency priorities and repair the solar panel!'
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* MINI-GAME A — EMERGENCY PRIORITIES */}
        <div className="rounded-2xl border-2 border-amber-300/65 bg-slate-950/70 p-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm sm:text-base font-extrabold text-amber-300 mb-1">
              MINI-GAME A — EMERGENCY PRIORITIES
            </h3>
            <p className="text-xs text-sky-100 mb-3">
              Arrange these cards from #1 (Highest Priority) to #3 using the arrows:
            </p>

            <div className="space-y-2 mb-3">
              {state.priorityOrder.map((itemId, index) => {
                const item = EMERGENCY_PRIORITY_ITEMS.find((p) => p.id === itemId);
                return (
                  <div
                    key={itemId}
                    className={`flex items-center justify-between gap-2 rounded-xl border-2 p-2.5 text-xs sm:text-sm font-bold ${
                      state.prioritiesSolved
                        ? 'border-emerald-400 bg-emerald-950/45 text-white'
                        : 'border-sky-300/45 bg-slate-900 text-sky-50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-amber-400 text-slate-950 font-extrabold flex items-center justify-center shrink-0">
                        {index + 1}
                      </span>
                      <span>{item?.label}</span>
                    </div>

                    {!state.prioritiesSolved && (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => onMovePriority(index, -1)}
                          disabled={index === 0}
                          aria-label="Move priority up"
                          className="w-7 h-7 rounded-lg bg-slate-800 border border-white/25 flex items-center justify-center disabled:opacity-35 cursor-pointer"
                        >
                          <ArrowUp size={14} />
                        </button>
                        <button
                          type="button"
                          onClick={() => onMovePriority(index, 1)}
                          disabled={index === state.priorityOrder.length - 1}
                          aria-label="Move priority down"
                          className="w-7 h-7 rounded-lg bg-slate-800 border border-white/25 flex items-center justify-center disabled:opacity-35 cursor-pointer"
                        >
                          <ArrowDown size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {priorityFeedback && (
              <p
                className={`text-xs font-bold mb-3 ${
                  state.prioritiesSolved ? 'text-emerald-300' : 'text-rose-300'
                }`}
              >
                {priorityFeedback}
              </p>
            )}
          </div>

          {!state.prioritiesSolved ? (
            <button
              type="button"
              onClick={handleCheckPriorities}
              className="w-full rounded-xl border-2 border-white bg-gradient-to-b from-amber-300 to-orange-500 py-2.5 text-sm font-extrabold text-slate-950 cursor-pointer"
            >
              Confirm Priority Order
            </button>
          ) : (
            <div className="inline-flex items-center justify-center gap-2 text-sm font-extrabold text-emerald-300 py-2">
              <CheckCircle2 size={18} /> Priorities Confirmed!
            </div>
          )}
        </div>

        {/* MINI-GAME B — REPAIR THE SOLAR PANEL */}
        <div className="rounded-2xl border-2 border-sky-300/65 bg-slate-950/70 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-1">
              <h3 className="text-sm sm:text-base font-extrabold text-amber-300 flex items-center gap-1.5">
                <Wrench size={17} /> MINI-GAME B — REPAIR SOLAR PANEL
              </h3>
              <span className="text-xs font-extrabold text-cyan-200 tabular-nums">
                {state.repairedSlots.length} / {REPAIR_COMPONENTS.length}
              </span>
            </div>
            <p className="text-xs text-sky-100 mb-3">
              Select a spare part on the left, then click its matching damaged slot on the right!
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
              {/* Spare Parts */}
              <div className="space-y-2">
                <div className="text-[11px] font-extrabold uppercase text-sky-300">
                  1. Spare Components
                </div>
                {REPAIR_COMPONENTS.map((part) => {
                  const isUsed = state.repairedSlots.includes(part.id);
                  const isSelected = selectedPartId === part.id;
                  return (
                    <button
                      key={part.id}
                      type="button"
                      disabled={isUsed}
                      onClick={() => {
                        setSelectedPartId(part.id);
                        setRepairHint(part.hint);
                      }}
                      className={`w-full text-left rounded-xl border-2 p-2.5 text-xs font-extrabold transition-colors cursor-pointer ${
                        isUsed
                          ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300 opacity-60'
                          : isSelected
                            ? 'border-amber-300 bg-amber-400 text-slate-950'
                            : 'border-white/25 bg-slate-900 text-white hover:border-amber-300'
                      }`}
                    >
                      {part.name}
                    </button>
                  );
                })}
              </div>

              {/* Damaged Solar Panel Slots */}
              <div className="space-y-2">
                <div className="text-[11px] font-extrabold uppercase text-sky-300">
                  2. Solar Array Slots
                </div>
                {REPAIR_COMPONENTS.map((slot) => {
                  const isRepaired = state.repairedSlots.includes(slot.id);
                  return (
                    <button
                      key={slot.id}
                      type="button"
                      disabled={isRepaired}
                      onClick={() => handleSlotClick(slot.id)}
                      className={`w-full text-left rounded-xl border-2 border-dashed p-2.5 text-xs font-extrabold transition-colors cursor-pointer ${
                        isRepaired
                          ? 'border-emerald-400 border-solid bg-emerald-600/30 text-emerald-200'
                          : 'border-amber-300/70 bg-slate-900/80 text-amber-200 hover:bg-slate-800'
                      }`}
                    >
                      {isRepaired ? `✓ ${slot.name} Installed` : slot.slotLabel}
                    </button>
                  );
                })}
              </div>
            </div>

            {repairHint && (
              <p className="text-xs font-bold text-cyan-200 mb-2">{repairHint}</p>
            )}
          </div>

          {/* Repair Progress Bar */}
          <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 transition-all duration-200"
              style={{
                width: `${(state.repairedSlots.length / REPAIR_COMPONENTS.length) * 100}%`,
              }}
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <ArcadeButton
          variant="yellow"
          onClick={onContinue}
          className={`!min-w-[230px] !min-h-[54px] !text-base ${
            !canFinishPhase6 ? 'opacity-50 pointer-events-none' : ''
          }`}
        >
          Complete Storm Survival!
        </ArcadeButton>
      </div>
    </div>
  );
}
